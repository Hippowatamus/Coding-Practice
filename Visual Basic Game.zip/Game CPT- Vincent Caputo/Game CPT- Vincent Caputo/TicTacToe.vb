﻿'Tic Tac Toe
'Objective: The Objective Of this game Is To line up three x's in a row within the 3 by 3 tile square while an A.I. tries to stop you.

'First the starting player Is decided randomly When the user selects a button.
'Each square on the tic tac toe board will have a boolean variable, when the square Is selected either by the user Or the A.I. that square's variable becomes true.
'When the user clicks on one of the 9 squares, it becomes an x .
'An A.I. will randomly Select squares To place an o On whenever the user selects a square, Or If the A.I. Is the starting player. To Do this a Loop will generate a random number between 0 And 8, Each number corresponding To a square until a square Is randomly selected that hasn't already been selected either by the user or the A.I.
'The player will win If any form Of 3 x's in a straight row is assembled.
'The player will lose If any form Of 3 o's in a straight row is assembled.
'To determine if a winning row Or draw has taken place, an if, Else if, statement will have conditions that require one of the winning, losing Or drawing formations to be present in order for a game ending code to execute.
'The game will be a draw If all squares are owned, but no player has a winning row.
'In order to make the game harder, the A.I. will prevent the user from winning the game in almost all positions. Similar to determining if a winning formation ais in place, if a winning position Is about to be in place, an o will be placed on the square the user would have won with.

Public Class TicTacToe


    Dim GameOver As Boolean = False
    Dim StartDecided As Boolean = False
    Dim AiStart As Boolean
    Dim SquaresPicked(8) As Boolean
    Dim randomnumber As Integer
    Dim ChoiceMade As Boolean = False
    Dim PreviouslySelected As Boolean = True
    Dim TopLeft As Boolean = True
    Dim TopMid As Boolean = True
    Dim TopRight As Boolean = True
    Dim MidLeft As Boolean = True
    Dim Mid As Boolean = True
    Dim MidRight As Boolean = True
    Dim BotLeft As Boolean = True
    Dim BotMid As Boolean = True
    Dim BotRight As Boolean = True
    Dim FirstTurnDone As Boolean = False

    Private Sub AiTurn()
        'If the A.I. sees that two x's are in a row in any position except when an x is on the
        'top right and bottom left, bottom right and middle, top left and bottom right or the 
        'bottomleft and middle tiles, it prevents the user from winning by placing an o on the winning tile.
        'If the user is not about to win in any position except those diagonal cases, the A.I. chooses a random tile to posess.
        If PicBoxTopLeft.Image.Height = 90 And PicBoxTopMid.Image.Height = 90 And TopRight = False Then
            PicBoxTopRight.Image = My.Resources.o
            TopRight = True
            WinnerCheck()
        ElseIf PicBoxTopRight.Image.Height = 90 And PicBoxTopMid.Image.Height = 90 And TopLeft = False Then
            PicBoxTopLeft.Image = My.Resources.o
            TopLeft = True
            WinnerCheck()
        ElseIf PicBoxTopRight.Image.Height = 90 And PicBoxTopLeft.Image.Height = 90 And TopMid = False Then
            PicBoxTopMid.Image = My.Resources.o
            TopMid = True
            WinnerCheck()
        ElseIf PicBoxMidRight.Image.Height = 90 And PicBoxMidLeft.Image.Height = 90 And Mid = False Then
            PicBoxMid.Image = My.Resources.o
            Mid = True
            WinnerCheck()
        ElseIf PicBoxMidRight.Image.Height = 90 And PicBoxMid.Image.Height = 90 And MidLeft = False Then
            PicBoxMidLeft.Image = My.Resources.o
            MidLeft = True
            WinnerCheck()
        ElseIf PicBoxMid.Image.Height = 90 And PicBoxMidLeft.Image.Height = 90 And MidRight = False Then
            PicBoxMidRight.Image = My.Resources.o
            MidRight = True
            WinnerCheck()
        ElseIf PicBoxBotRight.Image.Height = 90 And PicBoxBotLeft.Image.Height = 90 And BotMid = False Then
            PicBoxBotMid.Image = My.Resources.o
            BotMid = True
            WinnerCheck()
        ElseIf PicBoxBotRight.Image.Height = 90 And PicBoxBotMid.Image.Height = 90 And BotLeft = False Then
            PicBoxBotLeft.Image = My.Resources.o
            BotLeft = True
            WinnerCheck()
        ElseIf PicBoxBotMid.Image.Height = 90 And PicBoxBotLeft.Image.Height = 90 And BotRight = False Then
            PicBoxBotRight.Image = My.Resources.o
            BotRight = True
            WinnerCheck()
        ElseIf PicBoxTopRight.Image.Height = 90 And PicBoxMidRight.Image.Height = 90 And BotRight = False Then
            PicBoxBotRight.Image = My.Resources.o
            BotRight = True
        ElseIf PicBoxTopRight.Image.Height = 90 And PicBoxBotRight.Image.Height = 90 And MidRight = False Then
            PicBoxMidRight.Image = My.Resources.o
            MidRight = True
            WinnerCheck()
        ElseIf PicBoxMidRight.Image.Height = 90 And PicBoxBotRight.Image.Height = 90 And TopRight = False Then
            PicBoxTopRight.Image = My.Resources.o
            TopRight = True
            WinnerCheck()
        ElseIf PicBoxTopMid.Image.Height = 90 And PicBoxMid.Image.Height = 90 And BotMid = False Then
            PicBoxBotMid.Image = My.Resources.o
            BotMid = True
            WinnerCheck()
        ElseIf PicBoxTopMid.Image.Height = 90 And PicBoxBotMid.Image.Height = 90 And Mid = False Then
            PicBoxMid.Image = My.Resources.o
            Mid = True
            WinnerCheck()
        ElseIf PicBoxBotMid.Image.Height = 90 And PicBoxMid.Image.Height = 90 And TopMid = False Then
            PicBoxTopMid.Image = My.Resources.o
            TopMid = True
            WinnerCheck()
        ElseIf PicBoxTopLeft.Image.Height = 90 And PicBoxMidLeft.Image.Height = 90 And BotLeft = False Then
            PicBoxBotLeft.Image = My.Resources.o
            BotLeft = True
            WinnerCheck()
        ElseIf PicBoxMidLeft.Image.Height = 90 And PicBoxBotLeft.Image.Height = 90 And TopLeft = False Then
            PicBoxTopLeft.Image = My.Resources.o
            TopLeft = True
            WinnerCheck()
        ElseIf PicBoxTopLeft.Image.Height = 90 And PicBoxBotLeft.Image.Height = 90 And MidLeft = False Then
            PicBoxMidLeft.Image = My.Resources.o
            MidLeft = True
            WinnerCheck()
        ElseIf PicBoxTopLeft.Image.Height = 90 And PicBoxMid.Image.Height = 90 And BotRight = False Then
            PicBoxBotRight.Image = My.Resources.o
            BotRight = True
            WinnerCheck()
        ElseIf PicBoxTopRight.Image.Height = 90 And PicBoxMid.Image.Height = 90 And BotLeft = False Then
            PicBoxBotLeft.Image = My.Resources.o
            BotLeft = True
            WinnerCheck()

        Else
            PreviouslySelected = True
            Do While PreviouslySelected = True
                WinnerCheck()

                If (PicBoxTopRight.Image.Height >= 89 And PicBoxTopRight.Image.Height <= 90) And (PicBoxTopMid.Image.Height >= 89 And PicBoxTopMid.Image.Height <= 90) And (PicBoxTopLeft.Image.Height >= 89 And PicBoxTopLeft.Image.Height <= 90) And (PicBoxMidLeft.Image.Height >= 89 And PicBoxMidLeft.Image.Height <= 90) And (PicBoxMid.Image.Height >= 89 And PicBoxMid.Image.Height <= 90) And (PicBoxMidRight.Image.Height >= 89 And PicBoxMidRight.Image.Height <= 90) And (PicBoxBotLeft.Image.Height >= 89 And PicBoxBotLeft.Image.Height <= 90) And (PicBoxBotMid.Image.Height >= 89 And PicBoxBotMid.Image.Height <= 90) And (PicBoxBotRight.Image.Height >= 89 And PicBoxBotRight.Image.Height <= 90) Then
                    PreviouslySelected = False
                End If

                randomnumber = Int(9 * Rnd())

                SquaresPicked(randomnumber) = True

                If SquaresPicked(0) = True Then
                    SquaresPicked(0) = False
                    If TopLeft = False Then
                        PreviouslySelected = False
                        PicBoxTopLeft.Image = My.Resources.o
                        TopLeft = True
                    End If

                ElseIf SquaresPicked(1) = True Then
                    SquaresPicked(1) = False
                    If TopMid = False Then
                        PreviouslySelected = False
                        PicBoxTopMid.Image = My.Resources.o
                        TopMid = True
                    End If

                ElseIf SquaresPicked(2) = True Then
                    SquaresPicked(2) = False
                    If TopRight = False Then
                        PreviouslySelected = False
                        PicBoxTopRight.Image = My.Resources.o
                        TopRight = True
                    End If

                ElseIf SquaresPicked(3) = True Then
                    SquaresPicked(3) = False
                    If MidLeft = False Then
                        PreviouslySelected = False
                        PicBoxMidLeft.Image = My.Resources.o
                        MidLeft = True
                    End If

                ElseIf SquaresPicked(4) = True Then
                    SquaresPicked(4) = False
                    If Mid = False Then
                        PreviouslySelected = False
                        PicBoxMid.Image = My.Resources.o
                        Mid = True
                    End If

                ElseIf SquaresPicked(5) = True Then
                    SquaresPicked(5) = False
                    If MidRight = False Then
                        PreviouslySelected = False
                        PicBoxMidRight.Image = My.Resources.o
                        MidRight = True
                    End If

                ElseIf SquaresPicked(6) = True Then
                    SquaresPicked(6) = False
                    If BotLeft = False Then
                        PreviouslySelected = False
                        PicBoxBotLeft.Image = My.Resources.o
                        BotLeft = True
                    End If

                ElseIf SquaresPicked(7) = True Then
                    SquaresPicked(7) = False
                    If BotMid = False Then
                        PreviouslySelected = False
                        PicBoxBotMid.Image = My.Resources.o
                        BotMid = True
                    End If

                ElseIf SquaresPicked(8) = True Then
                    SquaresPicked(8) = False
                    If BotRight = False Then
                        PreviouslySelected = False
                        PicBoxBotRight.Image = My.Resources.o
                        BotRight = True
                    End If

                End If

            Loop
            WinnerCheck()
        End If
    End Sub


    Private Sub WinnerCheck()
        'the height of the x image is 90, the height of the o image is 89, the height of the default orange square is 91
        'This procedure determines if any winning, losing or drawing move has been made, if one of these moves have taken place, the corresponding message is displayed.
        If PicBoxTopLeft.Image.Height = 90 And PicBoxTopMid.Image.Height = 90 And PicBoxTopRight.Image.Height = 90 And GameOver = False Then
            MessageBox.Show("you win", "you win")
            Close()
            GameOver = True
            MainMenu.TicWin = True
        ElseIf PicBoxTopLeft.Image.Height = 89 And PicBoxTopMid.Image.Height = 89 And PicBoxTopRight.Image.Height = 89 And GameOver = False Then
            MessageBox.Show("you lose", "you lose")
            Close()
            GameOver = True
        ElseIf PicBoxMidLeft.Image.Height = 90 And PicBoxMid.Image.Height = 90 And PicBoxMidRight.Image.Height = 90 And GameOver = False Then
            MessageBox.Show("you win", "you win")
            Close()
            GameOver = True
            MainMenu.TicWin = True
        ElseIf PicBoxMidLeft.Image.Height = 89 And PicBoxMid.Image.Height = 89 And PicBoxMidRight.Image.Height = 89 And GameOver = False Then
            MessageBox.Show("you lose", "you lose")
            Close()
            GameOver = True
        ElseIf PicBoxBotLeft.Image.Height = 90 And PicBoxBotMid.Image.Height = 90 And PicBoxBotRight.Image.Height = 90 And GameOver = False Then
            MessageBox.Show("you win", "you win")
            Close()
            GameOver = True
            MainMenu.TicWin = True
        ElseIf PicBoxBotLeft.Image.Height = 89 And PicBoxBotMid.Image.Height = 89 And PicBoxBotRight.Image.Height = 89 And GameOver = False Then
            MessageBox.Show("you lose", "you lose")
            Close()
            GameOver = True
        ElseIf PicBoxTopLeft.Image.Height = 90 And PicBoxMidLeft.Image.Height = 90 And PicBoxBotLeft.Image.Height = 90 And GameOver = False Then
            MessageBox.Show("you win", "you win")
            Close()
            GameOver = True
            MainMenu.TicWin = True
        ElseIf PicBoxTopLeft.Image.Height = 89 And PicBoxMidLeft.Image.Height = 89 And PicBoxBotLeft.Image.Height = 89 And GameOver = False Then
            MessageBox.Show("you lose", "you lose")
            Close()
            GameOver = True
        ElseIf PicBoxTopMid.Image.Height = 90 And PicBoxMid.Image.Height = 90 And PicBoxBotMid.Image.Height = 90 And GameOver = False Then
            MessageBox.Show("you win", "you win")
            Close()
            GameOver = True
            MainMenu.TicWin = True
        ElseIf PicBoxTopMid.Image.Height = 89 And PicBoxMid.Image.Height = 89 And PicBoxBotMid.Image.Height = 89 And GameOver = False Then
            MessageBox.Show("you lose", "you lose")
            Close()
            GameOver = True
        ElseIf PicBoxTopRight.Image.Height = 90 And PicBoxMidRight.Image.Height = 90 And PicBoxBotRight.Image.Height = 90 And GameOver = False Then
            MessageBox.Show("you win", "you win")
            Close()
            GameOver = True
            MainMenu.TicWin = True
        ElseIf PicBoxTopRight.Image.Height = 89 And PicBoxMidRight.Image.Height = 89 And PicBoxBotRight.Image.Height = 89 And GameOver = False Then
            MessageBox.Show("you lose", "you lose")
            Close()
            GameOver = True
        ElseIf PicBoxTopRight.Image.Height = 90 And PicBoxMid.Image.Height = 90 And PicBoxBotLeft.Image.Height = 90 And GameOver = False Then
            MessageBox.Show("you win", "you win")
            Close()
            GameOver = True
            MainMenu.TicWin = True
        ElseIf PicBoxTopRight.Image.Height = 89 And PicBoxMid.Image.Height = 89 And PicBoxBotLeft.Image.Height = 89 And GameOver = False Then
            MessageBox.Show("you lose", "you lose")
            Close()
            GameOver = True
        ElseIf PicBoxTopLeft.Image.Height = 90 And PicBoxMid.Image.Height = 90 And PicBoxBotRight.Image.Height = 90 And GameOver = False Then
            MessageBox.Show("you win", "you win")
            Close()
            GameOver = True
            MainMenu.TicWin = True
        ElseIf PicBoxTopLeft.Image.Height = 90 And PicBoxMid.Image.Height = 90 And PicBoxBotRight.Image.Height = 90 And GameOver = False Then
            MessageBox.Show("you lose", "you lose")
            Close()
            GameOver = True
        ElseIf (PicBoxTopRight.Image.Height >= 89 And PicBoxTopRight.Image.Height <= 90) And (PicBoxTopMid.Image.Height >= 89 And PicBoxTopMid.Image.Height <= 90) And (PicBoxTopLeft.Image.Height >= 89 And PicBoxTopLeft.Image.Height <= 90) And (PicBoxMidLeft.Image.Height >= 89 And PicBoxMidLeft.Image.Height <= 90) And (PicBoxMid.Image.Height >= 89 And PicBoxMid.Image.Height <= 90) And (PicBoxMidRight.Image.Height >= 89 And PicBoxMidRight.Image.Height <= 90) And (PicBoxBotLeft.Image.Height >= 89 And PicBoxBotLeft.Image.Height <= 90) And (PicBoxBotMid.Image.Height >= 89 And PicBoxBotMid.Image.Height <= 90) And (PicBoxBotRight.Image.Height >= 89 And PicBoxBotRight.Image.Height <= 90) And GameOver = False Then
            MessageBox.Show("Draw", "Draw")
            Close()
            GameOver = True
        End If
    End Sub



    Private Sub BtnCoinToss_Click(sender As System.Object, e As System.EventArgs) Handles BtnCoinToss.Click
        Randomize()
        Dim coin As Double
        CoinToss(coin)
        Select Case coin
            Case Is > 0.5
                If StartDecided = False Then
                    Me.Label1.Text = "you start"
                    StartDecided = True
                    AiStart = False
                End If


            Case Is < 0.5
                If StartDecided = False Then
                    Me.Label1.Text = "A.I. starts"
                    StartDecided = True
                    AiStart = True
                End If


        End Select

        BtnCoinToss.Visible = False
        BtnStart.Visible = True

    End Sub
    Function CoinToss(ByRef coin As Double)
        Randomize()
        coin = Rnd()
        Return coin
    End Function

    Private Sub BtnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BtnStart.Click
        Randomize()

        GroupBox1.Visible = True
        picboxOrange.Visible = True
        picboxGreen.Visible = True
        picboxMagenta.Visible = True
        RdbtnGreen.Visible = True
        rdbtnorange.Visible = True


        randomnumber = Int(9 * Rnd())



        If AiStart = True And FirstTurnDone = False Then
            TopLeft = False
            TopMid = False
            TopRight = False
            MidLeft = False
            Mid = False
            MidRight = False
            BotLeft = False
            BotMid = False
            BotRight = False
            FirstTurnDone = True

            Do While PreviouslySelected = True


                SquaresPicked(randomnumber) = True
                If SquaresPicked(0) = True Then

                    If TopLeft = False Then
                        PreviouslySelected = False
                        PicBoxTopLeft.Image = My.Resources.o
                        TopLeft = True
                    End If



                ElseIf SquaresPicked(1) = True Then
                    If TopMid = False Then
                        PreviouslySelected = False
                        PicBoxTopMid.Image = My.Resources.o
                        TopMid = True
                    End If


                ElseIf SquaresPicked(2) = True Then

                    If TopRight = False Then
                        PreviouslySelected = False
                        PicBoxTopRight.Image = My.Resources.o
                        TopRight = True
                    End If


                ElseIf SquaresPicked(3) = True Then

                    If MidLeft = False Then
                        PreviouslySelected = False
                        PicBoxMidLeft.Image = My.Resources.o
                        MidLeft = True
                    End If

                ElseIf SquaresPicked(4) = True Then
                    If Mid = False Then
                        PreviouslySelected = False
                        Mid = True
                        PicBoxMid.Image = My.Resources.o
                    End If


                ElseIf SquaresPicked(5) = True Then
                    If MidRight = False Then
                        PreviouslySelected = False
                        PicBoxMidRight.Image = My.Resources.o
                        MidRight = True
                    End If


                ElseIf SquaresPicked(6) = True Then
                    If BotLeft = False Then
                        PreviouslySelected = False
                        PicBoxBotLeft.Image = My.Resources.o
                        BotLeft = True
                    End If


                ElseIf SquaresPicked(7) = True Then
                    If BotMid = False Then
                        PreviouslySelected = False
                        PicBoxBotMid.Image = My.Resources.o
                        BotMid = True
                    End If


                ElseIf SquaresPicked(8) = True Then
                    If BotRight = False Then
                        PreviouslySelected = False
                        PicBoxBotRight.Image = My.Resources.o
                        BotRight = True
                    End If


                End If
            Loop
        ElseIf AiStart = False Then
            TopLeft = False
            TopMid = False
            TopRight = False
            MidLeft = False
            Mid = False
            MidRight = False
            BotLeft = False
            BotMid = False
            BotRight = False
            FirstTurnDone = True
        End If

        BtnStart.Visible = False


    End Sub

    Private Sub PicBoxTopLeft_Click(sender As System.Object, e As System.EventArgs) Handles PicBoxTopLeft.Click
        Randomize()
        If TopLeft = False Then
            PicBoxTopLeft.Image = My.Resources.x
            TopLeft = True
            WinnerCheck()
            AiTurn()
        End If
    End Sub

    Private Sub PicBoxTopMid_Click(sender As System.Object, e As System.EventArgs) Handles PicBoxTopMid.Click
        Randomize()
        If TopMid = False Then
            PicBoxTopMid.Image = My.Resources.x
            TopMid = True
            WinnerCheck()
            AiTurn()
        End If
    End Sub

    Private Sub PicBoxTopRight_Click(sender As System.Object, e As System.EventArgs) Handles PicBoxTopRight.Click
        Randomize()
        If TopRight = False Then
            PicBoxTopRight.Image = My.Resources.x
            TopRight = True
            WinnerCheck()
            AiTurn()
        End If
    End Sub

    Private Sub PicBoxMidLeft_Click(sender As System.Object, e As System.EventArgs) Handles PicBoxMidLeft.Click
        Randomize()
        If MidLeft = False Then
            PicBoxMidLeft.Image = My.Resources.x
            MidLeft = True
            WinnerCheck()
            AiTurn()
        End If
        WinnerCheck()
    End Sub

    Private Sub PicBoxMid_Click(sender As System.Object, e As System.EventArgs) Handles PicBoxMid.Click
        Randomize()
        If Mid = False Then
            PicBoxMid.Image = My.Resources.x
            Mid = True
            WinnerCheck()
            AiTurn()
            WinnerCheck()
        End If
    End Sub

    Private Sub PicBoxMidRight_Click(sender As System.Object, e As System.EventArgs) Handles PicBoxMidRight.Click
        Randomize()
        If MidRight = False Then
            PicBoxMidRight.Image = My.Resources.x
            MidRight = True
            WinnerCheck()
            AiTurn()
            WinnerCheck()
        End If
    End Sub

    Private Sub PicBoxBotLeft_Click(sender As System.Object, e As System.EventArgs) Handles PicBoxBotLeft.Click
        Randomize()
        If BotLeft = False Then
            PicBoxBotLeft.Image = My.Resources.x
            BotLeft = True
            WinnerCheck()
            AiTurn()
            WinnerCheck()
        End If
    End Sub

    Private Sub PicBoxBotMid_Click(sender As System.Object, e As System.EventArgs) Handles PicBoxBotMid.Click
        Randomize()
        If BotMid = False Then
            PicBoxBotMid.Image = My.Resources.x
            BotMid = True
            WinnerCheck()
            AiTurn()
            WinnerCheck()
        End If
    End Sub

    Private Sub PicBoxBotRight_Click(sender As System.Object, e As System.EventArgs) Handles PicBoxBotRight.Click
        Randomize()
        If BotRight = False Then
            PicBoxBotRight.Image = My.Resources.x
            BotRight = True
            WinnerCheck()
            AiTurn()
            WinnerCheck()
        End If
    End Sub


    Private Sub Form1_Load(sender As Object, e As EventArgs) Handles MyBase.Load

    End Sub

    Private Sub RdbtnOrange_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles rdbtnorange.CheckedChanged

        If TopLeft = False Then
            PicBoxTopLeft.Image = My.Resources.orangebox
        End If
        If TopMid = False Then
            PicBoxTopMid.Image = My.Resources.orangebox
        End If
        If TopRight = False Then
            PicBoxTopRight.Image = My.Resources.orangebox
        End If
        If MidLeft = False Then
            PicBoxMidLeft.Image = My.Resources.orangebox
        End If
        If Mid = False Then
            PicBoxMid.Image = My.Resources.orangebox
        End If
        If MidRight = False Then
            PicBoxMidRight.Image = My.Resources.orangebox
        End If
        If BotLeft = False Then
            PicBoxBotLeft.Image = My.Resources.orangebox
        End If
        If BotMid = False Then
            PicBoxBotMid.Image = My.Resources.orangebox
        End If
        If BotRight = False Then
            PicBoxBotRight.Image = My.Resources.orangebox
        End If


    End Sub

    Private Sub RadioButton1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RdbtnGreen.CheckedChanged
        If TopLeft = False Then
            PicBoxTopLeft.Image = My.Resources.Green
        End If
        If TopMid = False Then
            PicBoxTopMid.Image = My.Resources.Green
        End If
        If TopRight = False Then
            PicBoxTopRight.Image = My.Resources.Green
        End If
        If MidLeft = False Then
            PicBoxMidLeft.Image = My.Resources.Green
        End If
        If Mid = False Then
            PicBoxMid.Image = My.Resources.Green
        End If
        If MidRight = False Then
            PicBoxMidRight.Image = My.Resources.Green
        End If
        If BotLeft = False Then
            PicBoxBotLeft.Image = My.Resources.Green
        End If
        If BotMid = False Then
            PicBoxBotMid.Image = My.Resources.Green
        End If
        If BotRight = False Then
            PicBoxBotRight.Image = My.Resources.Green
        End If
    End Sub

    Private Sub RadioButton2_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RdbtnMagenta.CheckedChanged
        If TopLeft = False Then
            PicBoxTopLeft.Image = My.Resources.Magenta
        End If
        If TopMid = False Then
            PicBoxTopMid.Image = My.Resources.Magenta
        End If
        If TopRight = False Then
            PicBoxTopRight.Image = My.Resources.Magenta
        End If
        If MidLeft = False Then
            PicBoxMidLeft.Image = My.Resources.Magenta
        End If
        If Mid = False Then
            PicBoxMid.Image = My.Resources.Magenta
        End If
        If MidRight = False Then
            PicBoxMidRight.Image = My.Resources.Magenta
        End If
        If BotLeft = False Then
            PicBoxBotLeft.Image = My.Resources.Magenta
        End If
        If BotMid = False Then
            PicBoxBotMid.Image = My.Resources.Magenta
        End If
        If BotRight = False Then
            PicBoxBotRight.Image = My.Resources.Magenta
        End If
    End Sub
End Class