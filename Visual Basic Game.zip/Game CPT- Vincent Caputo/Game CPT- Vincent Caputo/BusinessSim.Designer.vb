﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BusinessSim
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.HelpToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.InstructionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.btnLemonade = New System.Windows.Forms.Button()
        Me.btnUpgradeLemonade = New System.Windows.Forms.Button()
        Me.radLem1 = New System.Windows.Forms.RadioButton()
        Me.radLem5 = New System.Windows.Forms.RadioButton()
        Me.lblPrompt = New System.Windows.Forms.Label()
        Me.lblMoney = New System.Windows.Forms.Label()
        Me.grpLemUpgrade = New System.Windows.Forms.GroupBox()
        Me.radLem10 = New System.Windows.Forms.RadioButton()
        Me.btnHireLem = New System.Windows.Forms.Button()
        Me.tmrLemonade = New System.Windows.Forms.Timer(Me.components)
        Me.tmrUpgradeLem = New System.Windows.Forms.Timer(Me.components)
        Me.lblPrompt2 = New System.Windows.Forms.Label()
        Me.lblLemProfit = New System.Windows.Forms.Label()
        Me.lblLemUpgradeCost = New System.Windows.Forms.Label()
        Me.lblLemCostUpgrade = New System.Windows.Forms.Label()
        Me.tmrLemWorker = New System.Windows.Forms.Timer(Me.components)
        Me.btnDeliver = New System.Windows.Forms.Button()
        Me.btnUpgradeNewspaper = New System.Windows.Forms.Button()
        Me.btnBuyNewspaper = New System.Windows.Forms.Button()
        Me.btnHirePaperWorker = New System.Windows.Forms.Button()
        Me.radPaper1 = New System.Windows.Forms.RadioButton()
        Me.radPaper5 = New System.Windows.Forms.RadioButton()
        Me.radPaper10 = New System.Windows.Forms.RadioButton()
        Me.lblPrrompt3 = New System.Windows.Forms.Label()
        Me.lblPaperProfit = New System.Windows.Forms.Label()
        Me.lblUpgradePaper = New System.Windows.Forms.Label()
        Me.lblPapeUpCost = New System.Windows.Forms.Label()
        Me.grpPaperUpgrade = New System.Windows.Forms.GroupBox()
        Me.tmrDeliver = New System.Windows.Forms.Timer(Me.components)
        Me.tmrUpgradePaper = New System.Windows.Forms.Timer(Me.components)
        Me.tmrPaperWorker = New System.Windows.Forms.Timer(Me.components)
        Me.btnDonutShop = New System.Windows.Forms.Button()
        Me.btnUpgradeDonut = New System.Windows.Forms.Button()
        Me.lblPrompt4 = New System.Windows.Forms.Label()
        Me.lblDonutProfit = New System.Windows.Forms.Label()
        Me.lblDonutUpgr = New System.Windows.Forms.Label()
        Me.lblDonutUpCost = New System.Windows.Forms.Label()
        Me.btnBuyDonut = New System.Windows.Forms.Button()
        Me.grpDonutShop = New System.Windows.Forms.GroupBox()
        Me.radDonut10 = New System.Windows.Forms.RadioButton()
        Me.radDonut5 = New System.Windows.Forms.RadioButton()
        Me.radDonut1 = New System.Windows.Forms.RadioButton()
        Me.btnHireDonutWorker = New System.Windows.Forms.Button()
        Me.tmrDonut = New System.Windows.Forms.Timer(Me.components)
        Me.tmrDonutUpg = New System.Windows.Forms.Timer(Me.components)
        Me.btnRetire = New System.Windows.Forms.Button()
        Me.MenuStrip1.SuspendLayout()
        Me.grpLemUpgrade.SuspendLayout()
        Me.grpPaperUpgrade.SuspendLayout()
        Me.grpDonutShop.SuspendLayout()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.BackColor = System.Drawing.Color.Red
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.HelpToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(598, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "+"
        '
        'HelpToolStripMenuItem
        '
        Me.HelpToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.InstructionsToolStripMenuItem})
        Me.HelpToolStripMenuItem.Name = "HelpToolStripMenuItem"
        Me.HelpToolStripMenuItem.Size = New System.Drawing.Size(44, 20)
        Me.HelpToolStripMenuItem.Text = "Help"
        '
        'InstructionsToolStripMenuItem
        '
        Me.InstructionsToolStripMenuItem.Name = "InstructionsToolStripMenuItem"
        Me.InstructionsToolStripMenuItem.Size = New System.Drawing.Size(152, 22)
        Me.InstructionsToolStripMenuItem.Text = "Instructions"
        '
        'btnLemonade
        '
        Me.btnLemonade.BackColor = System.Drawing.Color.LightBlue
        Me.btnLemonade.ForeColor = System.Drawing.Color.Red
        Me.btnLemonade.Location = New System.Drawing.Point(12, 63)
        Me.btnLemonade.Name = "btnLemonade"
        Me.btnLemonade.Size = New System.Drawing.Size(75, 23)
        Me.btnLemonade.TabIndex = 1
        Me.btnLemonade.Text = "Lemonade"
        Me.btnLemonade.UseVisualStyleBackColor = False
        '
        'btnUpgradeLemonade
        '
        Me.btnUpgradeLemonade.BackColor = System.Drawing.Color.LightBlue
        Me.btnUpgradeLemonade.ForeColor = System.Drawing.Color.Red
        Me.btnUpgradeLemonade.Location = New System.Drawing.Point(93, 63)
        Me.btnUpgradeLemonade.Name = "btnUpgradeLemonade"
        Me.btnUpgradeLemonade.Size = New System.Drawing.Size(119, 23)
        Me.btnUpgradeLemonade.TabIndex = 2
        Me.btnUpgradeLemonade.Text = "Upgrade Lemonade"
        Me.btnUpgradeLemonade.UseVisualStyleBackColor = False
        '
        'radLem1
        '
        Me.radLem1.AutoSize = True
        Me.radLem1.Checked = True
        Me.radLem1.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radLem1.ForeColor = System.Drawing.Color.Indigo
        Me.radLem1.Location = New System.Drawing.Point(15, 13)
        Me.radLem1.Name = "radLem1"
        Me.radLem1.Size = New System.Drawing.Size(42, 17)
        Me.radLem1.TabIndex = 3
        Me.radLem1.TabStop = True
        Me.radLem1.Text = "x 1"
        Me.radLem1.UseVisualStyleBackColor = True
        '
        'radLem5
        '
        Me.radLem5.AutoSize = True
        Me.radLem5.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radLem5.ForeColor = System.Drawing.Color.Indigo
        Me.radLem5.Location = New System.Drawing.Point(60, 13)
        Me.radLem5.Name = "radLem5"
        Me.radLem5.Size = New System.Drawing.Size(42, 17)
        Me.radLem5.TabIndex = 4
        Me.radLem5.Text = "x 5"
        Me.radLem5.UseVisualStyleBackColor = True
        '
        'lblPrompt
        '
        Me.lblPrompt.AutoSize = True
        Me.lblPrompt.BackColor = System.Drawing.Color.LimeGreen
        Me.lblPrompt.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrompt.ForeColor = System.Drawing.Color.DarkGreen
        Me.lblPrompt.Location = New System.Drawing.Point(3, 34)
        Me.lblPrompt.Name = "lblPrompt"
        Me.lblPrompt.Size = New System.Drawing.Size(109, 25)
        Me.lblPrompt.TabIndex = 6
        Me.lblPrompt.Text = "Money: $"
        '
        'lblMoney
        '
        Me.lblMoney.AutoSize = True
        Me.lblMoney.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMoney.ForeColor = System.Drawing.Color.Red
        Me.lblMoney.Location = New System.Drawing.Point(91, 34)
        Me.lblMoney.Name = "lblMoney"
        Me.lblMoney.Size = New System.Drawing.Size(0, 25)
        Me.lblMoney.TabIndex = 7
        '
        'grpLemUpgrade
        '
        Me.grpLemUpgrade.BackColor = System.Drawing.Color.Transparent
        Me.grpLemUpgrade.Controls.Add(Me.radLem10)
        Me.grpLemUpgrade.Controls.Add(Me.radLem5)
        Me.grpLemUpgrade.Controls.Add(Me.radLem1)
        Me.grpLemUpgrade.ForeColor = System.Drawing.SystemColors.ControlLight
        Me.grpLemUpgrade.Location = New System.Drawing.Point(257, 53)
        Me.grpLemUpgrade.Name = "grpLemUpgrade"
        Me.grpLemUpgrade.Size = New System.Drawing.Size(159, 40)
        Me.grpLemUpgrade.TabIndex = 8
        Me.grpLemUpgrade.TabStop = False
        '
        'radLem10
        '
        Me.radLem10.AutoSize = True
        Me.radLem10.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.radLem10.ForeColor = System.Drawing.Color.Indigo
        Me.radLem10.Location = New System.Drawing.Point(105, 13)
        Me.radLem10.Name = "radLem10"
        Me.radLem10.Size = New System.Drawing.Size(49, 17)
        Me.radLem10.TabIndex = 5
        Me.radLem10.Text = "x 10"
        Me.radLem10.UseVisualStyleBackColor = True
        '
        'btnHireLem
        '
        Me.btnHireLem.BackColor = System.Drawing.Color.LightBlue
        Me.btnHireLem.ForeColor = System.Drawing.Color.Red
        Me.btnHireLem.Location = New System.Drawing.Point(422, 63)
        Me.btnHireLem.Name = "btnHireLem"
        Me.btnHireLem.Size = New System.Drawing.Size(119, 23)
        Me.btnHireLem.TabIndex = 9
        Me.btnHireLem.Text = "Hire Worker ($500)"
        Me.btnHireLem.UseVisualStyleBackColor = False
        '
        'tmrLemonade
        '
        Me.tmrLemonade.Enabled = True
        Me.tmrLemonade.Interval = 600
        '
        'tmrUpgradeLem
        '
        Me.tmrUpgradeLem.Enabled = True
        Me.tmrUpgradeLem.Interval = 600
        '
        'lblPrompt2
        '
        Me.lblPrompt2.AutoSize = True
        Me.lblPrompt2.BackColor = System.Drawing.Color.Transparent
        Me.lblPrompt2.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrompt2.ForeColor = System.Drawing.Color.Orange
        Me.lblPrompt2.Location = New System.Drawing.Point(20, 89)
        Me.lblPrompt2.Name = "lblPrompt2"
        Me.lblPrompt2.Size = New System.Drawing.Size(14, 13)
        Me.lblPrompt2.TabIndex = 10
        Me.lblPrompt2.Text = "+"
        '
        'lblLemProfit
        '
        Me.lblLemProfit.AutoSize = True
        Me.lblLemProfit.BackColor = System.Drawing.Color.Transparent
        Me.lblLemProfit.ForeColor = System.Drawing.Color.Orange
        Me.lblLemProfit.Location = New System.Drawing.Point(39, 89)
        Me.lblLemProfit.Name = "lblLemProfit"
        Me.lblLemProfit.Size = New System.Drawing.Size(0, 13)
        Me.lblLemProfit.TabIndex = 11
        '
        'lblLemUpgradeCost
        '
        Me.lblLemUpgradeCost.AutoSize = True
        Me.lblLemUpgradeCost.BackColor = System.Drawing.Color.Transparent
        Me.lblLemUpgradeCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblLemUpgradeCost.ForeColor = System.Drawing.Color.Orange
        Me.lblLemUpgradeCost.Location = New System.Drawing.Point(93, 89)
        Me.lblLemUpgradeCost.Name = "lblLemUpgradeCost"
        Me.lblLemUpgradeCost.Size = New System.Drawing.Size(99, 13)
        Me.lblLemUpgradeCost.TabIndex = 12
        Me.lblLemUpgradeCost.Text = "Upgrade Cost: $"
        '
        'lblLemCostUpgrade
        '
        Me.lblLemCostUpgrade.AutoSize = True
        Me.lblLemCostUpgrade.BackColor = System.Drawing.Color.Transparent
        Me.lblLemCostUpgrade.ForeColor = System.Drawing.Color.Orange
        Me.lblLemCostUpgrade.Location = New System.Drawing.Point(173, 89)
        Me.lblLemCostUpgrade.Name = "lblLemCostUpgrade"
        Me.lblLemCostUpgrade.Size = New System.Drawing.Size(0, 13)
        Me.lblLemCostUpgrade.TabIndex = 13
        '
        'tmrLemWorker
        '
        Me.tmrLemWorker.Interval = 1000
        '
        'btnDeliver
        '
        Me.btnDeliver.BackColor = System.Drawing.Color.LightBlue
        Me.btnDeliver.ForeColor = System.Drawing.Color.Red
        Me.btnDeliver.Location = New System.Drawing.Point(12, 105)
        Me.btnDeliver.Name = "btnDeliver"
        Me.btnDeliver.Size = New System.Drawing.Size(75, 23)
        Me.btnDeliver.TabIndex = 14
        Me.btnDeliver.Text = "Deliver"
        Me.btnDeliver.UseVisualStyleBackColor = False
        Me.btnDeliver.Visible = False
        '
        'btnUpgradeNewspaper
        '
        Me.btnUpgradeNewspaper.BackColor = System.Drawing.Color.LightBlue
        Me.btnUpgradeNewspaper.ForeColor = System.Drawing.Color.Red
        Me.btnUpgradeNewspaper.Location = New System.Drawing.Point(93, 105)
        Me.btnUpgradeNewspaper.Name = "btnUpgradeNewspaper"
        Me.btnUpgradeNewspaper.Size = New System.Drawing.Size(119, 23)
        Me.btnUpgradeNewspaper.TabIndex = 15
        Me.btnUpgradeNewspaper.Text = "Upgrade Newspaper"
        Me.btnUpgradeNewspaper.UseVisualStyleBackColor = False
        Me.btnUpgradeNewspaper.Visible = False
        '
        'btnBuyNewspaper
        '
        Me.btnBuyNewspaper.BackColor = System.Drawing.Color.LightBlue
        Me.btnBuyNewspaper.ForeColor = System.Drawing.Color.Indigo
        Me.btnBuyNewspaper.Location = New System.Drawing.Point(15, 105)
        Me.btnBuyNewspaper.Name = "btnBuyNewspaper"
        Me.btnBuyNewspaper.Size = New System.Drawing.Size(526, 23)
        Me.btnBuyNewspaper.TabIndex = 16
        Me.btnBuyNewspaper.Text = "Buy Newspaper Route ($10000)"
        Me.btnBuyNewspaper.UseVisualStyleBackColor = False
        '
        'btnHirePaperWorker
        '
        Me.btnHirePaperWorker.BackColor = System.Drawing.Color.LightBlue
        Me.btnHirePaperWorker.ForeColor = System.Drawing.Color.Red
        Me.btnHirePaperWorker.Location = New System.Drawing.Point(422, 105)
        Me.btnHirePaperWorker.Name = "btnHirePaperWorker"
        Me.btnHirePaperWorker.Size = New System.Drawing.Size(119, 23)
        Me.btnHirePaperWorker.TabIndex = 17
        Me.btnHirePaperWorker.Text = "Hire Worker ($25K)"
        Me.btnHirePaperWorker.UseVisualStyleBackColor = False
        Me.btnHirePaperWorker.Visible = False
        '
        'radPaper1
        '
        Me.radPaper1.AutoSize = True
        Me.radPaper1.Checked = True
        Me.radPaper1.Location = New System.Drawing.Point(2, 11)
        Me.radPaper1.Name = "radPaper1"
        Me.radPaper1.Size = New System.Drawing.Size(42, 17)
        Me.radPaper1.TabIndex = 18
        Me.radPaper1.TabStop = True
        Me.radPaper1.Text = "x 1"
        Me.radPaper1.UseVisualStyleBackColor = True
        Me.radPaper1.Visible = False
        '
        'radPaper5
        '
        Me.radPaper5.AutoSize = True
        Me.radPaper5.Location = New System.Drawing.Point(47, 11)
        Me.radPaper5.Name = "radPaper5"
        Me.radPaper5.Size = New System.Drawing.Size(42, 17)
        Me.radPaper5.TabIndex = 19
        Me.radPaper5.Text = "x 5"
        Me.radPaper5.UseVisualStyleBackColor = True
        Me.radPaper5.Visible = False
        '
        'radPaper10
        '
        Me.radPaper10.AutoSize = True
        Me.radPaper10.Location = New System.Drawing.Point(92, 11)
        Me.radPaper10.Name = "radPaper10"
        Me.radPaper10.Size = New System.Drawing.Size(49, 17)
        Me.radPaper10.TabIndex = 20
        Me.radPaper10.Text = "x 10"
        Me.radPaper10.UseVisualStyleBackColor = True
        Me.radPaper10.Visible = False
        '
        'lblPrrompt3
        '
        Me.lblPrrompt3.AutoSize = True
        Me.lblPrrompt3.BackColor = System.Drawing.Color.Transparent
        Me.lblPrrompt3.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrrompt3.ForeColor = System.Drawing.Color.Orange
        Me.lblPrrompt3.Location = New System.Drawing.Point(26, 134)
        Me.lblPrrompt3.Name = "lblPrrompt3"
        Me.lblPrrompt3.Size = New System.Drawing.Size(14, 13)
        Me.lblPrrompt3.TabIndex = 21
        Me.lblPrrompt3.Text = "+"
        Me.lblPrrompt3.Visible = False
        '
        'lblPaperProfit
        '
        Me.lblPaperProfit.AutoSize = True
        Me.lblPaperProfit.BackColor = System.Drawing.Color.Transparent
        Me.lblPaperProfit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPaperProfit.ForeColor = System.Drawing.Color.Orange
        Me.lblPaperProfit.Location = New System.Drawing.Point(39, 134)
        Me.lblPaperProfit.Name = "lblPaperProfit"
        Me.lblPaperProfit.Size = New System.Drawing.Size(0, 13)
        Me.lblPaperProfit.TabIndex = 22
        Me.lblPaperProfit.Visible = False
        '
        'lblUpgradePaper
        '
        Me.lblUpgradePaper.AutoSize = True
        Me.lblUpgradePaper.BackColor = System.Drawing.Color.Transparent
        Me.lblUpgradePaper.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblUpgradePaper.ForeColor = System.Drawing.Color.Orange
        Me.lblUpgradePaper.Location = New System.Drawing.Point(93, 131)
        Me.lblUpgradePaper.Name = "lblUpgradePaper"
        Me.lblUpgradePaper.Size = New System.Drawing.Size(99, 13)
        Me.lblUpgradePaper.TabIndex = 23
        Me.lblUpgradePaper.Text = "Upgrade Cost: $"
        Me.lblUpgradePaper.Visible = False
        '
        'lblPapeUpCost
        '
        Me.lblPapeUpCost.AutoSize = True
        Me.lblPapeUpCost.BackColor = System.Drawing.Color.Transparent
        Me.lblPapeUpCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPapeUpCost.ForeColor = System.Drawing.Color.Orange
        Me.lblPapeUpCost.Location = New System.Drawing.Point(212, 136)
        Me.lblPapeUpCost.Name = "lblPapeUpCost"
        Me.lblPapeUpCost.Size = New System.Drawing.Size(0, 13)
        Me.lblPapeUpCost.TabIndex = 24
        Me.lblPapeUpCost.Visible = False
        '
        'grpPaperUpgrade
        '
        Me.grpPaperUpgrade.BackColor = System.Drawing.Color.Transparent
        Me.grpPaperUpgrade.Controls.Add(Me.radPaper10)
        Me.grpPaperUpgrade.Controls.Add(Me.radPaper5)
        Me.grpPaperUpgrade.Controls.Add(Me.radPaper1)
        Me.grpPaperUpgrade.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpPaperUpgrade.ForeColor = System.Drawing.Color.Indigo
        Me.grpPaperUpgrade.Location = New System.Drawing.Point(265, 99)
        Me.grpPaperUpgrade.Name = "grpPaperUpgrade"
        Me.grpPaperUpgrade.Size = New System.Drawing.Size(151, 35)
        Me.grpPaperUpgrade.TabIndex = 25
        Me.grpPaperUpgrade.TabStop = False
        Me.grpPaperUpgrade.Visible = False
        '
        'tmrDeliver
        '
        Me.tmrDeliver.Enabled = True
        Me.tmrDeliver.Interval = 600
        '
        'tmrUpgradePaper
        '
        Me.tmrUpgradePaper.Enabled = True
        Me.tmrUpgradePaper.Interval = 650
        '
        'tmrPaperWorker
        '
        Me.tmrPaperWorker.Interval = 1000
        '
        'btnDonutShop
        '
        Me.btnDonutShop.BackColor = System.Drawing.Color.LightBlue
        Me.btnDonutShop.Location = New System.Drawing.Point(12, 151)
        Me.btnDonutShop.Name = "btnDonutShop"
        Me.btnDonutShop.Size = New System.Drawing.Size(75, 23)
        Me.btnDonutShop.TabIndex = 26
        Me.btnDonutShop.Text = "Donut Shop"
        Me.btnDonutShop.UseVisualStyleBackColor = False
        Me.btnDonutShop.Visible = False
        '
        'btnUpgradeDonut
        '
        Me.btnUpgradeDonut.BackColor = System.Drawing.Color.LightBlue
        Me.btnUpgradeDonut.Location = New System.Drawing.Point(93, 151)
        Me.btnUpgradeDonut.Name = "btnUpgradeDonut"
        Me.btnUpgradeDonut.Size = New System.Drawing.Size(119, 23)
        Me.btnUpgradeDonut.TabIndex = 27
        Me.btnUpgradeDonut.Text = "Upgrade Donut Shop"
        Me.btnUpgradeDonut.UseVisualStyleBackColor = False
        Me.btnUpgradeDonut.Visible = False
        '
        'lblPrompt4
        '
        Me.lblPrompt4.AutoSize = True
        Me.lblPrompt4.BackColor = System.Drawing.Color.Transparent
        Me.lblPrompt4.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrompt4.ForeColor = System.Drawing.Color.Orange
        Me.lblPrompt4.Location = New System.Drawing.Point(12, 177)
        Me.lblPrompt4.Name = "lblPrompt4"
        Me.lblPrompt4.Size = New System.Drawing.Size(14, 13)
        Me.lblPrompt4.TabIndex = 28
        Me.lblPrompt4.Text = "+"
        Me.lblPrompt4.Visible = False
        '
        'lblDonutProfit
        '
        Me.lblDonutProfit.AutoSize = True
        Me.lblDonutProfit.BackColor = System.Drawing.Color.Transparent
        Me.lblDonutProfit.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDonutProfit.ForeColor = System.Drawing.Color.Orange
        Me.lblDonutProfit.Location = New System.Drawing.Point(26, 177)
        Me.lblDonutProfit.Name = "lblDonutProfit"
        Me.lblDonutProfit.Size = New System.Drawing.Size(0, 13)
        Me.lblDonutProfit.TabIndex = 29
        Me.lblDonutProfit.Visible = False
        '
        'lblDonutUpgr
        '
        Me.lblDonutUpgr.AutoSize = True
        Me.lblDonutUpgr.BackColor = System.Drawing.Color.Transparent
        Me.lblDonutUpgr.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDonutUpgr.ForeColor = System.Drawing.Color.Orange
        Me.lblDonutUpgr.Location = New System.Drawing.Point(92, 178)
        Me.lblDonutUpgr.Name = "lblDonutUpgr"
        Me.lblDonutUpgr.Size = New System.Drawing.Size(95, 13)
        Me.lblDonutUpgr.TabIndex = 30
        Me.lblDonutUpgr.Text = "Upgrade Cost $"
        Me.lblDonutUpgr.Visible = False
        '
        'lblDonutUpCost
        '
        Me.lblDonutUpCost.AutoSize = True
        Me.lblDonutUpCost.BackColor = System.Drawing.Color.Transparent
        Me.lblDonutUpCost.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblDonutUpCost.ForeColor = System.Drawing.Color.Orange
        Me.lblDonutUpCost.Location = New System.Drawing.Point(173, 179)
        Me.lblDonutUpCost.Name = "lblDonutUpCost"
        Me.lblDonutUpCost.Size = New System.Drawing.Size(0, 13)
        Me.lblDonutUpCost.TabIndex = 31
        Me.lblDonutUpCost.Visible = False
        '
        'btnBuyDonut
        '
        Me.btnBuyDonut.BackColor = System.Drawing.Color.LightBlue
        Me.btnBuyDonut.Location = New System.Drawing.Point(15, 152)
        Me.btnBuyDonut.Name = "btnBuyDonut"
        Me.btnBuyDonut.Size = New System.Drawing.Size(526, 23)
        Me.btnBuyDonut.TabIndex = 32
        Me.btnBuyDonut.Text = "Buy Donut Shop ($100,000)"
        Me.btnBuyDonut.UseVisualStyleBackColor = False
        '
        'grpDonutShop
        '
        Me.grpDonutShop.BackColor = System.Drawing.Color.Transparent
        Me.grpDonutShop.Controls.Add(Me.radDonut10)
        Me.grpDonutShop.Controls.Add(Me.radDonut5)
        Me.grpDonutShop.Controls.Add(Me.radDonut1)
        Me.grpDonutShop.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.249999!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.grpDonutShop.ForeColor = System.Drawing.Color.Indigo
        Me.grpDonutShop.Location = New System.Drawing.Point(265, 140)
        Me.grpDonutShop.Name = "grpDonutShop"
        Me.grpDonutShop.Size = New System.Drawing.Size(151, 35)
        Me.grpDonutShop.TabIndex = 33
        Me.grpDonutShop.TabStop = False
        Me.grpDonutShop.Visible = False
        '
        'radDonut10
        '
        Me.radDonut10.AutoSize = True
        Me.radDonut10.Location = New System.Drawing.Point(92, 11)
        Me.radDonut10.Name = "radDonut10"
        Me.radDonut10.Size = New System.Drawing.Size(49, 17)
        Me.radDonut10.TabIndex = 20
        Me.radDonut10.Text = "x 10"
        Me.radDonut10.UseVisualStyleBackColor = True
        Me.radDonut10.Visible = False
        '
        'radDonut5
        '
        Me.radDonut5.AutoSize = True
        Me.radDonut5.Location = New System.Drawing.Point(47, 11)
        Me.radDonut5.Name = "radDonut5"
        Me.radDonut5.Size = New System.Drawing.Size(42, 17)
        Me.radDonut5.TabIndex = 19
        Me.radDonut5.Text = "x 5"
        Me.radDonut5.UseVisualStyleBackColor = True
        Me.radDonut5.Visible = False
        '
        'radDonut1
        '
        Me.radDonut1.AutoSize = True
        Me.radDonut1.Checked = True
        Me.radDonut1.Location = New System.Drawing.Point(2, 11)
        Me.radDonut1.Name = "radDonut1"
        Me.radDonut1.Size = New System.Drawing.Size(42, 17)
        Me.radDonut1.TabIndex = 18
        Me.radDonut1.TabStop = True
        Me.radDonut1.Text = "x 1"
        Me.radDonut1.UseVisualStyleBackColor = True
        Me.radDonut1.Visible = False
        '
        'btnHireDonutWorker
        '
        Me.btnHireDonutWorker.BackColor = System.Drawing.Color.LightBlue
        Me.btnHireDonutWorker.Location = New System.Drawing.Point(422, 151)
        Me.btnHireDonutWorker.Name = "btnHireDonutWorker"
        Me.btnHireDonutWorker.Size = New System.Drawing.Size(119, 23)
        Me.btnHireDonutWorker.TabIndex = 21
        Me.btnHireDonutWorker.Text = "Hire Worker ($1M)"
        Me.btnHireDonutWorker.UseVisualStyleBackColor = False
        Me.btnHireDonutWorker.Visible = False
        '
        'tmrDonut
        '
        Me.tmrDonut.Enabled = True
        Me.tmrDonut.Interval = 600
        '
        'tmrDonutUpg
        '
        Me.tmrDonutUpg.Enabled = True
        Me.tmrDonutUpg.Interval = 600
        '
        'btnRetire
        '
        Me.btnRetire.BackColor = System.Drawing.Color.LightBlue
        Me.btnRetire.Location = New System.Drawing.Point(15, 202)
        Me.btnRetire.Name = "btnRetire"
        Me.btnRetire.Size = New System.Drawing.Size(490, 23)
        Me.btnRetire.TabIndex = 34
        Me.btnRetire.Text = "Retire ($100,000,000)"
        Me.btnRetire.UseVisualStyleBackColor = False
        '
        'BusinessSim
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackgroundImage = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources._929397811
        Me.ClientSize = New System.Drawing.Size(598, 237)
        Me.Controls.Add(Me.btnBuyDonut)
        Me.Controls.Add(Me.btnRetire)
        Me.Controls.Add(Me.btnHireDonutWorker)
        Me.Controls.Add(Me.grpDonutShop)
        Me.Controls.Add(Me.btnBuyNewspaper)
        Me.Controls.Add(Me.lblDonutUpCost)
        Me.Controls.Add(Me.lblDonutUpgr)
        Me.Controls.Add(Me.lblDonutProfit)
        Me.Controls.Add(Me.lblPrompt4)
        Me.Controls.Add(Me.btnUpgradeDonut)
        Me.Controls.Add(Me.btnDonutShop)
        Me.Controls.Add(Me.grpPaperUpgrade)
        Me.Controls.Add(Me.lblPapeUpCost)
        Me.Controls.Add(Me.lblUpgradePaper)
        Me.Controls.Add(Me.lblPaperProfit)
        Me.Controls.Add(Me.lblPrrompt3)
        Me.Controls.Add(Me.btnHirePaperWorker)
        Me.Controls.Add(Me.btnUpgradeNewspaper)
        Me.Controls.Add(Me.btnDeliver)
        Me.Controls.Add(Me.lblLemCostUpgrade)
        Me.Controls.Add(Me.lblLemUpgradeCost)
        Me.Controls.Add(Me.lblLemProfit)
        Me.Controls.Add(Me.lblPrompt2)
        Me.Controls.Add(Me.btnHireLem)
        Me.Controls.Add(Me.grpLemUpgrade)
        Me.Controls.Add(Me.lblMoney)
        Me.Controls.Add(Me.lblPrompt)
        Me.Controls.Add(Me.btnUpgradeLemonade)
        Me.Controls.Add(Me.btnLemonade)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "BusinessSim"
        Me.Text = "Business Sim"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.grpLemUpgrade.ResumeLayout(False)
        Me.grpLemUpgrade.PerformLayout()
        Me.grpPaperUpgrade.ResumeLayout(False)
        Me.grpPaperUpgrade.PerformLayout()
        Me.grpDonutShop.ResumeLayout(False)
        Me.grpDonutShop.PerformLayout()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents HelpToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents InstructionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents btnLemonade As System.Windows.Forms.Button
    Friend WithEvents btnUpgradeLemonade As System.Windows.Forms.Button
    Friend WithEvents radLem1 As System.Windows.Forms.RadioButton
    Friend WithEvents radLem5 As System.Windows.Forms.RadioButton
    Friend WithEvents lblPrompt As System.Windows.Forms.Label
    Friend WithEvents lblMoney As System.Windows.Forms.Label
    Friend WithEvents grpLemUpgrade As System.Windows.Forms.GroupBox
    Friend WithEvents btnHireLem As System.Windows.Forms.Button
    Friend WithEvents tmrLemonade As System.Windows.Forms.Timer
    Friend WithEvents tmrUpgradeLem As System.Windows.Forms.Timer
    Friend WithEvents lblPrompt2 As System.Windows.Forms.Label
    Friend WithEvents lblLemProfit As System.Windows.Forms.Label
    Friend WithEvents lblLemUpgradeCost As System.Windows.Forms.Label
    Friend WithEvents lblLemCostUpgrade As System.Windows.Forms.Label
    Friend WithEvents radLem10 As System.Windows.Forms.RadioButton
    Friend WithEvents tmrLemWorker As System.Windows.Forms.Timer
    Friend WithEvents btnDeliver As System.Windows.Forms.Button
    Friend WithEvents btnUpgradeNewspaper As System.Windows.Forms.Button
    Friend WithEvents btnBuyNewspaper As System.Windows.Forms.Button
    Friend WithEvents btnHirePaperWorker As System.Windows.Forms.Button
    Friend WithEvents radPaper1 As System.Windows.Forms.RadioButton
    Friend WithEvents radPaper5 As System.Windows.Forms.RadioButton
    Friend WithEvents radPaper10 As System.Windows.Forms.RadioButton
    Friend WithEvents lblPrrompt3 As System.Windows.Forms.Label
    Friend WithEvents lblPaperProfit As System.Windows.Forms.Label
    Friend WithEvents lblUpgradePaper As System.Windows.Forms.Label
    Friend WithEvents lblPapeUpCost As System.Windows.Forms.Label
    Friend WithEvents grpPaperUpgrade As System.Windows.Forms.GroupBox
    Friend WithEvents tmrDeliver As System.Windows.Forms.Timer
    Friend WithEvents tmrUpgradePaper As System.Windows.Forms.Timer
    Friend WithEvents tmrPaperWorker As System.Windows.Forms.Timer
    Friend WithEvents btnDonutShop As System.Windows.Forms.Button
    Friend WithEvents btnUpgradeDonut As System.Windows.Forms.Button
    Friend WithEvents lblPrompt4 As System.Windows.Forms.Label
    Friend WithEvents lblDonutProfit As System.Windows.Forms.Label
    Friend WithEvents lblDonutUpgr As System.Windows.Forms.Label
    Friend WithEvents lblDonutUpCost As System.Windows.Forms.Label
    Friend WithEvents btnBuyDonut As System.Windows.Forms.Button
    Friend WithEvents grpDonutShop As System.Windows.Forms.GroupBox
    Friend WithEvents radDonut10 As System.Windows.Forms.RadioButton
    Friend WithEvents radDonut5 As System.Windows.Forms.RadioButton
    Friend WithEvents radDonut1 As System.Windows.Forms.RadioButton
    Friend WithEvents btnHireDonutWorker As System.Windows.Forms.Button
    Friend WithEvents tmrDonut As System.Windows.Forms.Timer
    Friend WithEvents tmrDonutUpg As System.Windows.Forms.Timer
    Friend WithEvents btnRetire As System.Windows.Forms.Button
End Class
