﻿Public Class RockPaperScissorsInstructions

    Private Sub Button2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Button2.Click
        Close() 'back to main menu
    End Sub

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        My.Forms.RockPaperScissors.Show() 'start game
        Close()
    End Sub
End Class