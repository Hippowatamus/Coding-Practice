﻿Public Class Matching
    'Matching Game
    'Objective:  The objective Of the Matching Game Is To match pairs Of symbols by clicking On the 'back of’ (blank) tiles and revealing their symbol. This will continue until all pairs are matched, and the game will be won.

    'Steps:
    'Start the game When the user clicks On the 'Matching Game’ button on the game selection menu.
    'Display a screen With the instructions For the game And a 'Start’ button at the bottom of the screen.  The user will press ‘start’ to begin play
    'On startup:
    'Use 8 characters from the wingding font as symbols on the game tiles.  
    'Define the game board Using a layout panel Of 4 by 4 (16 boxes, With the intent Of having 8 pairs).  Labels will be used To display the symbol In the layout panel.
    'Randomly assign Each label one Of the 8 selected wingding characters.  Each wingding character will be used twice.
    'When the user clicks on a label:
    'Reveal the tile's assigned symbol.  
    'Determine if this Is the user's first tile selection in the pair or the second.
    'If this Is the first, go To 4.
    'If this Is the second, And the second symbol matches the first selected tile symbol, both tile's symbols will be made permanently visible.
    'If a match Is Not made,  a Short timer (2-3 seconds) will begin, When it ends, both symbols will cease being revealed.
    'Every time a match Is made:
    'determine whether Or Not all 8 matches have been made.
    'If all matches have Not been made, go To Step 4.
    'If all matches have been made, display a message box With a message telling the user he has won And an 'OK’ button.
    'When the user presses 'OK’ the game ends and control returns to the Game Selection Menu.

    'A list of pairs of characters is made each character corresponds with an icon through Wingdings
    Private random As New Random
    Private symbols = New List(Of String) From {"a", "a", "b", "b", "c", "c", "d", "d",
                                "e", "e", "f", "f", "g", "g", "h", "h"}
    Private firstClicked As Label = Nothing
    Private secondClicked As Label = Nothing

    Private Sub AssignIconsToSquares()

        'This Randomly assigns a symbol to each panel
        'When the symbols are invisible, theeir font color is actually set to match that of the back color.
        For Each control In TableLayoutPanel1.Controls
            Dim symbolLbl = TryCast(control, Label)
            If symbolLbl IsNot Nothing Then
                Dim randomNumber = random.Next(symbols.Count)
                symbolLbl.Text = symbols(randomNumber)
                symbolLbl.ForeColor = symbolLbl.BackColor
                symbols.RemoveAt(randomNumber)
            End If
        Next

    End Sub

    Private Sub Form1_Load(ByVal sender As Object, ByVal e As EventArgs) Handles MyBase.Load
        AssignIconsToSquares()
    End Sub

    Private Sub label_Click(ByVal sender As Object, ByVal e As EventArgs) Handles LabelI.Click, LabelH.Click, LabelG.Click, LabelF.Click, LabelE.Click, LabelD.Click, LabelC.Click, LabelB.Click, LabelP.Click, LabelO.Click, LabelN.Click, LabelM.Click, LabelL.Click, LabelK.Click, LabelJ.Click, LabelA.Click

        If Timer1.Enabled Then Exit Sub

        Dim clickedLabel = TryCast(sender, Label)

        If clickedLabel IsNot Nothing Then

            If clickedLabel.ForeColor = Color.Black Then Exit Sub
            'When a Tile is clicked, firstClicked is assigned a value
            'If firsClicked has a value, secondClicked is assigned a value
            'If firstClicked = secondClicked, the tiles are permanently left visible
            If firstClicked Is Nothing Then
                firstClicked = clickedLabel
                firstClicked.ForeColor = Color.Black
                Exit Sub
            End If
            secondClicked = clickedLabel
            secondClicked.ForeColor = Color.Black
            CheckForWinner()
            If firstClicked.Text = secondClicked.Text Then
                firstClicked = Nothing
                secondClicked = Nothing
                Exit Sub
            End If
            Timer1.Start()
        End If
    End Sub

    Private Sub Timer1_Tick(ByVal sender As Object, ByVal e As EventArgs) Handles Timer1.Tick
        Timer1.Stop()

        firstClicked.ForeColor = firstClicked.BackColor
        secondClicked.ForeColor = secondClicked.BackColor
        firstClicked = Nothing
        secondClicked = Nothing
    End Sub
    Private Sub CheckForWinner()
        For Each control In TableLayoutPanel1.Controls
            Dim iconLabel = TryCast(control, Label)
            If iconLabel IsNot Nothing AndAlso
               iconLabel.ForeColor = iconLabel.BackColor Then Exit Sub
        Next
        MessageBox.Show("All Icons Have Been Matched, You Win!", "You Win!")
        MainMenu.MatchWin = True
        Close()

    End Sub

    Private Sub TableLayoutPanel1_Paint(ByVal sender As Object, ByVal e As PaintEventArgs) Handles TableLayoutPanel1.Paint

    End Sub
End Class
