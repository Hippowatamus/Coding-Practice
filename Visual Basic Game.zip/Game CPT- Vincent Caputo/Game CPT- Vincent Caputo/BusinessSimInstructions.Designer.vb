﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class BusinessSimInstructions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(BusinessSimInstructions))
        Me.btnStart = New System.Windows.Forms.Button()
        Me.lblBuisnessSim = New System.Windows.Forms.Label()
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.btnBack = New System.Windows.Forms.Button()
        Me.lblInstructions2 = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'btnStart
        '
        Me.btnStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnStart.ForeColor = System.Drawing.Color.LimeGreen
        Me.btnStart.Location = New System.Drawing.Point(20, 312)
        Me.btnStart.Name = "btnStart"
        Me.btnStart.Size = New System.Drawing.Size(113, 23)
        Me.btnStart.TabIndex = 0
        Me.btnStart.Text = "Start Game"
        Me.btnStart.UseVisualStyleBackColor = True
        '
        'lblBuisnessSim
        '
        Me.lblBuisnessSim.AutoSize = True
        Me.lblBuisnessSim.BackColor = System.Drawing.Color.Transparent
        Me.lblBuisnessSim.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblBuisnessSim.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblBuisnessSim.Location = New System.Drawing.Point(12, 9)
        Me.lblBuisnessSim.Name = "lblBuisnessSim"
        Me.lblBuisnessSim.Size = New System.Drawing.Size(222, 37)
        Me.lblBuisnessSim.TabIndex = 1
        Me.lblBuisnessSim.Text = "Buisness Sim"
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructions.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblInstructions.Location = New System.Drawing.Point(16, 52)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(90, 16)
        Me.lblInstructions.TabIndex = 2
        Me.lblInstructions.Text = "Instructions:"
        '
        'btnBack
        '
        Me.btnBack.Font = New System.Drawing.Font("Microsoft Sans Serif", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.btnBack.ForeColor = System.Drawing.Color.LimeGreen
        Me.btnBack.Location = New System.Drawing.Point(370, 12)
        Me.btnBack.Name = "btnBack"
        Me.btnBack.Size = New System.Drawing.Size(75, 23)
        Me.btnBack.TabIndex = 3
        Me.btnBack.Text = "Back"
        Me.btnBack.UseVisualStyleBackColor = True
        '
        'lblInstructions2
        '
        Me.lblInstructions2.AutoSize = True
        Me.lblInstructions2.Font = New System.Drawing.Font("Microsoft Sans Serif", 9.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructions2.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblInstructions2.Location = New System.Drawing.Point(17, 80)
        Me.lblInstructions2.Name = "lblInstructions2"
        Me.lblInstructions2.Size = New System.Drawing.Size(449, 176)
        Me.lblInstructions2.TabIndex = 4
        Me.lblInstructions2.Text = resources.GetString("lblInstructions2.Text")
        '
        'BusinessSimInstructions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DarkSlateGray
        Me.ClientSize = New System.Drawing.Size(603, 347)
        Me.Controls.Add(Me.lblInstructions2)
        Me.Controls.Add(Me.btnBack)
        Me.Controls.Add(Me.lblInstructions)
        Me.Controls.Add(Me.lblBuisnessSim)
        Me.Controls.Add(Me.btnStart)
        Me.Name = "BusinessSimInstructions"
        Me.Text = "Buisness Sim Instructions"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents btnStart As System.Windows.Forms.Button
    Friend WithEvents lblBuisnessSim As System.Windows.Forms.Label
    Friend WithEvents lblInstructions As System.Windows.Forms.Label
    Friend WithEvents btnBack As System.Windows.Forms.Button
    Friend WithEvents lblInstructions2 As System.Windows.Forms.Label
End Class
