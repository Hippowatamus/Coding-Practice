﻿'Vincent Caputo & Colin Peters
'Main Game Objective:
'To present the user with six different mini games to play.   The user must play And win each of the individual mini-games to win the game.   

'Game Start Screen:
'Objective:  To present the title of the game And allow the user to 'start’ the game.
'Steps:
'Display a label With 'Les Six Minijeux’ in large black letters on a blue background, and a ‘Start’ button at the bottom. 
'When the user presses start, go to the Game Selection Menu. (the title And 'start’ label will become invisible and the controls for the game selection menu will become visible.)

'Game Selection Menu:
'Objective:  To allow the user to select And launch each of the six minigames. 
'Steps:
'Game Selection Menu will have an Icon And a button For Each one Of the six minigames:
'Business Sim Game
'Maze Game
'Rock Paper Scissors Game
'Tank Game
'Tic Tac Toe Game
'Matching Game
'When the user clicks on the 'Business Sim Game’ button:
'Display the 'Business Sim Game’ instructions with a start button,
'When the user presses the start button, open the Business Sim Game form
'When the user clicks on the 'Maze Game’ button:
'Display the 'Maze Game’ instructions with a start button,
'When the user presses the start button, open the Maze Game form
'When the user clicks on the 'Rock Paper Scissors Game’ button:
'Display the 'Rock Paper Scissors Game’ instructions with a start button,
'When the user presses the start button, open the Rock Paper Scissors form
'When the user clicks on the 'Tank Game’ button:
'Display the 'Tank Game’ instructions with a start button,
'When the user presses the start button, open the Tank Game form
'When the user clicks on the 'Tic Tac Toe Game’ button:
'Display the 'Tic Tac Toe Game’ instructions with a start button,
'When the user presses the start button, open the Tic Tac Toe Game form
'When the user clicks on the 'Matching Game’ button:
'Display the 'Matching Game’ instructions with a start button,
'When the user presses the start button, open the Matching Game form
'A 'verify completed games’ button will determine what games have been won. The completed games will be indicated every time this button is clicked. When all games have been won, a message box will congratulate the user and the full game will end.

Public Class MainMenu
    'Vincent Caputo
    Public TankWin As Boolean
    Public MazeWin As Boolean
    Public TicWin As Boolean
    Public BusinessWin As Boolean
    Public MatchWin As Boolean
    Public RockWin As Boolean

    Dim instructions As Boolean
    Private Sub ExitToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles ExitToolStripMenuItem.Click
        Application.Exit() 'Closes Program
    End Sub

    Private Sub RestartToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles RestartToolStripMenuItem.Click
        Application.Restart() 'restarts game
    End Sub

    Private Sub btnBuisnessSim_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuisnessSim.Click
        If instructions = True Then
            My.Forms.BusinessSimInstructions.Show() 'Buisness sim
        Else
            MessageBox.Show("You Must Read The Instructions First!", "Warning", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnMazeGame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMazeGame.Click
        If instructions = True Then
            My.Forms.MazeInstructions.Show() 'maze game
        Else
            MessageBox.Show("You Must Read The Instructions First!", "Warning", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnMatching_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnMatching.Click
        If instructions = True Then
            My.Forms.MatchingInstructions.Show() 'matching game
        Else
            MessageBox.Show("You Must Read The Instructions First!", "Warning", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnRockPaperScissors_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRockPaperScissors.Click
        If instructions = True Then
            My.Forms.RockPaperScissorsInstructions.Show() 'Rock Paper Scissors
        Else
            MessageBox.Show("You Must Read The Instructions First!", "Warning", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnTankGame_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTankGame.Click
        If instructions = True Then
            My.Forms.TankInstructions.Show() 'tank game
        Else
            MessageBox.Show("You Must Read The Instructions First!", "Warning", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub btnTicTacToe_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnTicTacToe.Click
        If instructions = True Then
            My.Forms.c.Show() 'tic tac toe
        Else
            MessageBox.Show("You Must Read The Instructions First!", "Warning", MessageBoxButtons.OK)
        End If
    End Sub

    Private Sub Form1_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load

        If TankWin = True Then
            Me.btnTankGame.BackColor = Color.DarkRed
        End If

        If TankWin = True And MazeWin = True And RockWin = True And MatchWin = True And BusinessWin = True And TicWin = True Then
            MessageBox.Show("Congradulations You Won!", "Game Won", MessageBoxButtons.OK)
            'sound
            Application.Exit()

        End If
    End Sub

    Private Sub btnInstructions_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnInstructions.Click
        instructions = True
        My.Forms.MainMenuInstructions.Show()
    End Sub

    Private Sub btnVerify_Click(sender As Object, e As EventArgs) Handles btnVerify.Click
        If TankWin = True Then
            Me.btnTankGame.BackColor = Color.DarkRed
        End If
        If MazeWin = True Then
            Me.btnMazeGame.BackColor = Color.DarkRed
        End If
        If MatchWin = True Then
            Me.btnMatching.BackColor = Color.DarkRed
        End If
        If BusinessWin = True Then
            Me.btnBuisnessSim.BackColor = Color.DarkRed
        End If
        If RockWin = True Then
            Me.btnRockPaperScissors.BackColor = Color.DarkRed
        End If
        If TicWin = True Then
            Me.btnTicTacToe.BackColor = Color.DarkRed
        End If
        If TankWin = True And MazeWin = True And RockWin = True And MatchWin = True And BusinessWin = True And TicWin = True Then
            MessageBox.Show("Congratulations You Won!", "Game Won", MessageBoxButtons.OK)
            'sound
            Application.Exit()
        End If

    End Sub

    Private Sub ProgramToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles ProgramToolStripMenuItem.Click

    End Sub

    Private Sub CreditsToolStripMenuItem_Click(sender As Object, e As EventArgs)

    End Sub

    Private Sub Label2_Click(sender As Object, e As EventArgs) Handles lblStart.Click
        lblStart.Visible = False
        lblTitle.Visible = False
        PictureBox1.Visible = True
        PictureBox2.Visible = True
        PictureBox3.Visible = True
        PictureBox4.Visible = True
        PictureBox5.Visible = True
        PictureBox6.Visible = True
        btnBuisnessSim.Visible = True
        btnInstructions.Visible = True
        btnMatching.Visible = True
        btnMazeGame.Visible = True
        btnRockPaperScissors.Visible = True
        btnTankGame.Visible = True
        btnTicTacToe.Visible = True
        btnVerify.Visible = True
        lblPrompt.Visible = True

    End Sub
End Class
