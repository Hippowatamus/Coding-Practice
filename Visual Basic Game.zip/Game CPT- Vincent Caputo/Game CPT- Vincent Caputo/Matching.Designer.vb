﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Matching
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.LabelP = New System.Windows.Forms.Label()
        Me.LabelO = New System.Windows.Forms.Label()
        Me.LabelN = New System.Windows.Forms.Label()
        Me.LabelM = New System.Windows.Forms.Label()
        Me.LabelL = New System.Windows.Forms.Label()
        Me.LabelK = New System.Windows.Forms.Label()
        Me.LabelJ = New System.Windows.Forms.Label()
        Me.LabelI = New System.Windows.Forms.Label()
        Me.LabelH = New System.Windows.Forms.Label()
        Me.LabelG = New System.Windows.Forms.Label()
        Me.LabelF = New System.Windows.Forms.Label()
        Me.TableLayoutPanel1 = New System.Windows.Forms.TableLayoutPanel()
        Me.LabelE = New System.Windows.Forms.Label()
        Me.LabelD = New System.Windows.Forms.Label()
        Me.LabelC = New System.Windows.Forms.Label()
        Me.LabelB = New System.Windows.Forms.Label()
        Me.LabelA = New System.Windows.Forms.Label()
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.TableLayoutPanel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'LabelP
        '
        Me.LabelP.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelP.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelP.Location = New System.Drawing.Point(404, 383)
        Me.LabelP.Name = "LabelP"
        Me.LabelP.Size = New System.Drawing.Size(125, 126)
        Me.LabelP.TabIndex = 15
        Me.LabelP.Text = "c"
        Me.LabelP.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelO
        '
        Me.LabelO.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelO.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelO.Location = New System.Drawing.Point(271, 383)
        Me.LabelO.Name = "LabelO"
        Me.LabelO.Size = New System.Drawing.Size(125, 126)
        Me.LabelO.TabIndex = 14
        Me.LabelO.Text = "c"
        Me.LabelO.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelN
        '
        Me.LabelN.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelN.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelN.Location = New System.Drawing.Point(138, 383)
        Me.LabelN.Name = "LabelN"
        Me.LabelN.Size = New System.Drawing.Size(125, 126)
        Me.LabelN.TabIndex = 13
        Me.LabelN.Text = "c"
        Me.LabelN.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelM
        '
        Me.LabelM.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelM.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelM.Location = New System.Drawing.Point(5, 383)
        Me.LabelM.Name = "LabelM"
        Me.LabelM.Size = New System.Drawing.Size(125, 126)
        Me.LabelM.TabIndex = 12
        Me.LabelM.Text = "c"
        Me.LabelM.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelL
        '
        Me.LabelL.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelL.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelL.Location = New System.Drawing.Point(404, 256)
        Me.LabelL.Name = "LabelL"
        Me.LabelL.Size = New System.Drawing.Size(125, 125)
        Me.LabelL.TabIndex = 11
        Me.LabelL.Text = "c"
        Me.LabelL.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelK
        '
        Me.LabelK.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelK.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelK.Location = New System.Drawing.Point(271, 256)
        Me.LabelK.Name = "LabelK"
        Me.LabelK.Size = New System.Drawing.Size(125, 125)
        Me.LabelK.TabIndex = 10
        Me.LabelK.Text = "c"
        Me.LabelK.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelJ
        '
        Me.LabelJ.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelJ.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelJ.Location = New System.Drawing.Point(138, 256)
        Me.LabelJ.Name = "LabelJ"
        Me.LabelJ.Size = New System.Drawing.Size(125, 125)
        Me.LabelJ.TabIndex = 9
        Me.LabelJ.Text = "c"
        Me.LabelJ.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelI
        '
        Me.LabelI.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelI.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelI.Location = New System.Drawing.Point(5, 256)
        Me.LabelI.Name = "LabelI"
        Me.LabelI.Size = New System.Drawing.Size(125, 125)
        Me.LabelI.TabIndex = 8
        Me.LabelI.Text = "c"
        Me.LabelI.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelH
        '
        Me.LabelH.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelH.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelH.Location = New System.Drawing.Point(404, 129)
        Me.LabelH.Name = "LabelH"
        Me.LabelH.Size = New System.Drawing.Size(125, 125)
        Me.LabelH.TabIndex = 7
        Me.LabelH.Text = "c"
        Me.LabelH.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelG
        '
        Me.LabelG.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelG.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelG.Location = New System.Drawing.Point(271, 129)
        Me.LabelG.Name = "LabelG"
        Me.LabelG.Size = New System.Drawing.Size(125, 125)
        Me.LabelG.TabIndex = 6
        Me.LabelG.Text = "c"
        Me.LabelG.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelF
        '
        Me.LabelF.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelF.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelF.Location = New System.Drawing.Point(138, 129)
        Me.LabelF.Name = "LabelF"
        Me.LabelF.Size = New System.Drawing.Size(125, 125)
        Me.LabelF.TabIndex = 5
        Me.LabelF.Text = "c"
        Me.LabelF.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'TableLayoutPanel1
        '
        Me.TableLayoutPanel1.CellBorderStyle = System.Windows.Forms.TableLayoutPanelCellBorderStyle.Inset
        Me.TableLayoutPanel1.ColumnCount = 4
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.ColumnStyles.Add(New System.Windows.Forms.ColumnStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.Controls.Add(Me.LabelP, 3, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelO, 2, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelN, 1, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelM, 0, 3)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelL, 3, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelK, 2, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelJ, 1, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelI, 0, 2)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelH, 3, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelG, 2, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelF, 1, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelE, 0, 1)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelD, 3, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelC, 2, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelB, 1, 0)
        Me.TableLayoutPanel1.Controls.Add(Me.LabelA, 0, 0)
        Me.TableLayoutPanel1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.TableLayoutPanel1.Location = New System.Drawing.Point(0, 0)
        Me.TableLayoutPanel1.Name = "TableLayoutPanel1"
        Me.TableLayoutPanel1.RowCount = 4
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.RowStyles.Add(New System.Windows.Forms.RowStyle(System.Windows.Forms.SizeType.Percent, 25.0!))
        Me.TableLayoutPanel1.Size = New System.Drawing.Size(534, 511)
        Me.TableLayoutPanel1.TabIndex = 3
        '
        'LabelE
        '
        Me.LabelE.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelE.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelE.Location = New System.Drawing.Point(5, 129)
        Me.LabelE.Name = "LabelE"
        Me.LabelE.Size = New System.Drawing.Size(125, 125)
        Me.LabelE.TabIndex = 4
        Me.LabelE.Text = "c"
        Me.LabelE.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelD
        '
        Me.LabelD.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelD.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelD.Location = New System.Drawing.Point(404, 2)
        Me.LabelD.Name = "LabelD"
        Me.LabelD.Size = New System.Drawing.Size(125, 125)
        Me.LabelD.TabIndex = 3
        Me.LabelD.Text = "c"
        Me.LabelD.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelC
        '
        Me.LabelC.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelC.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelC.Location = New System.Drawing.Point(271, 2)
        Me.LabelC.Name = "LabelC"
        Me.LabelC.Size = New System.Drawing.Size(125, 125)
        Me.LabelC.TabIndex = 2
        Me.LabelC.Text = "c"
        Me.LabelC.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelB
        '
        Me.LabelB.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelB.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelB.Location = New System.Drawing.Point(138, 2)
        Me.LabelB.Name = "LabelB"
        Me.LabelB.Size = New System.Drawing.Size(125, 125)
        Me.LabelB.TabIndex = 1
        Me.LabelB.Text = "c"
        Me.LabelB.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'LabelA
        '
        Me.LabelA.Dock = System.Windows.Forms.DockStyle.Fill
        Me.LabelA.Font = New System.Drawing.Font("Webdings", 72.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(2, Byte))
        Me.LabelA.Location = New System.Drawing.Point(5, 2)
        Me.LabelA.Name = "LabelA"
        Me.LabelA.Size = New System.Drawing.Size(125, 125)
        Me.LabelA.TabIndex = 0
        Me.LabelA.Text = "c"
        Me.LabelA.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Timer1
        '
        Me.Timer1.Interval = 750
        '
        'Form5
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(534, 511)
        Me.Controls.Add(Me.TableLayoutPanel1)
        Me.Name = "Form5"
        Me.Text = "Matching"
        Me.TableLayoutPanel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents LabelP As System.Windows.Forms.Label
    Friend WithEvents LabelO As System.Windows.Forms.Label
    Friend WithEvents LabelN As System.Windows.Forms.Label
    Friend WithEvents LabelM As System.Windows.Forms.Label
    Friend WithEvents LabelL As System.Windows.Forms.Label
    Friend WithEvents LabelK As System.Windows.Forms.Label
    Friend WithEvents LabelJ As System.Windows.Forms.Label
    Friend WithEvents LabelI As System.Windows.Forms.Label
    Friend WithEvents LabelH As System.Windows.Forms.Label
    Friend WithEvents LabelG As System.Windows.Forms.Label
    Friend WithEvents LabelF As System.Windows.Forms.Label
    Friend WithEvents TableLayoutPanel1 As System.Windows.Forms.TableLayoutPanel
    Friend WithEvents LabelE As System.Windows.Forms.Label
    Friend WithEvents LabelD As System.Windows.Forms.Label
    Friend WithEvents LabelC As System.Windows.Forms.Label
    Friend WithEvents LabelB As System.Windows.Forms.Label
    Friend WithEvents LabelA As System.Windows.Forms.Label
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
End Class
