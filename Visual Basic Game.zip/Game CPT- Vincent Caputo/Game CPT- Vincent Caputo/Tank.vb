﻿'Tank Game
'Objective: 
'To destroy all turrets by running them over with the tank, without touching the bombs.
'The user will use the arrow keys To control the movement And direction Of the tank
'Turrets And bombs will be placed around the battlefield, the tank must drive over And crush all the turrets to win the game. There will be bombs placed along the battlefield too. If the user touches a bomb it will explode And the tank will blow up. If that occurs the game Is lost And the user must restart
'If all turrets are destroyed a congratulations message will be displayed And the game will close.

Public Class Tank
    Dim SRight As Boolean
    Dim SLeft As Boolean
    Dim SUp As Boolean
    Dim SDown As Boolean
    Dim ShooterSpeed As Integer = 3
    Dim colisionLeft As Boolean = False
    Dim colisionRight As Boolean = False
    Dim collisionUp As Boolean = False
    Dim collisionDown As Boolean = False
    Dim tankDirection As Integer
    Dim messagebox1 As Boolean = False
    Dim Lev1Bot1Destroyed As Boolean
    Dim lev1Bot2Destroyed As Boolean
    Dim levlBot3Destroyed As Boolean
    Dim levlBot4Destroyed As Boolean




    Private Sub Form2_KeyDown(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyDown

        'Controls tank movement
        If e.KeyValue = Keys.Right And colisionRight = False Then
            SRight = True
            SLeft = False
            Me.picTank.Image = My.Resources.TankRight
            My.Computer.Audio.Play(My.Resources.Tank_moving_sound_effect_1, AudioPlayMode.Background)
            tankDirection = 1

        End If

        If e.KeyValue = Keys.Left And colisionLeft = False Then
            SLeft = True
            SRight = False
            Me.picTank.Image = My.Resources.Tank_Left
            My.Computer.Audio.Play(My.Resources.Tank_moving_sound_effect_1, AudioPlayMode.Background)
            tankDirection = 2
        End If

        If e.KeyValue = Keys.Up And collisionUp = False Then
            SUp = True
            SDown = False
            Me.picTank.Image = My.Resources.Tank
            My.Computer.Audio.Play(My.Resources.Tank_moving_sound_effect_1, AudioPlayMode.Background)
            tankDirection = 0
        End If

        If e.KeyValue = Keys.Down And collisionDown = False Then
            SDown = True
            SUp = False
            Me.picTank.Image = My.Resources.TankDown
            My.Computer.Audio.Play(My.Resources.Tank_moving_sound_effect_1, AudioPlayMode.Background)
            tankDirection = 3
        End If

        'Collision detection
        If picTank.Bounds.IntersectsWith(picLeftWall.Bounds) Then
            colisionLeft = True
        Else
            colisionLeft = False
        End If

        If picTank.Bounds.IntersectsWith(picRightWall.Bounds) Then
            colisionRight = True
        Else
            colisionRight = False
        End If

        If picTank.Bounds.IntersectsWith(picBottomWall.Bounds) Then
            collisionDown = True
        Else
            collisionDown = False
        End If

        If picTank.Bounds.IntersectsWith(picBottomWall.Bounds) Then
            collisionDown = True
        Else
            collisionDown = False
        End If

        If picTank.Bounds.IntersectsWith(picTopWall.Bounds) Then
            collisionUp = True
        Else
            collisionUp = False
        End If

        'object hit detection
        If picTank.Bounds.IntersectsWith(picLevel1Bot1.Bounds) Then
            Lev1Bot1Destroyed = True
            Me.picLevel1Bot1.Image = My.Resources.Rubble2
        End If

        If picTank.Bounds.IntersectsWith(picLevel1Bot2.Bounds) Then
            lev1Bot2Destroyed = True
            Me.picLevel1Bot2.Image = My.Resources.Rubble2
        End If

        If picTank.Bounds.IntersectsWith(picBot3.Bounds) Then
            levlBot3Destroyed = True
            Me.picBot3.Image = My.Resources.Rubble2
        End If

        If picTank.Bounds.IntersectsWith(picBot4.Bounds) Then
            levlBot4Destroyed = True
            Me.picBot4.Image = My.Resources.Rubble2
        End If

        'if won
        If Lev1Bot1Destroyed = True And lev1Bot2Destroyed = True And messagebox1 = False And levlBot3Destroyed = True And levlBot4Destroyed = True Then
            MessageBox.Show("You Win", "Match Won", MessageBoxButtons.OK)
            messagebox1 = True
            MainMenu.TankWin = True
            My.Computer.Audio.Stop()
            Close()
        End If

        'Bomb detection
        If picTank.Bounds.IntersectsWith(picBomb1.Bounds) Then
            Me.picTank.Image = My.Resources.Explosion
            MessageBox.Show("You Lost!", "Failed", MessageBoxButtons.OK)
            My.Computer.Audio.Stop()
            Close()
        End If

        If picTank.Bounds.IntersectsWith(picBomb2.Bounds) Then
            Me.picTank.Image = My.Resources.Explosion
            MessageBox.Show("You Lost!", "Failed", MessageBoxButtons.OK)
            My.Computer.Audio.Stop()
            Close()
        End If

        If picTank.Bounds.IntersectsWith(picBomb3.Bounds) Then
            Me.picTank.Image = My.Resources.Explosion
            MessageBox.Show("You Lost!", "Failed", MessageBoxButtons.OK)
            My.Computer.Audio.Stop()
            Close()
        End If

        If picTank.Bounds.IntersectsWith(picBomb4.Bounds) Then
            Me.picTank.Image = My.Resources.Explosion
            MessageBox.Show("You Lost!", "Failed", MessageBoxButtons.OK)
            My.Computer.Audio.Stop()
            Close()
        End If

        If picTank.Bounds.IntersectsWith(picBomb5.Bounds) Then
            Me.picTank.Image = My.Resources.Explosion
            MessageBox.Show("You Lost!", "Failed", MessageBoxButtons.OK)
            My.Computer.Audio.Stop()
            Close()
        End If

        If picTank.Bounds.IntersectsWith(picBomb6.Bounds) Then
            Me.picTank.Image = My.Resources.Explosion
            MessageBox.Show("You Lost!", "Failed", MessageBoxButtons.OK)
            My.Computer.Audio.Stop()
            Close()
        End If

        If picTank.Bounds.IntersectsWith(picBomb7.Bounds) Then
            Me.picTank.Image = My.Resources.Explosion
            MessageBox.Show("You Lost!", "Failed", MessageBoxButtons.OK)
            My.Computer.Audio.Stop()
            Close()
        End If
    End Sub

    Private Sub tmrMove_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrMove.Tick
        moveShooter()
    End Sub

    'Moves tank
    Private Sub moveShooter()
        If SRight = True And colisionRight = False Then
            picTank.Left += ShooterSpeed
        End If

        If SLeft = True And colisionLeft = False Then
            picTank.Left -= ShooterSpeed
        End If

        If SUp = True And collisionUp = False Then
            picTank.Top -= ShooterSpeed
        End If

        If SDown = True And collisionDown = False Then
            picTank.Top += ShooterSpeed
        End If
    End Sub

    Private Sub Form2_KeyUp(ByVal sender As System.Object, ByVal e As System.Windows.Forms.KeyEventArgs) Handles MyBase.KeyUp

        'Stops tank when key moves up
        If e.KeyValue = Keys.Right Then
            SRight = False
            My.Computer.Audio.Stop()
        End If

        If e.KeyValue = Keys.Left Then
            SLeft = False
            My.Computer.Audio.Stop()
        End If

        If e.KeyValue = Keys.Down Then
            SDown = False
            My.Computer.Audio.Stop()
        End If

        If e.KeyValue = Keys.Up Then
            SUp = False
            My.Computer.Audio.Stop()
        End If
    End Sub

    Private Sub Form2_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        'chooses tank speed
        ShooterSpeed = 3
    End Sub

    Private Sub BackToMenuToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackToMenuToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub BackToInstructionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackToInstructionsToolStripMenuItem.Click
        My.Forms.TankInstructions.Show()
        Close()
    End Sub
End Class
