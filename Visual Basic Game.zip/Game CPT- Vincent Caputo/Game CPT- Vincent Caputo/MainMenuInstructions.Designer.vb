﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenuInstructions
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(MainMenuInstructions))
        Me.lblInstructions = New System.Windows.Forms.Label()
        Me.lblInstructions2 = New System.Windows.Forms.Label()
        Me.btnBackToMenuInstructions = New System.Windows.Forms.Button()
        Me.SuspendLayout()
        '
        'lblInstructions
        '
        Me.lblInstructions.AutoSize = True
        Me.lblInstructions.Font = New System.Drawing.Font("Microsoft Sans Serif", 24.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructions.Location = New System.Drawing.Point(17, 9)
        Me.lblInstructions.Name = "lblInstructions"
        Me.lblInstructions.Size = New System.Drawing.Size(193, 37)
        Me.lblInstructions.TabIndex = 0
        Me.lblInstructions.Text = "Instructions"
        '
        'lblInstructions2
        '
        Me.lblInstructions2.Font = New System.Drawing.Font("Microsoft Sans Serif", 11.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblInstructions2.ForeColor = System.Drawing.Color.DarkRed
        Me.lblInstructions2.Location = New System.Drawing.Point(21, 67)
        Me.lblInstructions2.Name = "lblInstructions2"
        Me.lblInstructions2.Size = New System.Drawing.Size(348, 190)
        Me.lblInstructions2.TabIndex = 1
        Me.lblInstructions2.Text = resources.GetString("lblInstructions2.Text")
        '
        'btnBackToMenuInstructions
        '
        Me.btnBackToMenuInstructions.BackColor = System.Drawing.Color.Red
        Me.btnBackToMenuInstructions.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.btnBackToMenuInstructions.ForeColor = System.Drawing.Color.Black
        Me.btnBackToMenuInstructions.Location = New System.Drawing.Point(25, 275)
        Me.btnBackToMenuInstructions.Name = "btnBackToMenuInstructions"
        Me.btnBackToMenuInstructions.Size = New System.Drawing.Size(108, 23)
        Me.btnBackToMenuInstructions.TabIndex = 2
        Me.btnBackToMenuInstructions.Text = "Back To Menu"
        Me.btnBackToMenuInstructions.UseVisualStyleBackColor = False
        '
        'MainMenuInstructions
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DodgerBlue
        Me.ClientSize = New System.Drawing.Size(402, 352)
        Me.Controls.Add(Me.btnBackToMenuInstructions)
        Me.Controls.Add(Me.lblInstructions2)
        Me.Controls.Add(Me.lblInstructions)
        Me.Name = "MainMenuInstructions"
        Me.Text = "Instructions"
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents lblInstructions As System.Windows.Forms.Label
    Friend WithEvents lblInstructions2 As System.Windows.Forms.Label
    Friend WithEvents btnBackToMenuInstructions As System.Windows.Forms.Button
End Class
