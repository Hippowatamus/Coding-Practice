﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class MainMenu
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.ProgramToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.RestartToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ExitToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.lblPrompt = New System.Windows.Forms.Label()
        Me.btnBuisnessSim = New System.Windows.Forms.Button()
        Me.btnRockPaperScissors = New System.Windows.Forms.Button()
        Me.btnTicTacToe = New System.Windows.Forms.Button()
        Me.btnMatching = New System.Windows.Forms.Button()
        Me.btnTankGame = New System.Windows.Forms.Button()
        Me.btnMazeGame = New System.Windows.Forms.Button()
        Me.btnInstructions = New System.Windows.Forms.Button()
        Me.btnVerify = New System.Windows.Forms.Button()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.lblStart = New System.Windows.Forms.Label()
        Me.PictureBox6 = New System.Windows.Forms.PictureBox()
        Me.PictureBox5 = New System.Windows.Forms.PictureBox()
        Me.PictureBox4 = New System.Windows.Forms.PictureBox()
        Me.PictureBox3 = New System.Windows.Forms.PictureBox()
        Me.PictureBox2 = New System.Windows.Forms.PictureBox()
        Me.PictureBox1 = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.ProgramToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(507, 24)
        Me.MenuStrip1.TabIndex = 0
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'ProgramToolStripMenuItem
        '
        Me.ProgramToolStripMenuItem.DropDownItems.AddRange(New System.Windows.Forms.ToolStripItem() {Me.RestartToolStripMenuItem, Me.ExitToolStripMenuItem})
        Me.ProgramToolStripMenuItem.Name = "ProgramToolStripMenuItem"
        Me.ProgramToolStripMenuItem.Size = New System.Drawing.Size(65, 20)
        Me.ProgramToolStripMenuItem.Text = "Program"
        '
        'RestartToolStripMenuItem
        '
        Me.RestartToolStripMenuItem.Name = "RestartToolStripMenuItem"
        Me.RestartToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.RestartToolStripMenuItem.Text = "Restart"
        '
        'ExitToolStripMenuItem
        '
        Me.ExitToolStripMenuItem.Name = "ExitToolStripMenuItem"
        Me.ExitToolStripMenuItem.Size = New System.Drawing.Size(110, 22)
        Me.ExitToolStripMenuItem.Text = "Exit"
        '
        'lblPrompt
        '
        Me.lblPrompt.AutoSize = True
        Me.lblPrompt.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblPrompt.ForeColor = System.Drawing.Color.LimeGreen
        Me.lblPrompt.Location = New System.Drawing.Point(12, 33)
        Me.lblPrompt.Name = "lblPrompt"
        Me.lblPrompt.Size = New System.Drawing.Size(175, 25)
        Me.lblPrompt.TabIndex = 1
        Me.lblPrompt.Text = "Select A Game:"
        Me.lblPrompt.Visible = False
        '
        'btnBuisnessSim
        '
        Me.btnBuisnessSim.BackColor = System.Drawing.Color.Navy
        Me.btnBuisnessSim.ForeColor = System.Drawing.Color.SpringGreen
        Me.btnBuisnessSim.Location = New System.Drawing.Point(12, 313)
        Me.btnBuisnessSim.Name = "btnBuisnessSim"
        Me.btnBuisnessSim.Size = New System.Drawing.Size(132, 23)
        Me.btnBuisnessSim.TabIndex = 2
        Me.btnBuisnessSim.Text = "Buisness Sim"
        Me.btnBuisnessSim.UseVisualStyleBackColor = False
        Me.btnBuisnessSim.Visible = False
        '
        'btnRockPaperScissors
        '
        Me.btnRockPaperScissors.BackColor = System.Drawing.Color.Navy
        Me.btnRockPaperScissors.ForeColor = System.Drawing.Color.SpringGreen
        Me.btnRockPaperScissors.Location = New System.Drawing.Point(150, 313)
        Me.btnRockPaperScissors.Name = "btnRockPaperScissors"
        Me.btnRockPaperScissors.Size = New System.Drawing.Size(132, 23)
        Me.btnRockPaperScissors.TabIndex = 3
        Me.btnRockPaperScissors.Text = "Rock Paper Scissors"
        Me.btnRockPaperScissors.UseVisualStyleBackColor = False
        Me.btnRockPaperScissors.Visible = False
        '
        'btnTicTacToe
        '
        Me.btnTicTacToe.BackColor = System.Drawing.Color.Navy
        Me.btnTicTacToe.ForeColor = System.Drawing.Color.SpringGreen
        Me.btnTicTacToe.Location = New System.Drawing.Point(292, 313)
        Me.btnTicTacToe.Name = "btnTicTacToe"
        Me.btnTicTacToe.Size = New System.Drawing.Size(132, 23)
        Me.btnTicTacToe.TabIndex = 6
        Me.btnTicTacToe.Text = "Tic Tac Toe"
        Me.btnTicTacToe.UseVisualStyleBackColor = False
        Me.btnTicTacToe.Visible = False
        '
        'btnMatching
        '
        Me.btnMatching.BackColor = System.Drawing.Color.Navy
        Me.btnMatching.ForeColor = System.Drawing.Color.SpringGreen
        Me.btnMatching.Location = New System.Drawing.Point(12, 177)
        Me.btnMatching.Name = "btnMatching"
        Me.btnMatching.Size = New System.Drawing.Size(132, 23)
        Me.btnMatching.TabIndex = 8
        Me.btnMatching.Text = "Matching"
        Me.btnMatching.UseVisualStyleBackColor = False
        Me.btnMatching.Visible = False
        '
        'btnTankGame
        '
        Me.btnTankGame.BackColor = System.Drawing.Color.Navy
        Me.btnTankGame.ForeColor = System.Drawing.Color.SpringGreen
        Me.btnTankGame.Location = New System.Drawing.Point(150, 177)
        Me.btnTankGame.Name = "btnTankGame"
        Me.btnTankGame.Size = New System.Drawing.Size(132, 23)
        Me.btnTankGame.TabIndex = 4
        Me.btnTankGame.Text = "Tank Game"
        Me.btnTankGame.UseVisualStyleBackColor = False
        Me.btnTankGame.Visible = False
        '
        'btnMazeGame
        '
        Me.btnMazeGame.BackColor = System.Drawing.Color.Navy
        Me.btnMazeGame.ForeColor = System.Drawing.Color.SpringGreen
        Me.btnMazeGame.Location = New System.Drawing.Point(292, 177)
        Me.btnMazeGame.Name = "btnMazeGame"
        Me.btnMazeGame.Size = New System.Drawing.Size(132, 23)
        Me.btnMazeGame.TabIndex = 9
        Me.btnMazeGame.Text = "Maze  Game"
        Me.btnMazeGame.UseVisualStyleBackColor = False
        Me.btnMazeGame.Visible = False
        '
        'btnInstructions
        '
        Me.btnInstructions.BackColor = System.Drawing.SystemColors.HotTrack
        Me.btnInstructions.ForeColor = System.Drawing.Color.SpringGreen
        Me.btnInstructions.Location = New System.Drawing.Point(207, 33)
        Me.btnInstructions.Name = "btnInstructions"
        Me.btnInstructions.Size = New System.Drawing.Size(217, 23)
        Me.btnInstructions.TabIndex = 16
        Me.btnInstructions.Text = "Read Instructions First"
        Me.btnInstructions.UseVisualStyleBackColor = False
        Me.btnInstructions.Visible = False
        '
        'btnVerify
        '
        Me.btnVerify.Location = New System.Drawing.Point(12, 342)
        Me.btnVerify.Name = "btnVerify"
        Me.btnVerify.Size = New System.Drawing.Size(139, 23)
        Me.btnVerify.TabIndex = 17
        Me.btnVerify.Text = "Verify Completed Games:"
        Me.btnVerify.UseVisualStyleBackColor = True
        Me.btnVerify.Visible = False
        '
        'lblTitle
        '
        Me.lblTitle.AutoSize = True
        Me.lblTitle.Font = New System.Drawing.Font("Segoe Script", 36.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.Location = New System.Drawing.Point(12, 58)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.Size = New System.Drawing.Size(470, 76)
        Me.lblTitle.TabIndex = 18
        Me.lblTitle.Text = "Les Six Minijeux"
        '
        'lblStart
        '
        Me.lblStart.AutoSize = True
        Me.lblStart.Font = New System.Drawing.Font("Impact", 20.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStart.Location = New System.Drawing.Point(201, 231)
        Me.lblStart.Name = "lblStart"
        Me.lblStart.Size = New System.Drawing.Size(74, 34)
        Me.lblStart.TabIndex = 19
        Me.lblStart.Text = "Start:"
        '
        'PictureBox6
        '
        Me.PictureBox6.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.tictactoepic
        Me.PictureBox6.Location = New System.Drawing.Point(292, 206)
        Me.PictureBox6.Name = "PictureBox6"
        Me.PictureBox6.Size = New System.Drawing.Size(132, 101)
        Me.PictureBox6.TabIndex = 15
        Me.PictureBox6.TabStop = False
        Me.PictureBox6.Visible = False
        '
        'PictureBox5
        '
        Me.PictureBox5.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Maze
        Me.PictureBox5.Location = New System.Drawing.Point(292, 70)
        Me.PictureBox5.Name = "PictureBox5"
        Me.PictureBox5.Size = New System.Drawing.Size(132, 101)
        Me.PictureBox5.TabIndex = 14
        Me.PictureBox5.TabStop = False
        Me.PictureBox5.Visible = False
        '
        'PictureBox4
        '
        Me.PictureBox4.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Matching
        Me.PictureBox4.Location = New System.Drawing.Point(12, 70)
        Me.PictureBox4.Name = "PictureBox4"
        Me.PictureBox4.Size = New System.Drawing.Size(132, 101)
        Me.PictureBox4.TabIndex = 13
        Me.PictureBox4.TabStop = False
        Me.PictureBox4.Visible = False
        '
        'PictureBox3
        '
        Me.PictureBox3.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.tankpic
        Me.PictureBox3.Location = New System.Drawing.Point(150, 70)
        Me.PictureBox3.Name = "PictureBox3"
        Me.PictureBox3.Size = New System.Drawing.Size(132, 101)
        Me.PictureBox3.TabIndex = 12
        Me.PictureBox3.TabStop = False
        Me.PictureBox3.Visible = False
        '
        'PictureBox2
        '
        Me.PictureBox2.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.rockpaperpic
        Me.PictureBox2.Location = New System.Drawing.Point(150, 206)
        Me.PictureBox2.Name = "PictureBox2"
        Me.PictureBox2.Size = New System.Drawing.Size(132, 101)
        Me.PictureBox2.TabIndex = 11
        Me.PictureBox2.TabStop = False
        Me.PictureBox2.Visible = False
        '
        'PictureBox1
        '
        Me.PictureBox1.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Money
        Me.PictureBox1.Location = New System.Drawing.Point(12, 206)
        Me.PictureBox1.Name = "PictureBox1"
        Me.PictureBox1.Size = New System.Drawing.Size(132, 101)
        Me.PictureBox1.TabIndex = 10
        Me.PictureBox1.TabStop = False
        Me.PictureBox1.Visible = False
        '
        'MainMenu
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.DodgerBlue
        Me.ClientSize = New System.Drawing.Size(507, 418)
        Me.Controls.Add(Me.lblStart)
        Me.Controls.Add(Me.lblTitle)
        Me.Controls.Add(Me.btnVerify)
        Me.Controls.Add(Me.btnInstructions)
        Me.Controls.Add(Me.PictureBox6)
        Me.Controls.Add(Me.PictureBox5)
        Me.Controls.Add(Me.PictureBox4)
        Me.Controls.Add(Me.PictureBox3)
        Me.Controls.Add(Me.PictureBox2)
        Me.Controls.Add(Me.PictureBox1)
        Me.Controls.Add(Me.btnMazeGame)
        Me.Controls.Add(Me.btnMatching)
        Me.Controls.Add(Me.btnTicTacToe)
        Me.Controls.Add(Me.btnTankGame)
        Me.Controls.Add(Me.btnRockPaperScissors)
        Me.Controls.Add(Me.btnBuisnessSim)
        Me.Controls.Add(Me.lblPrompt)
        Me.Controls.Add(Me.MenuStrip1)
        Me.MainMenuStrip = Me.MenuStrip1
        Me.Name = "MainMenu"
        Me.Text = "Mini Games"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.PictureBox6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PictureBox1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents ProgramToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents RestartToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents ExitToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents lblPrompt As System.Windows.Forms.Label
    Friend WithEvents btnBuisnessSim As System.Windows.Forms.Button
    Friend WithEvents btnRockPaperScissors As System.Windows.Forms.Button
    Friend WithEvents btnTicTacToe As System.Windows.Forms.Button
    Friend WithEvents btnMatching As System.Windows.Forms.Button
    Friend WithEvents btnTankGame As System.Windows.Forms.Button
    Friend WithEvents btnMazeGame As System.Windows.Forms.Button
    Friend WithEvents PictureBox1 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox2 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox3 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox4 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox5 As System.Windows.Forms.PictureBox
    Friend WithEvents PictureBox6 As System.Windows.Forms.PictureBox
    Friend WithEvents btnInstructions As System.Windows.Forms.Button
    Friend WithEvents btnVerify As Button
    Friend WithEvents lblTitle As Label
    Friend WithEvents lblStart As Label
End Class
