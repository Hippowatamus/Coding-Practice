﻿Public Class MainMenuInstructions

    Private Sub btnBackToMenuInstructions_Click(sender As System.Object, e As System.EventArgs) Handles btnBackToMenuInstructions.Click
        Close()
    End Sub
End Class