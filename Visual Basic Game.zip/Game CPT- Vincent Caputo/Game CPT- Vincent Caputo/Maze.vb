﻿Public Class Maze
    'Vincent Caputo
    'Maze Game
    'Objective: 
    '	To move the mouse cursor from start to finish without touching maze walls. 
    'Place the mouse under the start, the user will Then move the mouse through the maze To the finish.
    'If the user touches a wall With the mouse, the mouse will be reset at the starting position.
    'When  the mouse Is at the finish, the game will end with a message box congratulating you. 

    Dim close1 As Boolean = False
    Private Sub lblFinish_MouseEnter(ByVal sender As Object, ByVal e As System.EventArgs) Handles lblFinish.MouseEnter
        'Show that you won message, then closes forum
        MessageBox.Show("Awesome Job!")
        MainMenu.MazeWin = True
        close1 = True
        Close()
        'closes forum
    End Sub

    'moves back to start
    Private Sub MoveToStart()
        'moves mouse to location
        If close1 = False Then
            Dim startingPositon = Panel1.Location()
            startingPositon.Offset(10, 10)
            Cursor.Position = PointToScreen(startingPositon)
        End If
    End Sub

    Private Sub Wall_MouseEnter(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles Label87.MouseEnter, Panel2.MouseEnter, Panel1.MouseEnter, lblFinish.MouseEnter, Label9.MouseEnter, Label86.MouseEnter, Label85.MouseEnter, Label84.MouseEnter, Label83.MouseEnter, Label82.MouseEnter, Label81.MouseEnter, Label80.MouseEnter, Label8.MouseEnter, Label79.MouseEnter, Label78.MouseEnter, Label77.MouseEnter, Label76.MouseEnter, Label75.MouseEnter, Label74.MouseEnter, Label73.MouseEnter, Label72.MouseEnter, Label71.MouseEnter, Label70.MouseEnter, Label7.MouseEnter, Label69.MouseEnter, Label68.MouseEnter, Label67.MouseEnter, Label66.MouseEnter, Label65.MouseEnter, Label64.MouseEnter, Label63.MouseEnter, Label62.MouseEnter, Label61.MouseEnter, Label60.MouseEnter, Label6.MouseEnter, Label59.MouseEnter, Label58.MouseEnter, Label57.MouseEnter, Label56.MouseEnter, Label55.MouseEnter, Label54.MouseEnter, Label53.MouseEnter, Label52.MouseEnter, Label51.MouseEnter, Label50.MouseEnter, Label5.MouseEnter, Label49.MouseEnter, Label48.MouseEnter, Label47.MouseEnter, Label46.MouseEnter, Label45.MouseEnter, Label44.MouseEnter, Label43.MouseEnter, Label42.MouseEnter, Label41.MouseEnter, Label40.MouseEnter, Label4.MouseEnter, Label39.MouseEnter, Label38.MouseEnter, Label37.MouseEnter, Label36.MouseEnter, Label35.MouseEnter, Label34.MouseEnter, Label33.MouseEnter, Label32.MouseEnter, Label31.MouseEnter, Label30.MouseEnter, Label3.MouseEnter, Label29.MouseEnter, Label28.MouseEnter, Label27.MouseEnter, Label26.MouseEnter, Label25.MouseEnter, Label24.MouseEnter, Label23.MouseEnter, Label22.MouseEnter, Label21.MouseEnter, Label20.MouseEnter, Label2.MouseEnter, Label19.MouseEnter, Label18.MouseEnter, Label17.MouseEnter, Label16.MouseEnter, Label15.MouseEnter, Label14.MouseEnter, Label13.MouseEnter, Label12.MouseEnter, Label11.MouseEnter, Label10.MouseEnter, Label1.MouseEnter
        MoveToStart() 'if the mouse hits the wall, move mouse back to start

    End Sub

    Private Sub BackToInstructionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackToInstructionsToolStripMenuItem.Click
        My.Forms.MazeInstructions.Show()
    End Sub

    Private Sub BackToMenuToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackToMenuToolStripMenuItem.Click
        Close()
    End Sub
End Class