﻿Public Class RockPaperScissors
    'Vincent Caputo
    'Rock Paper Scissors
    'Objective: To reach the maximum “games won” set by the user.
    'The user will first Set a maximum points To win the game In the text box at the top Of the game. Whichever player reaches that maximum points first will win the game.
    'There will be 3 radio buttons In the middle Of the game (Rock, Paper, Scissors). The user will Select one Of those choices. Depending On what radio button Is selected, a picture will be displayed showing either a rock, paper, Or scissors.
    'Rock destroys scissors, paper destroys rock And scissors destroys paper.
    'The program will randomly Select either rock paper scissors And depending On what the user has selected, a picture will be displayed And either the computer Or player will Get a point. 
    'When the maximum points Is reached And the player wins, a message box will congratulate you And the game will close. If the user wins, a message box will be displayed And shows that the user lost And then game will close. If the user wishes to try again to win, he Or she will have to open the game again.

    Dim wins As Integer
    Dim tie As Integer
    Dim computerWin As Integer
    Private Sub btnGo_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnGo.Click
        Const rock As Integer = 1
        Const Paper As Integer = 2
        Const Scissors As Integer = 3
        Dim computerThrow As Integer
        Dim maxScore As Integer = Val(Me.txtMaxScore.Text)
        Dim restart1 As Boolean = False

        'shows error message to make you enter a max score
        If maxScore = 0 Then
            MessageBox.Show("You Must Enter A Max Score!", "Error", _
                            MessageBoxButtons.OK)
            restart1 = True
        End If
        If restart1 = True Then
            Restart()
        Else

            'picks random number
            Randomize()
            computerThrow = Int(3 * Rnd() + 1)

            'determines which to throw
            Select Case computerThrow
                Case rock
                    If Me.radRock.Checked Then 'Rock Rock
                        Me.PictureBox2.Image = My.Resources.Rock
                        Me.lblMessage.Text = "Tie!"
                        tie = tie + 1
                    ElseIf Me.radPaper.Checked Then 'Rock Paper
                        Me.PictureBox2.Image = My.Resources.Rock
                        Me.lblMessage.Text = "Winner!"
                        wins = wins + 1
                    ElseIf Me.radScissors.Checked Then 'Rock Scissors
                        Me.PictureBox2.Image = My.Resources.Rock
                        Me.lblMessage.Text = "Computer Wins!"
                        computerWin = computerWin + 1
                    End If

                Case Paper
                    If Me.radRock.Checked Then 'Paper Rock
                        Me.PictureBox2.Image = My.Resources.Paper
                        Me.lblMessage.Text = "Computer Wins!"
                        computerWin = computerWin + 1
                    ElseIf Me.radPaper.Checked Then 'Paper Paper
                        Me.PictureBox2.Image = My.Resources.Paper
                        Me.lblMessage.Text = "Tie!"
                        tie = tie + 1
                    ElseIf Me.radScissors.Checked Then 'Paper Scissors
                        Me.PictureBox2.Image = My.Resources.Paper
                        Me.lblMessage.Text = "Winner!"
                        wins = wins + 1
                    End If

                Case Scissors
                    If Me.radRock.Checked Then 'Scissors Rock
                        Me.PictureBox2.Image = My.Resources.Scissors
                        Me.lblMessage.Text = "Winner!"
                        wins = wins + 1
                    ElseIf Me.radPaper.Checked Then 'Scissors Paper
                        Me.PictureBox2.Image = My.Resources.Scissors
                        Me.lblMessage.Text = "Computer Wins!"
                        computerWin = computerWin + 1
                    ElseIf Me.radScissors.Checked Then 'Scissors Scissors
                        Me.PictureBox2.Image = My.Resources.Scissors
                        Me.lblMessage.Text = "Tie"
                        tie = tie + 1
                    End If
            End Select

            'displays scores
            Me.lblWins.Text = wins
            Me.lblTies.Text = tie
            Me.lblComputerWins.Text = computerWin

            'determines who wins
            If computerWin = Val(Me.txtMaxScore.Text) Then
                MsgBox("You Lose!")
            ElseIf wins = Val(Me.txtMaxScore.Text) Then
                MsgBox("You Win!")
                MainMenu.RockWin = True
                Close()
            End If
        End If

    End Sub

    Private Sub InstructionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs)
        'instructions
        MessageBox.Show("To play, enter a max score, who ever reaches the max score first wins.", "Instructions", _
                            MessageBoxButtons.OK)
    End Sub

    Private Sub Restart()
        'Restarts game 
        wins = 0
        tie = 0
        computerWin = 0

        Me.lblWins.Text = wins
        Me.lblTies.Text = tie
        Me.lblComputerWins.Text = computerWin
        lblMessage.Text = ""
        Me.PictureBox2.Image = Nothing
    End Sub

    Private Sub radRock_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radRock.CheckedChanged
        Me.PictureBox1.Image = My.Resources.Rock
    End Sub

    Private Sub radPaper_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radPaper.CheckedChanged
        Me.PictureBox1.Image = My.Resources.Paper
    End Sub

    Private Sub radScissors_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radScissors.CheckedChanged
        Me.PictureBox1.Image = My.Resources.Scissors
    End Sub

    Private Sub BackToInstructionsToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackToInstructionsToolStripMenuItem.Click
        My.Forms.RockPaperScissorsInstructions.Show()
    End Sub

    Private Sub BackToMenuToolStripMenuItem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles BackToMenuToolStripMenuItem.Click
        Close()
    End Sub

    Private Sub txtMaxScore_TextChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles txtMaxScore.TextChanged
        wins = 0
        tie = 0
        computerWin = 0

        Me.lblWins.Text = wins
        Me.lblTies.Text = tie
        Me.lblComputerWins.Text = computerWin
        lblMessage.Text = ""
        Me.PictureBox2.Image = Nothing
    End Sub
End Class