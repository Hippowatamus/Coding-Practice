﻿Public Class TankInstructions

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        My.Forms.Tank.Show() 'starts game and closes instructions page
        Close()
    End Sub

    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Close() 'closes page
    End Sub
End Class