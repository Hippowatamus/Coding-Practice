﻿Public Class c

    Private Sub btnStart_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnStart.Click
        My.Forms.TicTacToe.Show()
        Close() 'closes instruction page
    End Sub

    Private Sub btnBack_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBack.Click
        Close()
    End Sub

    Private Sub lblInstructions2_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles lblInstructions2.Click

    End Sub
End Class