﻿Public Class BusinessSim
    'Vincent Caputo
    'Business Sim Game
    'Objective:
    'To make 100,000,000 And retire by hiring workers, working at businesses, upgrading businesses And purchasing New businesses. Through a series of button clicks the user will achieve this And win the game.
    'User will click On buttons On the far left Of the screen. Each click Of these buttons Is work. Each time work Is done profit from the business will be made And added To the user's bank account. Profit per click will be shown below each button.
    ' Once enough money Is made the user has the choice To upgrade a business. The user will have a choice between purchasing one, five Or ten upgrades at once. This feature Is used To quickly upgrade businesses When a large sum Of money Is made. The upgrade button Is located adjacent To the right Of the work buttons. The amount Of upgrades that can be purchased at once will be controlled via 3 radio buttons located adjacent To the right Of the upgrade button. The x1 radio button will Double revenue from the business, the x5 radio button will multiply revenue by a factor Of five As well As the cost For that upgrade, And Finally the x10 radio button will multiply the revenue by a factor Of 10 And increase the cost Of the upgrade by a factor Of 10 As well. The cost Of these upgrades will be displayed below the upgrade button.
    'The final button selection For a business Is the hire worker button. This button automatically clicks On the work button Or works For you, so you don't have to click the button and can focus on another business. Keep in mind that the worker is not as fast as you and has a slower rate of click. The cost of the worker will be showed on the button itself and when the button is click that cost will be subtracted from your bank account. 
    'When you are satisfied with the business And have the finances, you can purchase another business by clicking the buy business button below your current business. The cost of this purchase will be displayed on the button. When the button Is clicked the cost will be subtracted from your bank account And the button will disappear And the New business controls will appear. These controls will be completely identical to the starting business controls
    'Once the user has $100,000,000, the user can retire And the game Is won.


    Dim money As Integer
    Dim lemUpgrade As Integer = 2
    Dim lemUpgradeCost As Integer = 8
    Dim paperUpgrade As Integer = 4
    Dim paperUpgradeCost As Integer = 16
    Dim donutShopUpgrade As Integer = 6
    Dim donutShopUpgradeCost As Integer = 24

    Private Sub lblLemonade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnLemonade.Click
        If money < 100000000 Then
            Me.btnLemonade.BackColor = Color.Yellow
            money = money + lemUpgrade 'Increasing money each time lemonade is made
            Me.lblMoney.Text = money 'Displaying money
            Me.lblLemProfit.Text = lemUpgrade ' Shows profit per click
            Me.lblLemCostUpgrade.Text = lemUpgradeCost 'Shows upgrade cost
        End If
    End Sub

    Private Sub tmrLemonade_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrLemonade.Tick
        Static colorChange As Boolean = True 'Button Flash
        If colorChange Then
            Me.btnLemonade.BackColor = Color.LightBlue
        Else
            Me.btnLemonade.BackColor = Color.Yellow
            colorChange = True
        End If
    End Sub

    Private Sub btnUpgradeLemonade_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpgradeLemonade.Click
        Me.btnUpgradeLemonade.BackColor = Color.Green

        If radLem1.Checked And money >= lemUpgradeCost Then
            money = money - lemUpgradeCost 'Takes away money for upgrade cost
            lemUpgrade = lemUpgrade * 2 'Performs upgrade (Doubling original profit each time)
            lemUpgradeCost = lemUpgradeCost * 2 'Increasing Upgrade cost
            Me.lblMoney.Text = money 'Displaying current money
        ElseIf Me.radLem5.Checked And money >= lemUpgradeCost * 5 Then
            money = money - lemUpgradeCost * 5 'Takes away money for upgrade cost
            lemUpgrade = lemUpgrade * 5 'Performs upgrade (Doubling original profit each time)
            lemUpgradeCost = lemUpgradeCost * 5 'Increasing Upgrade cost
            Me.lblMoney.Text = money 'Displaying current money
        ElseIf Me.radLem10.Checked And money >= lemUpgradeCost * 10 Then
            money = money - lemUpgradeCost * 10 'Takes away money for upgrade cost
            lemUpgrade = lemUpgrade * 10 'Performs upgrade (Doubling original profit each time)
            lemUpgradeCost = lemUpgradeCost * 10 'Increasing Upgrade cost
            Me.lblMoney.Text = money 'Displaying current money
        Else
            MessageBox.Show("Not Enough Money!", "Alert!", _
                            MessageBoxButtons.OK) 'if not enough money
        End If

        Me.lblLemProfit.Text = lemUpgrade ' Shows profit per click
        Me.lblLemCostUpgrade.Text = lemUpgradeCost 'Shows upgrade cost

    End Sub

    Private Sub tmrUpgradeLem_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrUpgradeLem.Tick
        Static colorChange As Boolean = True 'Button Flash
        If colorChange Then
            Me.btnUpgradeLemonade.BackColor = Color.LightBlue
        Else
            Me.btnUpgradeLemonade.BackColor = Color.Green
            colorChange = True
        End If
    End Sub

    Private Sub radLem1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radLem1.CheckedChanged
        Me.lblLemCostUpgrade.Text = lemUpgradeCost 'Shows upgrade cost
    End Sub

    Private Sub radLem10_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radLem5.CheckedChanged
        Me.lblLemCostUpgrade.Text = lemUpgradeCost * 5 'Shows upgrade cost
    End Sub

    Private Sub radLem5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radLem10.CheckedChanged
        Me.lblLemCostUpgrade.Text = lemUpgradeCost * 10 'Shows upgrade cost
    End Sub

    Private Sub tmrLemWorker_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrLemWorker.Tick
        Static counter As Integer = 0
        Static counterChange As Boolean = True

        If counterChange Then
            counter += 1
            counterChange = False
        Else
            counter += 1
            counterChange = True
        End If

        If counter = 5 Then
            money = money + lemUpgrade 'Increasing money each time lemonade is made
            Me.lblMoney.Text = money 'Displaying money
            Me.lblLemProfit.Text = lemUpgrade ' Shows profit per click
            Me.lblLemCostUpgrade.Text = lemUpgradeCost 'Shows upgrade cost
            counter = 0
        End If
    End Sub

    Private Sub btnHireLem_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHireLem.Click
        'hires a worker
        If money >= 500 Then
            Me.tmrLemWorker.Enabled = True
            Me.tmrLemWorker.Start()
            money = money - 500
            Me.btnHireLem.Visible = False
            Me.lblMoney.Text = money
        Else
            MessageBox.Show("Not Enough Money!", "Alert!", _
                            MessageBoxButtons.OK) 'if not enough money
        End If
    End Sub

    Private Sub btnDeliver_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDeliver.Click
        'makes money per click
        If money < 100000000 Then
            Me.btnDeliver.BackColor = Color.Black
            money = money + paperUpgrade
            Me.lblMoney.Text = money 'Displaying money
            Me.lblPaperProfit.Text = paperUpgrade ' Shows profit per click
            Me.lblPapeUpCost.Text = paperUpgradeCost 'Shows upgrade cost
        End If

    End Sub

    Private Sub tmrDeliver_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrDeliver.Tick
        Static colorChange As Boolean = True 'Button Flash
        If colorChange Then
            Me.btnDeliver.BackColor = Color.LightBlue
        Else
            Me.btnDeliver.BackColor = Color.Black
            colorChange = True
        End If
    End Sub

    Private Sub tmrUpgradePaper_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrUpgradePaper.Tick
        Static colorChange As Boolean = True 'Button Flash
        If colorChange Then
            Me.btnUpgradeNewspaper.BackColor = Color.LightBlue
        Else
            Me.btnUpgradeNewspaper.BackColor = Color.Green
            colorChange = True
        End If
    End Sub

    Private Sub btnUpgradeNewspaper_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpgradeNewspaper.Click
        Me.btnUpgradeNewspaper.BackColor = Color.Green
        'upgrades newspaper
        If radPaper1.Checked And money >= paperUpgradeCost Then
            money = money - paperUpgradeCost 'Takes away money for upgrade cost
            paperUpgrade = paperUpgrade * 2 'Performs upgrade (Doubling original profit each time)
            paperUpgradeCost = paperUpgradeCost * 2 'Increasing Upgrade cost
            Me.lblMoney.Text = money 'Displaying current money
        ElseIf Me.radPaper5.Checked And money >= paperUpgradeCost * 5 Then
            money = money - paperUpgradeCost * 5 'Takes away money for upgrade cost
            paperUpgrade = paperUpgrade * 5 'Performs upgrade (Doubling original profit each time)
            paperUpgradeCost = paperUpgradeCost * 5 'Increasing Upgrade cost
            Me.lblMoney.Text = money 'Displaying current money
        ElseIf Me.radPaper10.Checked And money >= paperUpgradeCost * 10 Then
            money = money - paperUpgradeCost * 10 'Takes away money for upgrade cost
            paperUpgrade = paperUpgrade * 10 'Performs upgrade (Doubling original profit each time)
            paperUpgradeCost = paperUpgradeCost * 10 'Increasing Upgrade cost
            Me.lblMoney.Text = money 'Displaying current money
        Else
            MessageBox.Show("Not Enough Money!", "Alert!", _
                            MessageBoxButtons.OK) 'if not enough money
        End If

        Me.lblPaperProfit.Text = paperUpgrade ' Shows profit per click
        Me.lblPapeUpCost.Text = paperUpgradeCost 'Shows upgrade cost
    End Sub

    Private Sub btnHirePaperWorker_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnHirePaperWorker.Click
        'hires paper worker 
        If money >= 25000 Then
            Me.tmrPaperWorker.Enabled = True
            Me.tmrPaperWorker.Start()
            money = money - 25000
            Me.btnHirePaperWorker.Visible = False
            Me.lblMoney.Text = money
        Else
            MessageBox.Show("Not Enough Money!", "Alert!", _
                            MessageBoxButtons.OK) 'if not enough money
        End If
    End Sub

    Private Sub tmrPaperWorker_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrPaperWorker.Tick
        Static counter As Integer = 0
        Static counterChange As Boolean = True

        If counterChange Then
            counter += 1
            counterChange = False
        Else
            counter += 1
            counterChange = True
        End If

        If counter = 8 Then
            money = money + paperUpgrade 'Increasing money each time paper is delivered 
            Me.lblMoney.Text = money 'Displaying money
            Me.lblPaperProfit.Text = paperUpgrade ' Shows profit per click
            Me.lblPapeUpCost.Text = paperUpgradeCost 'Shows upgrade cost
            counter = 0
        End If
    End Sub

    Private Sub radPaper1_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radPaper1.CheckedChanged
        Me.lblPapeUpCost.Text = paperUpgradeCost 'shows cost
    End Sub

    Private Sub radPaper5_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radPaper5.CheckedChanged
        Me.lblPapeUpCost.Text = paperUpgradeCost 'shows cost
    End Sub

    Private Sub radPaper10_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles radPaper10.CheckedChanged
        Me.lblPapeUpCost.Text = paperUpgradeCost 'shows cost
    End Sub

    Private Sub btnBuyNewspaper_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuyNewspaper.Click
        'buy newspaper company
        If money >= 10000 Then
            money = money - 10000
            lblMoney.Text = money
            Me.btnBuyNewspaper.Visible = False
            Me.lblPrrompt3.Visible = True
            Me.lblPaperProfit.Visible = True
            Me.lblUpgradePaper.Visible = True
            Me.lblPapeUpCost.Visible = True
            Me.btnHirePaperWorker.Visible = True
            Me.grpPaperUpgrade.Visible = True
            Me.radPaper1.Visible = True
            Me.radPaper5.Visible = True
            Me.radPaper10.Visible = True
            Me.btnDeliver.Visible = True
            Me.btnUpgradeNewspaper.Visible = True
        Else
            MessageBox.Show("Not Enough Money!", "Alert!",
                            MessageBoxButtons.OK) 'if not enough money
        End If

    End Sub

    Private Sub btnDonutShop_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnDonutShop.Click
        If money < 100000000 Then
            money = money + donutShopUpgrade 'makes money
            Me.lblDonutUpCost.Text = donutShopUpgradeCost
            Me.lblMoney.Text = money 'Displays money
            Me.lblDonutProfit.Text = donutShopUpgrade ' displays profit per click
            Me.lblDonutUpCost.Text = donutShopUpgradeCost ' displays upgrade cost
        End If
    End Sub

    Private Sub btnUpgradeDonut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnUpgradeDonut.Click
        'upgrade donut
        If radDonut1.Checked And money >= donutShopUpgradeCost Then
            money = money - donutShopUpgradeCost 'Takes away money for upgrade cost
            donutShopUpgrade = donutShopUpgrade * 2 'Performs upgrade (Doubling original profit each time)
            donutShopUpgradeCost = donutShopUpgradeCost * 2 'Increasing Upgrade cost
            Me.lblMoney.Text = money 'Displaying current money
        ElseIf Me.radDonut5.Checked And money >= donutShopUpgradeCost * 5 Then
            money = money - donutShopUpgradeCost * 5 'Takes away money for upgrade cost
            donutShopUpgrade = donutShopUpgrade * 5 'Performs upgrade (Doubling original profit each time)
            donutShopUpgradeCost = donutShopUpgradeCost * 5 'Increasing Upgrade cost
            Me.lblMoney.Text = money 'Displaying current money
        ElseIf Me.radDonut10.Checked And money >= donutShopUpgradeCost * 10 Then
            money = money - paperUpgradeCost * 10 'Takes away money for upgrade cost
            donutShopUpgrade = donutShopUpgrade * 10 'Performs upgrade (Doubling original profit each time)
            donutShopUpgradeCost = donutShopUpgradeCost * 10 'Increasing Upgrade cost
            Me.lblMoney.Text = money 'Displaying current money
        Else
            MessageBox.Show("Not Enough Money!", "Alert!", _
                            MessageBoxButtons.OK) 'if not enough money
        End If
    End Sub

    Private Sub btnBuyDonut_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnBuyDonut.Click
        'buy donut shop
        If money >= 100000 Then
            Me.btnBuyDonut.Visible = False
            Me.btnDonutShop.Visible = True
            Me.btnUpgradeDonut.Visible = True
            Me.lblPrompt4.Visible = True
            Me.lblDonutProfit.Visible = True
            Me.lblDonutUpCost.Visible = True
            Me.lblDonutUpgr.Visible = True
            btnHireDonutWorker.Visible = True
            Me.radDonut1.Visible = True
            Me.radDonut5.Visible = True
            Me.radDonut10.Visible = True
            Me.grpDonutShop.Visible = True
        Else
            MessageBox.Show("Not Enough Money!", "Alert!", _
                            MessageBoxButtons.OK) 'if not enough money
        End If
    End Sub

    Private Sub tmrDonutUpg_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrDonutUpg.Tick
        Static colorChange As Boolean = True 'Button Flash
        If colorChange Then
            Me.btnDeliver.BackColor = Color.LightBlue
        Else
            Me.btnDonutShop.BackColor = Color.Brown
            colorChange = True
        End If
    End Sub

    Private Sub tmrDonut_Tick(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles tmrDonut.Tick
        Static colorChange As Boolean = True 'Button Flash
        If colorChange Then
            Me.btnDeliver.BackColor = Color.LightBlue
        Else
            Me.btnUpgradeDonut.BackColor = Color.Green
            colorChange = True
        End If
    End Sub

    Private Sub btnRetire_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnRetire.Click

        If money >= 100000000 Then
            money -= 100000000
            Me.lblMoney.Text = money
            MessageBox.Show("Congratulations! You became successfull!", "Game Won", MessageBoxButtons.OK)
            MainMenu.BusinessWin = True
            Close()
        End If

    End Sub

    Private Sub InstructionsToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles InstructionsToolStripMenuItem.Click
        MessageBox.Show("To play, start by clicking the button on the top right to start making lemonade. Each time you make lemonade, you make money. Use your money to upgrade and hire a worker for your buisness. You also have the option to buy more buisnesses. The goal of the game is to make enough money to retire in style.", "Instructions")
    End Sub

    Private Sub HelpToolStripMenuItem_Click(sender As Object, e As EventArgs) Handles HelpToolStripMenuItem.Click

    End Sub
End Class