﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Tank
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Me.tmrMove = New System.Windows.Forms.Timer(Me.components)
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.BackToInstructionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackToMenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.picBomb6 = New System.Windows.Forms.PictureBox()
        Me.picBomb7 = New System.Windows.Forms.PictureBox()
        Me.picBomb4 = New System.Windows.Forms.PictureBox()
        Me.picBomb5 = New System.Windows.Forms.PictureBox()
        Me.picBomb3 = New System.Windows.Forms.PictureBox()
        Me.picBomb1 = New System.Windows.Forms.PictureBox()
        Me.picBomb2 = New System.Windows.Forms.PictureBox()
        Me.picBot4 = New System.Windows.Forms.PictureBox()
        Me.picBot3 = New System.Windows.Forms.PictureBox()
        Me.picLevel1Bot2 = New System.Windows.Forms.PictureBox()
        Me.picLevel1Bot1 = New System.Windows.Forms.PictureBox()
        Me.picBottomWall = New System.Windows.Forms.PictureBox()
        Me.picLeftWall = New System.Windows.Forms.PictureBox()
        Me.picTank = New System.Windows.Forms.PictureBox()
        Me.picTopWall = New System.Windows.Forms.PictureBox()
        Me.picRightWall = New System.Windows.Forms.PictureBox()
        Me.MenuStrip1.SuspendLayout()
        CType(Me.picBomb6, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBomb7, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBomb4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBomb5, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBomb3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBomb1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBomb2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBot4, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBot3, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLevel1Bot2, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLevel1Bot1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picBottomWall, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picLeftWall, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTank, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picTopWall, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picRightWall, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'tmrMove
        '
        Me.tmrMove.Enabled = True
        Me.tmrMove.Interval = 1
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackToInstructionsToolStripMenuItem, Me.BackToMenuToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(480, 24)
        Me.MenuStrip1.TabIndex = 31
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'BackToInstructionsToolStripMenuItem
        '
        Me.BackToInstructionsToolStripMenuItem.Name = "BackToInstructionsToolStripMenuItem"
        Me.BackToInstructionsToolStripMenuItem.Size = New System.Drawing.Size(125, 20)
        Me.BackToInstructionsToolStripMenuItem.Text = "Back To Instructions"
        '
        'BackToMenuToolStripMenuItem
        '
        Me.BackToMenuToolStripMenuItem.Name = "BackToMenuToolStripMenuItem"
        Me.BackToMenuToolStripMenuItem.Size = New System.Drawing.Size(94, 20)
        Me.BackToMenuToolStripMenuItem.Text = "Back To Menu"
        '
        'picBomb6
        '
        Me.picBomb6.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Bomb
        Me.picBomb6.Location = New System.Drawing.Point(366, 74)
        Me.picBomb6.Name = "picBomb6"
        Me.picBomb6.Size = New System.Drawing.Size(46, 43)
        Me.picBomb6.TabIndex = 42
        Me.picBomb6.TabStop = False
        '
        'picBomb7
        '
        Me.picBomb7.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Bomb
        Me.picBomb7.Location = New System.Drawing.Point(316, 325)
        Me.picBomb7.Name = "picBomb7"
        Me.picBomb7.Size = New System.Drawing.Size(46, 43)
        Me.picBomb7.TabIndex = 41
        Me.picBomb7.TabStop = False
        '
        'picBomb4
        '
        Me.picBomb4.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Bomb
        Me.picBomb4.Location = New System.Drawing.Point(170, 102)
        Me.picBomb4.Name = "picBomb4"
        Me.picBomb4.Size = New System.Drawing.Size(46, 43)
        Me.picBomb4.TabIndex = 40
        Me.picBomb4.TabStop = False
        '
        'picBomb5
        '
        Me.picBomb5.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Bomb
        Me.picBomb5.Location = New System.Drawing.Point(109, 53)
        Me.picBomb5.Name = "picBomb5"
        Me.picBomb5.Size = New System.Drawing.Size(46, 43)
        Me.picBomb5.TabIndex = 39
        Me.picBomb5.TabStop = False
        '
        'picBomb3
        '
        Me.picBomb3.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Bomb
        Me.picBomb3.Location = New System.Drawing.Point(99, 325)
        Me.picBomb3.Name = "picBomb3"
        Me.picBomb3.Size = New System.Drawing.Size(46, 43)
        Me.picBomb3.TabIndex = 38
        Me.picBomb3.TabStop = False
        '
        'picBomb1
        '
        Me.picBomb1.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Bomb
        Me.picBomb1.Location = New System.Drawing.Point(40, 153)
        Me.picBomb1.Name = "picBomb1"
        Me.picBomb1.Size = New System.Drawing.Size(46, 43)
        Me.picBomb1.TabIndex = 37
        Me.picBomb1.TabStop = False
        '
        'picBomb2
        '
        Me.picBomb2.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Bomb
        Me.picBomb2.Location = New System.Drawing.Point(99, 202)
        Me.picBomb2.Name = "picBomb2"
        Me.picBomb2.Size = New System.Drawing.Size(46, 43)
        Me.picBomb2.TabIndex = 36
        Me.picBomb2.TabStop = False
        '
        'picBot4
        '
        Me.picBot4.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Turret_Right
        Me.picBot4.Location = New System.Drawing.Point(99, 264)
        Me.picBot4.Name = "picBot4"
        Me.picBot4.Size = New System.Drawing.Size(46, 43)
        Me.picBot4.TabIndex = 35
        Me.picBot4.TabStop = False
        '
        'picBot3
        '
        Me.picBot3.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Turret_Right
        Me.picBot3.Location = New System.Drawing.Point(99, 102)
        Me.picBot3.Name = "picBot3"
        Me.picBot3.Size = New System.Drawing.Size(46, 43)
        Me.picBot3.TabIndex = 34
        Me.picBot3.TabStop = False
        '
        'picLevel1Bot2
        '
        Me.picLevel1Bot2.BackColor = System.Drawing.Color.Transparent
        Me.picLevel1Bot2.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Turret_Right
        Me.picLevel1Bot2.Location = New System.Drawing.Point(40, 309)
        Me.picLevel1Bot2.Name = "picLevel1Bot2"
        Me.picLevel1Bot2.Size = New System.Drawing.Size(46, 43)
        Me.picLevel1Bot2.TabIndex = 33
        Me.picLevel1Bot2.TabStop = False
        '
        'picLevel1Bot1
        '
        Me.picLevel1Bot1.BackColor = System.Drawing.Color.Transparent
        Me.picLevel1Bot1.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Turret_Right
        Me.picLevel1Bot1.Location = New System.Drawing.Point(40, 50)
        Me.picLevel1Bot1.Name = "picLevel1Bot1"
        Me.picLevel1Bot1.Size = New System.Drawing.Size(46, 43)
        Me.picLevel1Bot1.TabIndex = 32
        Me.picLevel1Bot1.TabStop = False
        '
        'picBottomWall
        '
        Me.picBottomWall.BackColor = System.Drawing.Color.DarkRed
        Me.picBottomWall.Location = New System.Drawing.Point(-7, 400)
        Me.picBottomWall.Name = "picBottomWall"
        Me.picBottomWall.Size = New System.Drawing.Size(493, 47)
        Me.picBottomWall.TabIndex = 30
        Me.picBottomWall.TabStop = False
        '
        'picLeftWall
        '
        Me.picLeftWall.BackColor = System.Drawing.Color.DarkRed
        Me.picLeftWall.Location = New System.Drawing.Point(-20, 8)
        Me.picLeftWall.Name = "picLeftWall"
        Me.picLeftWall.Size = New System.Drawing.Size(34, 422)
        Me.picLeftWall.TabIndex = 29
        Me.picLeftWall.TabStop = False
        '
        'picTank
        '
        Me.picTank.BackColor = System.Drawing.SystemColors.Control
        Me.picTank.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.Tank
        Me.picTank.Location = New System.Drawing.Point(233, 165)
        Me.picTank.Name = "picTank"
        Me.picTank.Size = New System.Drawing.Size(46, 43)
        Me.picTank.TabIndex = 26
        Me.picTank.TabStop = False
        '
        'picTopWall
        '
        Me.picTopWall.BackColor = System.Drawing.Color.DarkRed
        Me.picTopWall.Location = New System.Drawing.Point(-7, 8)
        Me.picTopWall.Name = "picTopWall"
        Me.picTopWall.Size = New System.Drawing.Size(493, 25)
        Me.picTopWall.TabIndex = 28
        Me.picTopWall.TabStop = False
        '
        'picRightWall
        '
        Me.picRightWall.BackColor = System.Drawing.Color.DarkRed
        Me.picRightWall.Location = New System.Drawing.Point(465, 8)
        Me.picRightWall.Name = "picRightWall"
        Me.picRightWall.Size = New System.Drawing.Size(36, 422)
        Me.picRightWall.TabIndex = 27
        Me.picRightWall.TabStop = False
        '
        'Tank
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(480, 431)
        Me.Controls.Add(Me.picBomb6)
        Me.Controls.Add(Me.picBomb7)
        Me.Controls.Add(Me.picBomb4)
        Me.Controls.Add(Me.picBomb5)
        Me.Controls.Add(Me.picBomb3)
        Me.Controls.Add(Me.picBomb1)
        Me.Controls.Add(Me.picBomb2)
        Me.Controls.Add(Me.picBottomWall)
        Me.Controls.Add(Me.picLeftWall)
        Me.Controls.Add(Me.picTank)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.picTopWall)
        Me.Controls.Add(Me.picRightWall)
        Me.Controls.Add(Me.picBot3)
        Me.Controls.Add(Me.picLevel1Bot1)
        Me.Controls.Add(Me.picBot4)
        Me.Controls.Add(Me.picLevel1Bot2)
        Me.Name = "Tank"
        Me.Text = "Tank Game"
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        CType(Me.picBomb6, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBomb7, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBomb4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBomb5, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBomb3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBomb1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBomb2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBot4, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBot3, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLevel1Bot2, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLevel1Bot1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picBottomWall, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picLeftWall, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTank, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picTopWall, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picRightWall, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents picBomb6 As System.Windows.Forms.PictureBox
    Friend WithEvents picBomb7 As System.Windows.Forms.PictureBox
    Friend WithEvents picBomb4 As System.Windows.Forms.PictureBox
    Friend WithEvents picBomb5 As System.Windows.Forms.PictureBox
    Friend WithEvents picBomb3 As System.Windows.Forms.PictureBox
    Friend WithEvents picBomb1 As System.Windows.Forms.PictureBox
    Friend WithEvents picBomb2 As System.Windows.Forms.PictureBox
    Friend WithEvents picBot4 As System.Windows.Forms.PictureBox
    Friend WithEvents tmrMove As System.Windows.Forms.Timer
    Friend WithEvents picBot3 As System.Windows.Forms.PictureBox
    Friend WithEvents picLevel1Bot2 As System.Windows.Forms.PictureBox
    Friend WithEvents picLevel1Bot1 As System.Windows.Forms.PictureBox
    Friend WithEvents picBottomWall As System.Windows.Forms.PictureBox
    Friend WithEvents picLeftWall As System.Windows.Forms.PictureBox
    Friend WithEvents picTank As System.Windows.Forms.PictureBox
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents picTopWall As System.Windows.Forms.PictureBox
    Friend WithEvents picRightWall As System.Windows.Forms.PictureBox
    Friend WithEvents BackToInstructionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackToMenuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
