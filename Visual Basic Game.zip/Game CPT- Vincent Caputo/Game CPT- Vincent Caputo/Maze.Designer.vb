﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class Maze
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.Label64 = New System.Windows.Forms.Label()
        Me.Label65 = New System.Windows.Forms.Label()
        Me.Label66 = New System.Windows.Forms.Label()
        Me.Label67 = New System.Windows.Forms.Label()
        Me.Label68 = New System.Windows.Forms.Label()
        Me.Label69 = New System.Windows.Forms.Label()
        Me.Label72 = New System.Windows.Forms.Label()
        Me.Label74 = New System.Windows.Forms.Label()
        Me.Label75 = New System.Windows.Forms.Label()
        Me.Label70 = New System.Windows.Forms.Label()
        Me.Label71 = New System.Windows.Forms.Label()
        Me.Label76 = New System.Windows.Forms.Label()
        Me.Label77 = New System.Windows.Forms.Label()
        Me.Panel2 = New System.Windows.Forms.Panel()
        Me.lblStart = New System.Windows.Forms.Label()
        Me.Label87 = New System.Windows.Forms.Label()
        Me.lblFinish = New System.Windows.Forms.Label()
        Me.Label43 = New System.Windows.Forms.Label()
        Me.Label48 = New System.Windows.Forms.Label()
        Me.Label86 = New System.Windows.Forms.Label()
        Me.Label53 = New System.Windows.Forms.Label()
        Me.Label85 = New System.Windows.Forms.Label()
        Me.Label44 = New System.Windows.Forms.Label()
        Me.Label45 = New System.Windows.Forms.Label()
        Me.Label46 = New System.Windows.Forms.Label()
        Me.Label47 = New System.Windows.Forms.Label()
        Me.Label49 = New System.Windows.Forms.Label()
        Me.Label50 = New System.Windows.Forms.Label()
        Me.Label51 = New System.Windows.Forms.Label()
        Me.Label52 = New System.Windows.Forms.Label()
        Me.Label54 = New System.Windows.Forms.Label()
        Me.Label55 = New System.Windows.Forms.Label()
        Me.Label56 = New System.Windows.Forms.Label()
        Me.Label57 = New System.Windows.Forms.Label()
        Me.Label58 = New System.Windows.Forms.Label()
        Me.Label59 = New System.Windows.Forms.Label()
        Me.Label60 = New System.Windows.Forms.Label()
        Me.Label61 = New System.Windows.Forms.Label()
        Me.Label62 = New System.Windows.Forms.Label()
        Me.Label63 = New System.Windows.Forms.Label()
        Me.Label73 = New System.Windows.Forms.Label()
        Me.Label78 = New System.Windows.Forms.Label()
        Me.Label79 = New System.Windows.Forms.Label()
        Me.Label80 = New System.Windows.Forms.Label()
        Me.Label81 = New System.Windows.Forms.Label()
        Me.Label82 = New System.Windows.Forms.Label()
        Me.Label83 = New System.Windows.Forms.Label()
        Me.Label84 = New System.Windows.Forms.Label()
        Me.MenuStrip1 = New System.Windows.Forms.MenuStrip()
        Me.BackToInstructionsToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.ToolStripMenuItem1 = New System.Windows.Forms.ToolStripMenuItem()
        Me.BackToMenuToolStripMenuItem = New System.Windows.Forms.ToolStripMenuItem()
        Me.Label42 = New System.Windows.Forms.Label()
        Me.Label41 = New System.Windows.Forms.Label()
        Me.Label40 = New System.Windows.Forms.Label()
        Me.Label39 = New System.Windows.Forms.Label()
        Me.Label38 = New System.Windows.Forms.Label()
        Me.Label37 = New System.Windows.Forms.Label()
        Me.Label36 = New System.Windows.Forms.Label()
        Me.Label35 = New System.Windows.Forms.Label()
        Me.Label34 = New System.Windows.Forms.Label()
        Me.Label31 = New System.Windows.Forms.Label()
        Me.Label33 = New System.Windows.Forms.Label()
        Me.Label32 = New System.Windows.Forms.Label()
        Me.Label30 = New System.Windows.Forms.Label()
        Me.Label29 = New System.Windows.Forms.Label()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.Label28 = New System.Windows.Forms.Label()
        Me.Label27 = New System.Windows.Forms.Label()
        Me.Label26 = New System.Windows.Forms.Label()
        Me.Label25 = New System.Windows.Forms.Label()
        Me.Label24 = New System.Windows.Forms.Label()
        Me.Label23 = New System.Windows.Forms.Label()
        Me.Label22 = New System.Windows.Forms.Label()
        Me.Label21 = New System.Windows.Forms.Label()
        Me.Label20 = New System.Windows.Forms.Label()
        Me.Label19 = New System.Windows.Forms.Label()
        Me.Label18 = New System.Windows.Forms.Label()
        Me.Label17 = New System.Windows.Forms.Label()
        Me.Label16 = New System.Windows.Forms.Label()
        Me.Label15 = New System.Windows.Forms.Label()
        Me.Label14 = New System.Windows.Forms.Label()
        Me.Label13 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Panel2.SuspendLayout()
        Me.MenuStrip1.SuspendLayout()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'Label64
        '
        Me.Label64.BackColor = System.Drawing.Color.ForestGreen
        Me.Label64.Location = New System.Drawing.Point(62, 200)
        Me.Label64.Name = "Label64"
        Me.Label64.Size = New System.Drawing.Size(23, 75)
        Me.Label64.TabIndex = 20
        '
        'Label65
        '
        Me.Label65.BackColor = System.Drawing.Color.ForestGreen
        Me.Label65.Location = New System.Drawing.Point(246, 123)
        Me.Label65.Name = "Label65"
        Me.Label65.Size = New System.Drawing.Size(23, 100)
        Me.Label65.TabIndex = 19
        '
        'Label66
        '
        Me.Label66.BackColor = System.Drawing.Color.ForestGreen
        Me.Label66.Location = New System.Drawing.Point(246, 23)
        Me.Label66.Name = "Label66"
        Me.Label66.Size = New System.Drawing.Size(23, 100)
        Me.Label66.TabIndex = 18
        '
        'Label67
        '
        Me.Label67.BackColor = System.Drawing.Color.ForestGreen
        Me.Label67.Location = New System.Drawing.Point(-5, 196)
        Me.Label67.Name = "Label67"
        Me.Label67.Size = New System.Drawing.Size(23, 100)
        Me.Label67.TabIndex = 17
        '
        'Label68
        '
        Me.Label68.BackColor = System.Drawing.Color.ForestGreen
        Me.Label68.Location = New System.Drawing.Point(121, 61)
        Me.Label68.Name = "Label68"
        Me.Label68.Size = New System.Drawing.Size(23, 100)
        Me.Label68.TabIndex = 16
        '
        'Label69
        '
        Me.Label69.BackColor = System.Drawing.Color.ForestGreen
        Me.Label69.Location = New System.Drawing.Point(188, 61)
        Me.Label69.Name = "Label69"
        Me.Label69.Size = New System.Drawing.Size(23, 100)
        Me.Label69.TabIndex = 15
        '
        'Label72
        '
        Me.Label72.BackColor = System.Drawing.Color.ForestGreen
        Me.Label72.Location = New System.Drawing.Point(3, 390)
        Me.Label72.Name = "Label72"
        Me.Label72.Size = New System.Drawing.Size(100, 23)
        Me.Label72.TabIndex = 12
        '
        'Label74
        '
        Me.Label74.BackColor = System.Drawing.Color.ForestGreen
        Me.Label74.Location = New System.Drawing.Point(13, 327)
        Me.Label74.Name = "Label74"
        Me.Label74.Size = New System.Drawing.Size(100, 23)
        Me.Label74.TabIndex = 10
        '
        'Label75
        '
        Me.Label75.BackColor = System.Drawing.Color.ForestGreen
        Me.Label75.Location = New System.Drawing.Point(62, 200)
        Me.Label75.Name = "Label75"
        Me.Label75.Size = New System.Drawing.Size(100, 23)
        Me.Label75.TabIndex = 9
        '
        'Label70
        '
        Me.Label70.BackColor = System.Drawing.Color.ForestGreen
        Me.Label70.Location = New System.Drawing.Point(78, 0)
        Me.Label70.Name = "Label70"
        Me.Label70.Size = New System.Drawing.Size(23, 100)
        Me.Label70.TabIndex = 14
        '
        'Label71
        '
        Me.Label71.BackColor = System.Drawing.Color.ForestGreen
        Me.Label71.Location = New System.Drawing.Point(-5, 98)
        Me.Label71.Name = "Label71"
        Me.Label71.Size = New System.Drawing.Size(23, 100)
        Me.Label71.TabIndex = 13
        '
        'Label76
        '
        Me.Label76.BackColor = System.Drawing.Color.ForestGreen
        Me.Label76.Location = New System.Drawing.Point(124, 61)
        Me.Label76.Name = "Label76"
        Me.Label76.Size = New System.Drawing.Size(87, 23)
        Me.Label76.TabIndex = 8
        '
        'Label77
        '
        Me.Label77.BackColor = System.Drawing.Color.ForestGreen
        Me.Label77.Location = New System.Drawing.Point(78, 200)
        Me.Label77.Name = "Label77"
        Me.Label77.Size = New System.Drawing.Size(100, 23)
        Me.Label77.TabIndex = 7
        '
        'Panel2
        '
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel2.Controls.Add(Me.lblStart)
        Me.Panel2.Controls.Add(Me.Label87)
        Me.Panel2.Controls.Add(Me.lblFinish)
        Me.Panel2.Controls.Add(Me.Label43)
        Me.Panel2.Controls.Add(Me.Label48)
        Me.Panel2.Controls.Add(Me.Label86)
        Me.Panel2.Controls.Add(Me.Label53)
        Me.Panel2.Controls.Add(Me.Label85)
        Me.Panel2.Controls.Add(Me.Label44)
        Me.Panel2.Controls.Add(Me.Label45)
        Me.Panel2.Controls.Add(Me.Label46)
        Me.Panel2.Controls.Add(Me.Label47)
        Me.Panel2.Controls.Add(Me.Label49)
        Me.Panel2.Controls.Add(Me.Label50)
        Me.Panel2.Controls.Add(Me.Label51)
        Me.Panel2.Controls.Add(Me.Label52)
        Me.Panel2.Controls.Add(Me.Label54)
        Me.Panel2.Controls.Add(Me.Label55)
        Me.Panel2.Controls.Add(Me.Label56)
        Me.Panel2.Controls.Add(Me.Label57)
        Me.Panel2.Controls.Add(Me.Label58)
        Me.Panel2.Controls.Add(Me.Label59)
        Me.Panel2.Controls.Add(Me.Label60)
        Me.Panel2.Controls.Add(Me.Label61)
        Me.Panel2.Controls.Add(Me.Label62)
        Me.Panel2.Controls.Add(Me.Label63)
        Me.Panel2.Controls.Add(Me.Label64)
        Me.Panel2.Controls.Add(Me.Label65)
        Me.Panel2.Controls.Add(Me.Label66)
        Me.Panel2.Controls.Add(Me.Label67)
        Me.Panel2.Controls.Add(Me.Label68)
        Me.Panel2.Controls.Add(Me.Label69)
        Me.Panel2.Controls.Add(Me.Label70)
        Me.Panel2.Controls.Add(Me.Label71)
        Me.Panel2.Controls.Add(Me.Label72)
        Me.Panel2.Controls.Add(Me.Label73)
        Me.Panel2.Controls.Add(Me.Label74)
        Me.Panel2.Controls.Add(Me.Label75)
        Me.Panel2.Controls.Add(Me.Label76)
        Me.Panel2.Controls.Add(Me.Label77)
        Me.Panel2.Controls.Add(Me.Label78)
        Me.Panel2.Controls.Add(Me.Label79)
        Me.Panel2.Controls.Add(Me.Label80)
        Me.Panel2.Controls.Add(Me.Label81)
        Me.Panel2.Controls.Add(Me.Label82)
        Me.Panel2.Controls.Add(Me.Label83)
        Me.Panel2.Controls.Add(Me.Label84)
        Me.Panel2.Location = New System.Drawing.Point(-2, -2)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(453, 417)
        Me.Panel2.TabIndex = 42
        '
        'lblStart
        '
        Me.lblStart.AutoSize = True
        Me.lblStart.BackColor = System.Drawing.Color.Transparent
        Me.lblStart.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblStart.Location = New System.Drawing.Point(15, -7)
        Me.lblStart.Name = "lblStart"
        Me.lblStart.Size = New System.Drawing.Size(49, 20)
        Me.lblStart.TabIndex = 2
        Me.lblStart.Text = "Start"
        '
        'Label87
        '
        Me.Label87.BackColor = System.Drawing.Color.ForestGreen
        Me.Label87.Location = New System.Drawing.Point(-2, 48)
        Me.Label87.Name = "Label87"
        Me.Label87.Size = New System.Drawing.Size(46, 23)
        Me.Label87.TabIndex = 48
        '
        'lblFinish
        '
        Me.lblFinish.AutoSize = True
        Me.lblFinish.BackColor = System.Drawing.Color.Transparent
        Me.lblFinish.Font = New System.Drawing.Font("Microsoft Sans Serif", 15.75!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFinish.Location = New System.Drawing.Point(384, 384)
        Me.lblFinish.Name = "lblFinish"
        Me.lblFinish.Size = New System.Drawing.Size(76, 25)
        Me.lblFinish.TabIndex = 47
        Me.lblFinish.Text = "Finish"
        '
        'Label43
        '
        Me.Label43.BackColor = System.Drawing.Color.ForestGreen
        Me.Label43.Location = New System.Drawing.Point(358, 61)
        Me.Label43.Name = "Label43"
        Me.Label43.Size = New System.Drawing.Size(93, 23)
        Me.Label43.TabIndex = 46
        '
        'Label48
        '
        Me.Label48.BackColor = System.Drawing.Color.ForestGreen
        Me.Label48.Location = New System.Drawing.Point(355, 327)
        Me.Label48.Name = "Label48"
        Me.Label48.Size = New System.Drawing.Size(93, 23)
        Me.Label48.TabIndex = 45
        '
        'Label86
        '
        Me.Label86.BackColor = System.Drawing.Color.ForestGreen
        Me.Label86.Location = New System.Drawing.Point(355, 61)
        Me.Label86.Name = "Label86"
        Me.Label86.Size = New System.Drawing.Size(23, 118)
        Me.Label86.TabIndex = 44
        '
        'Label53
        '
        Me.Label53.BackColor = System.Drawing.Color.ForestGreen
        Me.Label53.Location = New System.Drawing.Point(355, 223)
        Me.Label53.Name = "Label53"
        Me.Label53.Size = New System.Drawing.Size(23, 100)
        Me.Label53.TabIndex = 43
        '
        'Label85
        '
        Me.Label85.BackColor = System.Drawing.Color.ForestGreen
        Me.Label85.Location = New System.Drawing.Point(355, 223)
        Me.Label85.Name = "Label85"
        Me.Label85.Size = New System.Drawing.Size(23, 113)
        Me.Label85.TabIndex = 42
        '
        'Label44
        '
        Me.Label44.BackColor = System.Drawing.Color.ForestGreen
        Me.Label44.Location = New System.Drawing.Point(428, 290)
        Me.Label44.Name = "Label44"
        Me.Label44.Size = New System.Drawing.Size(23, 91)
        Me.Label44.TabIndex = 40
        '
        'Label45
        '
        Me.Label45.BackColor = System.Drawing.Color.ForestGreen
        Me.Label45.Location = New System.Drawing.Point(428, 200)
        Me.Label45.Name = "Label45"
        Me.Label45.Size = New System.Drawing.Size(23, 100)
        Me.Label45.TabIndex = 39
        '
        'Label46
        '
        Me.Label46.BackColor = System.Drawing.Color.ForestGreen
        Me.Label46.Location = New System.Drawing.Point(428, 102)
        Me.Label46.Name = "Label46"
        Me.Label46.Size = New System.Drawing.Size(23, 100)
        Me.Label46.TabIndex = 38
        '
        'Label47
        '
        Me.Label47.BackColor = System.Drawing.Color.ForestGreen
        Me.Label47.Location = New System.Drawing.Point(428, 2)
        Me.Label47.Name = "Label47"
        Me.Label47.Size = New System.Drawing.Size(23, 100)
        Me.Label47.TabIndex = 37
        '
        'Label49
        '
        Me.Label49.BackColor = System.Drawing.Color.ForestGreen
        Me.Label49.Location = New System.Drawing.Point(294, 102)
        Me.Label49.Name = "Label49"
        Me.Label49.Size = New System.Drawing.Size(23, 100)
        Me.Label49.TabIndex = 35
        '
        'Label50
        '
        Me.Label50.BackColor = System.Drawing.Color.ForestGreen
        Me.Label50.Location = New System.Drawing.Point(294, 61)
        Me.Label50.Name = "Label50"
        Me.Label50.Size = New System.Drawing.Size(23, 100)
        Me.Label50.TabIndex = 34
        '
        'Label51
        '
        Me.Label51.BackColor = System.Drawing.Color.ForestGreen
        Me.Label51.Location = New System.Drawing.Point(294, 200)
        Me.Label51.Name = "Label51"
        Me.Label51.Size = New System.Drawing.Size(23, 100)
        Me.Label51.TabIndex = 33
        '
        'Label52
        '
        Me.Label52.BackColor = System.Drawing.Color.ForestGreen
        Me.Label52.Location = New System.Drawing.Point(351, 0)
        Me.Label52.Name = "Label52"
        Me.Label52.Size = New System.Drawing.Size(100, 23)
        Me.Label52.TabIndex = 32
        '
        'Label54
        '
        Me.Label54.BackColor = System.Drawing.Color.ForestGreen
        Me.Label54.Location = New System.Drawing.Point(278, 390)
        Me.Label54.Name = "Label54"
        Me.Label54.Size = New System.Drawing.Size(100, 23)
        Me.Label54.TabIndex = 30
        '
        'Label55
        '
        Me.Label55.BackColor = System.Drawing.Color.ForestGreen
        Me.Label55.Location = New System.Drawing.Point(94, 390)
        Me.Label55.Name = "Label55"
        Me.Label55.Size = New System.Drawing.Size(100, 23)
        Me.Label55.TabIndex = 29
        '
        'Label56
        '
        Me.Label56.BackColor = System.Drawing.Color.ForestGreen
        Me.Label56.Location = New System.Drawing.Point(188, 390)
        Me.Label56.Name = "Label56"
        Me.Label56.Size = New System.Drawing.Size(100, 23)
        Me.Label56.TabIndex = 28
        '
        'Label57
        '
        Me.Label57.BackColor = System.Drawing.Color.ForestGreen
        Me.Label57.Location = New System.Drawing.Point(94, 327)
        Me.Label57.Name = "Label57"
        Me.Label57.Size = New System.Drawing.Size(100, 23)
        Me.Label57.TabIndex = 27
        '
        'Label58
        '
        Me.Label58.BackColor = System.Drawing.Color.ForestGreen
        Me.Label58.Location = New System.Drawing.Point(111, 267)
        Me.Label58.Name = "Label58"
        Me.Label58.Size = New System.Drawing.Size(100, 23)
        Me.Label58.TabIndex = 26
        '
        'Label59
        '
        Me.Label59.BackColor = System.Drawing.Color.ForestGreen
        Me.Label59.Location = New System.Drawing.Point(294, 290)
        Me.Label59.Name = "Label59"
        Me.Label59.Size = New System.Drawing.Size(23, 100)
        Me.Label59.TabIndex = 25
        '
        'Label60
        '
        Me.Label60.BackColor = System.Drawing.Color.ForestGreen
        Me.Label60.Location = New System.Drawing.Point(246, 267)
        Me.Label60.Name = "Label60"
        Me.Label60.Size = New System.Drawing.Size(23, 69)
        Me.Label60.TabIndex = 24
        '
        'Label61
        '
        Me.Label61.BackColor = System.Drawing.Color.ForestGreen
        Me.Label61.Location = New System.Drawing.Point(246, 223)
        Me.Label61.Name = "Label61"
        Me.Label61.Size = New System.Drawing.Size(23, 100)
        Me.Label61.TabIndex = 23
        '
        'Label62
        '
        Me.Label62.BackColor = System.Drawing.Color.ForestGreen
        Me.Label62.Location = New System.Drawing.Point(-5, 267)
        Me.Label62.Name = "Label62"
        Me.Label62.Size = New System.Drawing.Size(23, 100)
        Me.Label62.TabIndex = 22
        '
        'Label63
        '
        Me.Label63.BackColor = System.Drawing.Color.ForestGreen
        Me.Label63.Location = New System.Drawing.Point(-5, 327)
        Me.Label63.Name = "Label63"
        Me.Label63.Size = New System.Drawing.Size(23, 100)
        Me.Label63.TabIndex = 21
        '
        'Label73
        '
        Me.Label73.BackColor = System.Drawing.Color.ForestGreen
        Me.Label73.Location = New System.Drawing.Point(62, 267)
        Me.Label73.Name = "Label73"
        Me.Label73.Size = New System.Drawing.Size(100, 23)
        Me.Label73.TabIndex = 11
        '
        'Label78
        '
        Me.Label78.BackColor = System.Drawing.Color.ForestGreen
        Me.Label78.Location = New System.Drawing.Point(169, 200)
        Me.Label78.Name = "Label78"
        Me.Label78.Size = New System.Drawing.Size(100, 23)
        Me.Label78.TabIndex = 6
        '
        'Label79
        '
        Me.Label79.BackColor = System.Drawing.Color.ForestGreen
        Me.Label79.Location = New System.Drawing.Point(176, 0)
        Me.Label79.Name = "Label79"
        Me.Label79.Size = New System.Drawing.Size(100, 23)
        Me.Label79.TabIndex = 5
        '
        'Label80
        '
        Me.Label80.BackColor = System.Drawing.Color.ForestGreen
        Me.Label80.Location = New System.Drawing.Point(269, 0)
        Me.Label80.Name = "Label80"
        Me.Label80.Size = New System.Drawing.Size(100, 23)
        Me.Label80.TabIndex = 4
        '
        'Label81
        '
        Me.Label81.BackColor = System.Drawing.Color.ForestGreen
        Me.Label81.Location = New System.Drawing.Point(78, 0)
        Me.Label81.Name = "Label81"
        Me.Label81.Size = New System.Drawing.Size(100, 23)
        Me.Label81.TabIndex = 3
        '
        'Label82
        '
        Me.Label82.BackColor = System.Drawing.Color.ForestGreen
        Me.Label82.Location = New System.Drawing.Point(3, 138)
        Me.Label82.Name = "Label82"
        Me.Label82.Size = New System.Drawing.Size(100, 23)
        Me.Label82.TabIndex = 2
        '
        'Label83
        '
        Me.Label83.BackColor = System.Drawing.Color.ForestGreen
        Me.Label83.Location = New System.Drawing.Point(44, 138)
        Me.Label83.Name = "Label83"
        Me.Label83.Size = New System.Drawing.Size(100, 23)
        Me.Label83.TabIndex = 1
        '
        'Label84
        '
        Me.Label84.BackColor = System.Drawing.Color.ForestGreen
        Me.Label84.Location = New System.Drawing.Point(-5, 48)
        Me.Label84.Name = "Label84"
        Me.Label84.Size = New System.Drawing.Size(23, 50)
        Me.Label84.TabIndex = 0
        '
        'MenuStrip1
        '
        Me.MenuStrip1.Items.AddRange(New System.Windows.Forms.ToolStripItem() {Me.BackToInstructionsToolStripMenuItem, Me.ToolStripMenuItem1, Me.BackToMenuToolStripMenuItem})
        Me.MenuStrip1.Location = New System.Drawing.Point(0, 0)
        Me.MenuStrip1.Name = "MenuStrip1"
        Me.MenuStrip1.Size = New System.Drawing.Size(484, 24)
        Me.MenuStrip1.TabIndex = 3
        Me.MenuStrip1.Text = "MenuStrip1"
        '
        'BackToInstructionsToolStripMenuItem
        '
        Me.BackToInstructionsToolStripMenuItem.Name = "BackToInstructionsToolStripMenuItem"
        Me.BackToInstructionsToolStripMenuItem.Size = New System.Drawing.Size(125, 20)
        Me.BackToInstructionsToolStripMenuItem.Text = "Back To Instructions"
        '
        'ToolStripMenuItem1
        '
        Me.ToolStripMenuItem1.Name = "ToolStripMenuItem1"
        Me.ToolStripMenuItem1.Size = New System.Drawing.Size(12, 20)
        '
        'BackToMenuToolStripMenuItem
        '
        Me.BackToMenuToolStripMenuItem.Name = "BackToMenuToolStripMenuItem"
        Me.BackToMenuToolStripMenuItem.Size = New System.Drawing.Size(94, 20)
        Me.BackToMenuToolStripMenuItem.Text = "Back To Menu"
        '
        'Label42
        '
        Me.Label42.BackColor = System.Drawing.Color.ForestGreen
        Me.Label42.Location = New System.Drawing.Point(355, 302)
        Me.Label42.Name = "Label42"
        Me.Label42.Size = New System.Drawing.Size(23, 100)
        Me.Label42.TabIndex = 41
        '
        'Label41
        '
        Me.Label41.BackColor = System.Drawing.Color.ForestGreen
        Me.Label41.Location = New System.Drawing.Point(428, 290)
        Me.Label41.Name = "Label41"
        Me.Label41.Size = New System.Drawing.Size(23, 91)
        Me.Label41.TabIndex = 40
        '
        'Label40
        '
        Me.Label40.BackColor = System.Drawing.Color.ForestGreen
        Me.Label40.Location = New System.Drawing.Point(428, 200)
        Me.Label40.Name = "Label40"
        Me.Label40.Size = New System.Drawing.Size(23, 100)
        Me.Label40.TabIndex = 39
        '
        'Label39
        '
        Me.Label39.BackColor = System.Drawing.Color.ForestGreen
        Me.Label39.Location = New System.Drawing.Point(428, 102)
        Me.Label39.Name = "Label39"
        Me.Label39.Size = New System.Drawing.Size(23, 100)
        Me.Label39.TabIndex = 38
        '
        'Label38
        '
        Me.Label38.BackColor = System.Drawing.Color.ForestGreen
        Me.Label38.Location = New System.Drawing.Point(428, 2)
        Me.Label38.Name = "Label38"
        Me.Label38.Size = New System.Drawing.Size(23, 100)
        Me.Label38.TabIndex = 37
        '
        'Label37
        '
        Me.Label37.BackColor = System.Drawing.Color.ForestGreen
        Me.Label37.Location = New System.Drawing.Point(282, 35)
        Me.Label37.Name = "Label37"
        Me.Label37.Size = New System.Drawing.Size(87, 23)
        Me.Label37.TabIndex = 36
        '
        'Label36
        '
        Me.Label36.BackColor = System.Drawing.Color.ForestGreen
        Me.Label36.Location = New System.Drawing.Point(310, 79)
        Me.Label36.Name = "Label36"
        Me.Label36.Size = New System.Drawing.Size(23, 100)
        Me.Label36.TabIndex = 35
        '
        'Label35
        '
        Me.Label35.BackColor = System.Drawing.Color.ForestGreen
        Me.Label35.Location = New System.Drawing.Point(310, 138)
        Me.Label35.Name = "Label35"
        Me.Label35.Size = New System.Drawing.Size(23, 100)
        Me.Label35.TabIndex = 34
        '
        'Label34
        '
        Me.Label34.BackColor = System.Drawing.Color.ForestGreen
        Me.Label34.Location = New System.Drawing.Point(310, 200)
        Me.Label34.Name = "Label34"
        Me.Label34.Size = New System.Drawing.Size(23, 100)
        Me.Label34.TabIndex = 33
        '
        'Label31
        '
        Me.Label31.BackColor = System.Drawing.Color.ForestGreen
        Me.Label31.Location = New System.Drawing.Point(278, 390)
        Me.Label31.Name = "Label31"
        Me.Label31.Size = New System.Drawing.Size(100, 23)
        Me.Label31.TabIndex = 30
        '
        'Label33
        '
        Me.Label33.BackColor = System.Drawing.Color.ForestGreen
        Me.Label33.Location = New System.Drawing.Point(351, 0)
        Me.Label33.Name = "Label33"
        Me.Label33.Size = New System.Drawing.Size(100, 23)
        Me.Label33.TabIndex = 32
        '
        'Label32
        '
        Me.Label32.BackColor = System.Drawing.Color.ForestGreen
        Me.Label32.Location = New System.Drawing.Point(269, 200)
        Me.Label32.Name = "Label32"
        Me.Label32.Size = New System.Drawing.Size(100, 23)
        Me.Label32.TabIndex = 31
        '
        'Label30
        '
        Me.Label30.BackColor = System.Drawing.Color.ForestGreen
        Me.Label30.Location = New System.Drawing.Point(94, 390)
        Me.Label30.Name = "Label30"
        Me.Label30.Size = New System.Drawing.Size(100, 23)
        Me.Label30.TabIndex = 29
        '
        'Label29
        '
        Me.Label29.BackColor = System.Drawing.Color.ForestGreen
        Me.Label29.Location = New System.Drawing.Point(188, 390)
        Me.Label29.Name = "Label29"
        Me.Label29.Size = New System.Drawing.Size(100, 23)
        Me.Label29.TabIndex = 28
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.Fixed3D
        Me.Panel1.Controls.Add(Me.Panel2)
        Me.Panel1.Controls.Add(Me.Label42)
        Me.Panel1.Controls.Add(Me.Label41)
        Me.Panel1.Controls.Add(Me.Label40)
        Me.Panel1.Controls.Add(Me.Label39)
        Me.Panel1.Controls.Add(Me.Label38)
        Me.Panel1.Controls.Add(Me.Label37)
        Me.Panel1.Controls.Add(Me.Label36)
        Me.Panel1.Controls.Add(Me.Label35)
        Me.Panel1.Controls.Add(Me.Label34)
        Me.Panel1.Controls.Add(Me.Label33)
        Me.Panel1.Controls.Add(Me.Label32)
        Me.Panel1.Controls.Add(Me.Label31)
        Me.Panel1.Controls.Add(Me.Label30)
        Me.Panel1.Controls.Add(Me.Label29)
        Me.Panel1.Controls.Add(Me.Label28)
        Me.Panel1.Controls.Add(Me.Label27)
        Me.Panel1.Controls.Add(Me.Label26)
        Me.Panel1.Controls.Add(Me.Label25)
        Me.Panel1.Controls.Add(Me.Label24)
        Me.Panel1.Controls.Add(Me.Label23)
        Me.Panel1.Controls.Add(Me.Label22)
        Me.Panel1.Controls.Add(Me.Label21)
        Me.Panel1.Controls.Add(Me.Label20)
        Me.Panel1.Controls.Add(Me.Label19)
        Me.Panel1.Controls.Add(Me.Label18)
        Me.Panel1.Controls.Add(Me.Label17)
        Me.Panel1.Controls.Add(Me.Label16)
        Me.Panel1.Controls.Add(Me.Label15)
        Me.Panel1.Controls.Add(Me.Label14)
        Me.Panel1.Controls.Add(Me.Label13)
        Me.Panel1.Controls.Add(Me.Label12)
        Me.Panel1.Controls.Add(Me.Label11)
        Me.Panel1.Controls.Add(Me.Label10)
        Me.Panel1.Controls.Add(Me.Label9)
        Me.Panel1.Controls.Add(Me.Label8)
        Me.Panel1.Controls.Add(Me.Label7)
        Me.Panel1.Controls.Add(Me.Label6)
        Me.Panel1.Controls.Add(Me.Label5)
        Me.Panel1.Controls.Add(Me.Label4)
        Me.Panel1.Controls.Add(Me.Label3)
        Me.Panel1.Controls.Add(Me.Label2)
        Me.Panel1.Controls.Add(Me.Label1)
        Me.Panel1.Location = New System.Drawing.Point(12, 33)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(453, 417)
        Me.Panel1.TabIndex = 2
        '
        'Label28
        '
        Me.Label28.BackColor = System.Drawing.Color.ForestGreen
        Me.Label28.Location = New System.Drawing.Point(94, 327)
        Me.Label28.Name = "Label28"
        Me.Label28.Size = New System.Drawing.Size(100, 23)
        Me.Label28.TabIndex = 27
        '
        'Label27
        '
        Me.Label27.BackColor = System.Drawing.Color.ForestGreen
        Me.Label27.Location = New System.Drawing.Point(111, 267)
        Me.Label27.Name = "Label27"
        Me.Label27.Size = New System.Drawing.Size(100, 23)
        Me.Label27.TabIndex = 26
        '
        'Label26
        '
        Me.Label26.BackColor = System.Drawing.Color.ForestGreen
        Me.Label26.Location = New System.Drawing.Point(310, 290)
        Me.Label26.Name = "Label26"
        Me.Label26.Size = New System.Drawing.Size(23, 100)
        Me.Label26.TabIndex = 25
        '
        'Label25
        '
        Me.Label25.BackColor = System.Drawing.Color.ForestGreen
        Me.Label25.Location = New System.Drawing.Point(246, 267)
        Me.Label25.Name = "Label25"
        Me.Label25.Size = New System.Drawing.Size(23, 69)
        Me.Label25.TabIndex = 24
        '
        'Label24
        '
        Me.Label24.BackColor = System.Drawing.Color.ForestGreen
        Me.Label24.Location = New System.Drawing.Point(246, 223)
        Me.Label24.Name = "Label24"
        Me.Label24.Size = New System.Drawing.Size(23, 100)
        Me.Label24.TabIndex = 23
        '
        'Label23
        '
        Me.Label23.BackColor = System.Drawing.Color.ForestGreen
        Me.Label23.Location = New System.Drawing.Point(-5, 267)
        Me.Label23.Name = "Label23"
        Me.Label23.Size = New System.Drawing.Size(23, 100)
        Me.Label23.TabIndex = 22
        '
        'Label22
        '
        Me.Label22.BackColor = System.Drawing.Color.ForestGreen
        Me.Label22.Location = New System.Drawing.Point(-5, 327)
        Me.Label22.Name = "Label22"
        Me.Label22.Size = New System.Drawing.Size(23, 100)
        Me.Label22.TabIndex = 21
        '
        'Label21
        '
        Me.Label21.BackColor = System.Drawing.Color.ForestGreen
        Me.Label21.Location = New System.Drawing.Point(62, 200)
        Me.Label21.Name = "Label21"
        Me.Label21.Size = New System.Drawing.Size(23, 75)
        Me.Label21.TabIndex = 20
        '
        'Label20
        '
        Me.Label20.BackColor = System.Drawing.Color.ForestGreen
        Me.Label20.Location = New System.Drawing.Point(246, 123)
        Me.Label20.Name = "Label20"
        Me.Label20.Size = New System.Drawing.Size(23, 100)
        Me.Label20.TabIndex = 19
        '
        'Label19
        '
        Me.Label19.BackColor = System.Drawing.Color.ForestGreen
        Me.Label19.Location = New System.Drawing.Point(246, 23)
        Me.Label19.Name = "Label19"
        Me.Label19.Size = New System.Drawing.Size(23, 100)
        Me.Label19.TabIndex = 18
        '
        'Label18
        '
        Me.Label18.BackColor = System.Drawing.Color.ForestGreen
        Me.Label18.Location = New System.Drawing.Point(-5, 196)
        Me.Label18.Name = "Label18"
        Me.Label18.Size = New System.Drawing.Size(23, 100)
        Me.Label18.TabIndex = 17
        '
        'Label17
        '
        Me.Label17.BackColor = System.Drawing.Color.ForestGreen
        Me.Label17.Location = New System.Drawing.Point(121, 61)
        Me.Label17.Name = "Label17"
        Me.Label17.Size = New System.Drawing.Size(23, 100)
        Me.Label17.TabIndex = 16
        '
        'Label16
        '
        Me.Label16.BackColor = System.Drawing.Color.ForestGreen
        Me.Label16.Location = New System.Drawing.Point(188, 61)
        Me.Label16.Name = "Label16"
        Me.Label16.Size = New System.Drawing.Size(23, 100)
        Me.Label16.TabIndex = 15
        '
        'Label15
        '
        Me.Label15.BackColor = System.Drawing.Color.ForestGreen
        Me.Label15.Location = New System.Drawing.Point(62, 0)
        Me.Label15.Name = "Label15"
        Me.Label15.Size = New System.Drawing.Size(23, 100)
        Me.Label15.TabIndex = 14
        '
        'Label14
        '
        Me.Label14.BackColor = System.Drawing.Color.ForestGreen
        Me.Label14.Location = New System.Drawing.Point(-5, 98)
        Me.Label14.Name = "Label14"
        Me.Label14.Size = New System.Drawing.Size(23, 100)
        Me.Label14.TabIndex = 13
        '
        'Label13
        '
        Me.Label13.BackColor = System.Drawing.Color.ForestGreen
        Me.Label13.Location = New System.Drawing.Point(3, 390)
        Me.Label13.Name = "Label13"
        Me.Label13.Size = New System.Drawing.Size(100, 23)
        Me.Label13.TabIndex = 12
        '
        'Label12
        '
        Me.Label12.BackColor = System.Drawing.Color.ForestGreen
        Me.Label12.Location = New System.Drawing.Point(62, 267)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(100, 23)
        Me.Label12.TabIndex = 11
        '
        'Label11
        '
        Me.Label11.BackColor = System.Drawing.Color.ForestGreen
        Me.Label11.Location = New System.Drawing.Point(13, 327)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(100, 23)
        Me.Label11.TabIndex = 10
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.ForestGreen
        Me.Label10.Location = New System.Drawing.Point(62, 200)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(100, 23)
        Me.Label10.TabIndex = 9
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.ForestGreen
        Me.Label9.Location = New System.Drawing.Point(124, 61)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(87, 23)
        Me.Label9.TabIndex = 8
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.Color.ForestGreen
        Me.Label8.Location = New System.Drawing.Point(78, 200)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(100, 23)
        Me.Label8.TabIndex = 7
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.Color.ForestGreen
        Me.Label7.Location = New System.Drawing.Point(169, 200)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(100, 23)
        Me.Label7.TabIndex = 6
        '
        'Label6
        '
        Me.Label6.BackColor = System.Drawing.Color.ForestGreen
        Me.Label6.Location = New System.Drawing.Point(176, 0)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(100, 23)
        Me.Label6.TabIndex = 5
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.ForestGreen
        Me.Label5.Location = New System.Drawing.Point(269, 0)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(100, 23)
        Me.Label5.TabIndex = 4
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.ForestGreen
        Me.Label4.Location = New System.Drawing.Point(78, 0)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(100, 23)
        Me.Label4.TabIndex = 3
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.Color.ForestGreen
        Me.Label3.Location = New System.Drawing.Point(3, 138)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(100, 23)
        Me.Label3.TabIndex = 2
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.ForestGreen
        Me.Label2.Location = New System.Drawing.Point(44, 138)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(100, 23)
        Me.Label2.TabIndex = 1
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.ForestGreen
        Me.Label1.Location = New System.Drawing.Point(-5, -2)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(23, 100)
        Me.Label1.TabIndex = 0
        '
        'Maze
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(484, 461)
        Me.Controls.Add(Me.MenuStrip1)
        Me.Controls.Add(Me.Panel1)
        Me.MaximizeBox = False
        Me.Name = "Maze"
        Me.Text = "Maze Game"
        Me.Panel2.ResumeLayout(False)
        Me.Panel2.PerformLayout()
        Me.MenuStrip1.ResumeLayout(False)
        Me.MenuStrip1.PerformLayout()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
    Friend WithEvents Label64 As System.Windows.Forms.Label
    Friend WithEvents Label65 As System.Windows.Forms.Label
    Friend WithEvents Label66 As System.Windows.Forms.Label
    Friend WithEvents Label67 As System.Windows.Forms.Label
    Friend WithEvents Label68 As System.Windows.Forms.Label
    Friend WithEvents Label69 As System.Windows.Forms.Label
    Friend WithEvents Label72 As System.Windows.Forms.Label
    Friend WithEvents Label74 As System.Windows.Forms.Label
    Friend WithEvents Label75 As System.Windows.Forms.Label
    Friend WithEvents Label70 As System.Windows.Forms.Label
    Friend WithEvents Label71 As System.Windows.Forms.Label
    Friend WithEvents Label76 As System.Windows.Forms.Label
    Friend WithEvents Label77 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents lblStart As System.Windows.Forms.Label
    Friend WithEvents Label87 As System.Windows.Forms.Label
    Friend WithEvents lblFinish As System.Windows.Forms.Label
    Friend WithEvents Label43 As System.Windows.Forms.Label
    Friend WithEvents Label48 As System.Windows.Forms.Label
    Friend WithEvents Label86 As System.Windows.Forms.Label
    Friend WithEvents Label53 As System.Windows.Forms.Label
    Friend WithEvents Label85 As System.Windows.Forms.Label
    Friend WithEvents Label44 As System.Windows.Forms.Label
    Friend WithEvents Label45 As System.Windows.Forms.Label
    Friend WithEvents Label46 As System.Windows.Forms.Label
    Friend WithEvents Label47 As System.Windows.Forms.Label
    Friend WithEvents Label49 As System.Windows.Forms.Label
    Friend WithEvents Label50 As System.Windows.Forms.Label
    Friend WithEvents Label51 As System.Windows.Forms.Label
    Friend WithEvents Label52 As System.Windows.Forms.Label
    Friend WithEvents Label54 As System.Windows.Forms.Label
    Friend WithEvents Label55 As System.Windows.Forms.Label
    Friend WithEvents Label56 As System.Windows.Forms.Label
    Friend WithEvents Label57 As System.Windows.Forms.Label
    Friend WithEvents Label58 As System.Windows.Forms.Label
    Friend WithEvents Label59 As System.Windows.Forms.Label
    Friend WithEvents Label60 As System.Windows.Forms.Label
    Friend WithEvents Label61 As System.Windows.Forms.Label
    Friend WithEvents Label62 As System.Windows.Forms.Label
    Friend WithEvents Label63 As System.Windows.Forms.Label
    Friend WithEvents Label73 As System.Windows.Forms.Label
    Friend WithEvents Label78 As System.Windows.Forms.Label
    Friend WithEvents Label79 As System.Windows.Forms.Label
    Friend WithEvents Label80 As System.Windows.Forms.Label
    Friend WithEvents Label81 As System.Windows.Forms.Label
    Friend WithEvents Label82 As System.Windows.Forms.Label
    Friend WithEvents Label83 As System.Windows.Forms.Label
    Friend WithEvents Label84 As System.Windows.Forms.Label
    Friend WithEvents MenuStrip1 As System.Windows.Forms.MenuStrip
    Friend WithEvents Label42 As System.Windows.Forms.Label
    Friend WithEvents Label41 As System.Windows.Forms.Label
    Friend WithEvents Label40 As System.Windows.Forms.Label
    Friend WithEvents Label39 As System.Windows.Forms.Label
    Friend WithEvents Label38 As System.Windows.Forms.Label
    Friend WithEvents Label37 As System.Windows.Forms.Label
    Friend WithEvents Label36 As System.Windows.Forms.Label
    Friend WithEvents Label35 As System.Windows.Forms.Label
    Friend WithEvents Label34 As System.Windows.Forms.Label
    Friend WithEvents Label31 As System.Windows.Forms.Label
    Friend WithEvents Label33 As System.Windows.Forms.Label
    Friend WithEvents Label32 As System.Windows.Forms.Label
    Friend WithEvents Label30 As System.Windows.Forms.Label
    Friend WithEvents Label29 As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Label28 As System.Windows.Forms.Label
    Friend WithEvents Label27 As System.Windows.Forms.Label
    Friend WithEvents Label26 As System.Windows.Forms.Label
    Friend WithEvents Label25 As System.Windows.Forms.Label
    Friend WithEvents Label24 As System.Windows.Forms.Label
    Friend WithEvents Label23 As System.Windows.Forms.Label
    Friend WithEvents Label22 As System.Windows.Forms.Label
    Friend WithEvents Label21 As System.Windows.Forms.Label
    Friend WithEvents Label20 As System.Windows.Forms.Label
    Friend WithEvents Label19 As System.Windows.Forms.Label
    Friend WithEvents Label18 As System.Windows.Forms.Label
    Friend WithEvents Label17 As System.Windows.Forms.Label
    Friend WithEvents Label16 As System.Windows.Forms.Label
    Friend WithEvents Label15 As System.Windows.Forms.Label
    Friend WithEvents Label14 As System.Windows.Forms.Label
    Friend WithEvents Label13 As System.Windows.Forms.Label
    Friend WithEvents Label12 As System.Windows.Forms.Label
    Friend WithEvents Label11 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label6 As System.Windows.Forms.Label
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents ToolStripMenuItem1 As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackToInstructionsToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
    Friend WithEvents BackToMenuToolStripMenuItem As System.Windows.Forms.ToolStripMenuItem
End Class
