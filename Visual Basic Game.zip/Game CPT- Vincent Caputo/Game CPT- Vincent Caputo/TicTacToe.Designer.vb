﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class TicTacToe
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(TicTacToe))
        Me.Label1 = New System.Windows.Forms.Label()
        Me.BtnStart = New System.Windows.Forms.Button()
        Me.BtnCoinToss = New System.Windows.Forms.Button()
        Me.rdbtnorange = New System.Windows.Forms.RadioButton()
        Me.RdbtnGreen = New System.Windows.Forms.RadioButton()
        Me.RdbtnMagenta = New System.Windows.Forms.RadioButton()
        Me.GroupBox1 = New System.Windows.Forms.GroupBox()
        Me.PicBoxTopMid = New System.Windows.Forms.PictureBox()
        Me.PicBoxTopRight = New System.Windows.Forms.PictureBox()
        Me.PicBoxMidLeft = New System.Windows.Forms.PictureBox()
        Me.PicBoxMid = New System.Windows.Forms.PictureBox()
        Me.PicBoxMidRight = New System.Windows.Forms.PictureBox()
        Me.PicBoxBotRight = New System.Windows.Forms.PictureBox()
        Me.PicBoxBotMid = New System.Windows.Forms.PictureBox()
        Me.PicBoxBotLeft = New System.Windows.Forms.PictureBox()
        Me.PicBoxTopLeft = New System.Windows.Forms.PictureBox()
        Me.picboxMagenta = New System.Windows.Forms.PictureBox()
        Me.picboxGreen = New System.Windows.Forms.PictureBox()
        Me.picboxOrange = New System.Windows.Forms.PictureBox()
        Me.GroupBox1.SuspendLayout()
        CType(Me.PicBoxTopMid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxTopRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxMidLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxMid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxMidRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxBotRight, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxBotMid, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxBotLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.PicBoxTopLeft, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picboxMagenta, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picboxGreen, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.picboxOrange, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.Label1.Location = New System.Drawing.Point(144, 298)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(65, 23)
        Me.Label1.TabIndex = 38
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'BtnStart
        '
        Me.BtnStart.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.BtnStart.Location = New System.Drawing.Point(215, 298)
        Me.BtnStart.Name = "BtnStart"
        Me.BtnStart.Size = New System.Drawing.Size(75, 23)
        Me.BtnStart.TabIndex = 37
        Me.BtnStart.Text = "Start Game"
        Me.BtnStart.UseVisualStyleBackColor = False
        Me.BtnStart.Visible = False
        '
        'BtnCoinToss
        '
        Me.BtnCoinToss.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(128, Byte), Integer))
        Me.BtnCoinToss.Location = New System.Drawing.Point(7, 298)
        Me.BtnCoinToss.Name = "BtnCoinToss"
        Me.BtnCoinToss.Size = New System.Drawing.Size(131, 23)
        Me.BtnCoinToss.TabIndex = 36
        Me.BtnCoinToss.Text = "Decide Who Goes First:"
        Me.BtnCoinToss.UseVisualStyleBackColor = False
        '
        'rdbtnorange
        '
        Me.rdbtnorange.AutoSize = True
        Me.rdbtnorange.Location = New System.Drawing.Point(6, 170)
        Me.rdbtnorange.Name = "rdbtnorange"
        Me.rdbtnorange.Size = New System.Drawing.Size(14, 13)
        Me.rdbtnorange.TabIndex = 40
        Me.rdbtnorange.TabStop = True
        Me.rdbtnorange.Tag = "Colors"
        Me.rdbtnorange.UseVisualStyleBackColor = True
        '
        'RdbtnGreen
        '
        Me.RdbtnGreen.AutoSize = True
        Me.RdbtnGreen.Location = New System.Drawing.Point(6, 212)
        Me.RdbtnGreen.Name = "RdbtnGreen"
        Me.RdbtnGreen.Size = New System.Drawing.Size(14, 13)
        Me.RdbtnGreen.TabIndex = 42
        Me.RdbtnGreen.TabStop = True
        Me.RdbtnGreen.Tag = "Colors"
        Me.RdbtnGreen.UseVisualStyleBackColor = True
        '
        'RdbtnMagenta
        '
        Me.RdbtnMagenta.AutoSize = True
        Me.RdbtnMagenta.Location = New System.Drawing.Point(6, 254)
        Me.RdbtnMagenta.Name = "RdbtnMagenta"
        Me.RdbtnMagenta.Size = New System.Drawing.Size(14, 13)
        Me.RdbtnMagenta.TabIndex = 44
        Me.RdbtnMagenta.TabStop = True
        Me.RdbtnMagenta.Tag = "Colors"
        Me.RdbtnMagenta.UseVisualStyleBackColor = True
        '
        'GroupBox1
        '
        Me.GroupBox1.Controls.Add(Me.picboxMagenta)
        Me.GroupBox1.Controls.Add(Me.rdbtnorange)
        Me.GroupBox1.Controls.Add(Me.picboxGreen)
        Me.GroupBox1.Controls.Add(Me.RdbtnMagenta)
        Me.GroupBox1.Controls.Add(Me.picboxOrange)
        Me.GroupBox1.Controls.Add(Me.RdbtnGreen)
        Me.GroupBox1.Font = New System.Drawing.Font("Comic Sans MS", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.GroupBox1.Location = New System.Drawing.Point(296, 12)
        Me.GroupBox1.Name = "GroupBox1"
        Me.GroupBox1.Size = New System.Drawing.Size(24, 307)
        Me.GroupBox1.TabIndex = 46
        Me.GroupBox1.TabStop = False
        Me.GroupBox1.Text = "TILE   COLOUR"
        Me.GroupBox1.Visible = False
        '
        'PicBoxTopMid
        '
        Me.PicBoxTopMid.Image = CType(resources.GetObject("PicBoxTopMid.Image"), System.Drawing.Image)
        Me.PicBoxTopMid.Location = New System.Drawing.Point(103, 9)
        Me.PicBoxTopMid.Name = "PicBoxTopMid"
        Me.PicBoxTopMid.Size = New System.Drawing.Size(91, 91)
        Me.PicBoxTopMid.TabIndex = 35
        Me.PicBoxTopMid.TabStop = False
        Me.PicBoxTopMid.Tag = "TicTacToeSquares"
        '
        'PicBoxTopRight
        '
        Me.PicBoxTopRight.Image = CType(resources.GetObject("PicBoxTopRight.Image"), System.Drawing.Image)
        Me.PicBoxTopRight.Location = New System.Drawing.Point(199, 9)
        Me.PicBoxTopRight.Name = "PicBoxTopRight"
        Me.PicBoxTopRight.Size = New System.Drawing.Size(91, 91)
        Me.PicBoxTopRight.TabIndex = 34
        Me.PicBoxTopRight.TabStop = False
        Me.PicBoxTopRight.Tag = "TicTacToeSquares"
        '
        'PicBoxMidLeft
        '
        Me.PicBoxMidLeft.Image = CType(resources.GetObject("PicBoxMidLeft.Image"), System.Drawing.Image)
        Me.PicBoxMidLeft.Location = New System.Drawing.Point(7, 105)
        Me.PicBoxMidLeft.Name = "PicBoxMidLeft"
        Me.PicBoxMidLeft.Size = New System.Drawing.Size(91, 91)
        Me.PicBoxMidLeft.TabIndex = 33
        Me.PicBoxMidLeft.TabStop = False
        Me.PicBoxMidLeft.Tag = "TicTacToeSquares"
        '
        'PicBoxMid
        '
        Me.PicBoxMid.Image = CType(resources.GetObject("PicBoxMid.Image"), System.Drawing.Image)
        Me.PicBoxMid.Location = New System.Drawing.Point(103, 105)
        Me.PicBoxMid.Name = "PicBoxMid"
        Me.PicBoxMid.Size = New System.Drawing.Size(91, 91)
        Me.PicBoxMid.TabIndex = 32
        Me.PicBoxMid.TabStop = False
        Me.PicBoxMid.Tag = "TicTacToeSquares"
        '
        'PicBoxMidRight
        '
        Me.PicBoxMidRight.Image = Global.Game_CPT__Vincent_Caputo.My.Resources.Resources.orangebox
        Me.PicBoxMidRight.Location = New System.Drawing.Point(199, 105)
        Me.PicBoxMidRight.Name = "PicBoxMidRight"
        Me.PicBoxMidRight.Size = New System.Drawing.Size(91, 91)
        Me.PicBoxMidRight.TabIndex = 31
        Me.PicBoxMidRight.TabStop = False
        Me.PicBoxMidRight.Tag = "TicTacToeSquares"
        '
        'PicBoxBotRight
        '
        Me.PicBoxBotRight.Image = CType(resources.GetObject("PicBoxBotRight.Image"), System.Drawing.Image)
        Me.PicBoxBotRight.Location = New System.Drawing.Point(199, 201)
        Me.PicBoxBotRight.Name = "PicBoxBotRight"
        Me.PicBoxBotRight.Size = New System.Drawing.Size(91, 91)
        Me.PicBoxBotRight.TabIndex = 30
        Me.PicBoxBotRight.TabStop = False
        Me.PicBoxBotRight.Tag = "TicTacToeSquares"
        '
        'PicBoxBotMid
        '
        Me.PicBoxBotMid.Image = CType(resources.GetObject("PicBoxBotMid.Image"), System.Drawing.Image)
        Me.PicBoxBotMid.Location = New System.Drawing.Point(103, 201)
        Me.PicBoxBotMid.Name = "PicBoxBotMid"
        Me.PicBoxBotMid.Size = New System.Drawing.Size(91, 91)
        Me.PicBoxBotMid.TabIndex = 29
        Me.PicBoxBotMid.TabStop = False
        Me.PicBoxBotMid.Tag = "TicTacToeSquares"
        '
        'PicBoxBotLeft
        '
        Me.PicBoxBotLeft.Image = CType(resources.GetObject("PicBoxBotLeft.Image"), System.Drawing.Image)
        Me.PicBoxBotLeft.Location = New System.Drawing.Point(7, 201)
        Me.PicBoxBotLeft.Name = "PicBoxBotLeft"
        Me.PicBoxBotLeft.Size = New System.Drawing.Size(91, 91)
        Me.PicBoxBotLeft.TabIndex = 28
        Me.PicBoxBotLeft.TabStop = False
        Me.PicBoxBotLeft.Tag = "TicTacToeSquares"
        '
        'PicBoxTopLeft
        '
        Me.PicBoxTopLeft.Image = CType(resources.GetObject("PicBoxTopLeft.Image"), System.Drawing.Image)
        Me.PicBoxTopLeft.Location = New System.Drawing.Point(7, 9)
        Me.PicBoxTopLeft.Name = "PicBoxTopLeft"
        Me.PicBoxTopLeft.Size = New System.Drawing.Size(91, 91)
        Me.PicBoxTopLeft.TabIndex = 27
        Me.PicBoxTopLeft.TabStop = False
        Me.PicBoxTopLeft.Tag = "TicTacToeSquares"
        '
        'picboxMagenta
        '
        Me.picboxMagenta.BackColor = System.Drawing.Color.Fuchsia
        Me.picboxMagenta.Location = New System.Drawing.Point(2, 273)
        Me.picboxMagenta.Name = "picboxMagenta"
        Me.picboxMagenta.Size = New System.Drawing.Size(18, 17)
        Me.picboxMagenta.TabIndex = 45
        Me.picboxMagenta.TabStop = False
        '
        'picboxGreen
        '
        Me.picboxGreen.BackColor = System.Drawing.Color.FromArgb(CType(CType(0, Byte), Integer), CType(CType(192, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.picboxGreen.Location = New System.Drawing.Point(2, 231)
        Me.picboxGreen.Name = "picboxGreen"
        Me.picboxGreen.Size = New System.Drawing.Size(18, 17)
        Me.picboxGreen.TabIndex = 43
        Me.picboxGreen.TabStop = False
        '
        'picboxOrange
        '
        Me.picboxOrange.BackColor = System.Drawing.Color.FromArgb(CType(CType(255, Byte), Integer), CType(CType(128, Byte), Integer), CType(CType(0, Byte), Integer))
        Me.picboxOrange.Location = New System.Drawing.Point(2, 189)
        Me.picboxOrange.Name = "picboxOrange"
        Me.picboxOrange.Size = New System.Drawing.Size(18, 17)
        Me.picboxOrange.TabIndex = 41
        Me.picboxOrange.TabStop = False
        '
        'TicTacToe
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(322, 331)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.BtnStart)
        Me.Controls.Add(Me.BtnCoinToss)
        Me.Controls.Add(Me.PicBoxTopMid)
        Me.Controls.Add(Me.PicBoxTopRight)
        Me.Controls.Add(Me.PicBoxMidLeft)
        Me.Controls.Add(Me.PicBoxMid)
        Me.Controls.Add(Me.PicBoxMidRight)
        Me.Controls.Add(Me.PicBoxBotRight)
        Me.Controls.Add(Me.PicBoxBotMid)
        Me.Controls.Add(Me.PicBoxBotLeft)
        Me.Controls.Add(Me.PicBoxTopLeft)
        Me.Controls.Add(Me.GroupBox1)
        Me.Name = "TicTacToe"
        Me.Text = "TicTacToe"
        Me.GroupBox1.ResumeLayout(False)
        Me.GroupBox1.PerformLayout()
        CType(Me.PicBoxTopMid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxTopRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxMidLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxMid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxMidRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxBotRight, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxBotMid, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxBotLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.PicBoxTopLeft, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picboxMagenta, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picboxGreen, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.picboxOrange, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents BtnStart As System.Windows.Forms.Button
    Friend WithEvents BtnCoinToss As System.Windows.Forms.Button
    Friend WithEvents PicBoxTopMid As System.Windows.Forms.PictureBox
    Friend WithEvents PicBoxTopRight As System.Windows.Forms.PictureBox
    Friend WithEvents PicBoxMidLeft As System.Windows.Forms.PictureBox
    Friend WithEvents PicBoxMid As System.Windows.Forms.PictureBox
    Friend WithEvents PicBoxMidRight As System.Windows.Forms.PictureBox
    Friend WithEvents PicBoxBotRight As System.Windows.Forms.PictureBox
    Friend WithEvents PicBoxBotMid As System.Windows.Forms.PictureBox
    Friend WithEvents PicBoxBotLeft As System.Windows.Forms.PictureBox
    Friend WithEvents PicBoxTopLeft As System.Windows.Forms.PictureBox
    Friend WithEvents rdbtnorange As System.Windows.Forms.RadioButton
    Friend WithEvents picboxOrange As System.Windows.Forms.PictureBox
    Friend WithEvents RdbtnGreen As System.Windows.Forms.RadioButton
    Friend WithEvents picboxGreen As System.Windows.Forms.PictureBox
    Friend WithEvents RdbtnMagenta As System.Windows.Forms.RadioButton
    Friend WithEvents picboxMagenta As System.Windows.Forms.PictureBox
    Friend WithEvents GroupBox1 As System.Windows.Forms.GroupBox
End Class
